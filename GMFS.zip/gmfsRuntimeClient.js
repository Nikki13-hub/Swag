/**
 *@NApiVersion 2.1
 *@NScriptType ClientScript
 */

define(['N/currentRecord', 'N/runtime', 'N/format', 'N/query', 'N/search'], 
function(currentRecord, runtime, format, query, search) {
	var xlsxFile;
	//jQuery.getScript("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js");
	jQuery.getScript("https://rawgithub.com/protobi/js-xlsx/master/xlsx.js");
	jQuery.getScript("https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js", function() {jQuery('<style>').load("https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css").appendTo("head");})
	.defaults = {
		bgOpacity: null,
		backgroundDismiss: false,
		backgroundDismissAction: 'shake',
		autoClose: false,
		boxWidth: '50%',
		useBootstrap: false,
		type: 'blue',
		onContentReady: function() {},
		onOpenBefore: function() {},
		onOpen: function() {},
		onClose: function() {},
		onDestroy: function() {},
		onAction: function() {},
		buttons: {},
		defaultButtons: {
			ok: {
				action: function () {
				}
			}
		}
	};
	
		function pageInit(context) {
			var sql = `select id, fullname from subsidiary where parent is not null and iselimination = 'F' order by id`;
			var subs = query.runSuiteQL({query: sql}).asMappedResults();
			subs.forEach(function(s) {
				context.currentRecord.getField({fieldId: 'custpage_locations'}).insertSelectOption({value: s.id, text: s.fullname});
				return true;
			});
			return;
			return;
		}
		
	function processInfo() {
		console.log('GMFS', 'Start');
		xlsxFile = runtime.getCurrentSession().get({name: 'gmfsfile'})||'';
		if (!xlsxFile) {
			jQuery.alert({
				title: 'Error', 
				bgOpacity: null,
				backgroundDismiss: false,
				backgroundDismissAction: 'shake',
				autoClose: false,
				boxWidth: '50%',
				useBootstrap: false,
				type: 'red',
				content: 'No Excel template loaded'
			});
			return;
		}
		else {
			jQuery.confirm({
				title: 'Processing Request', 
				bgOpacity: null,
				backgroundDismiss: false,
				backgroundDismissAction: 'shake',
				autoClose: false,
				boxWidth: '50%',
				useBootstrap: false,
				type: 'blue',
				content: 'Processing request. Please Wait...',
				buttons: {
					close: function() {
						return;
					}
				},
				onContentReady: function() {
					var self = this;
					var cr = currentRecord.get();
					var xlsx = XLSX.read(xlsxFile,{cellStyles:true});
					var marray = ["January","February","March","April","May","June","July","August","September","October","November","December"];
					var reportLocations = cr.getValue('custpage_locations');
					var runLocations = reportLocations.toString().split('\u0005');
					var runLocations = JSON.stringify(runLocations);
					var arLocations = runLocations.replace('[','(');
					var arLocations = arLocations.replace(']',')');
					var arLocations = arLocations.replace(/["]+/g, '');
					var runLocations = runLocations.replace('[','');
					var runLocations = runLocations.replace(']','');
					var runLocations = runLocations.replace(/["]+/g, '');
					var startDate = format.format({value: cr.getValue('custpage_startdate'), type: format.Type.DATE});
					var endDate = format.format({value: cr.getValue('custpage_enddate'), type: format.Type.DATE});
					var startDateNS = new Date(startDate);
					var endDateNS = new Date(endDate);
					var startMo = marray[startDateNS.getMonth()];
					var startDay = startDateNS.getDate();
					var startYear = startDateNS.getFullYear();
					var endMo = marray[endDateNS.getMonth()];
					var endDay = endDateNS.getDate();
					var endYear = endDateNS.getFullYear();
					var sSql = `select id, parent from accountingperiod where parent is not null and isquarter = 'F' and isposting = 'T' and isadjust = 'F' and isyear = 'F' and startdate = '${startDate}'`;
					var sPeriod = query.runSuiteQL({query: sSql}).asMappedResults(); 
					var eSql = `select id from accountingperiod where parent is not null and isquarter = 'F' and isposting = 'T' and isadjust = 'F' and isyear = 'F' and enddate = '${endDate}'`;
					var ePeriod = query.runSuiteQL({query: eSql}).asMappedResults(); 
					if ((ePeriod && ePeriod.length > 0) && (sPeriod && sPeriod.length > 0)) {
					var sPer = Number(sPeriod[0].id);
					var soPer = Number(sPeriod[0].parent);
					var ePer = Number(ePeriod[0].id);
					var nPer = ePer - sPer;
					var niLines = [];
					console.log('Run', 'Net Income');
					setTimeout(function() {self.setContentAppend('<br>Processing net income')},2000);
					var epSql = `select MAX(id) id from accountingperiod where parent = ${soPer} and id <= ${ePer}`;
					var epPeriod = query.runSuiteQL({query: epSql}).asMappedResults();
					var epPer = Number(epPeriod[0].id);
					var niSql = `SELECT GMFSDate, SUM(NetIncome) NetIncome FROM (
						SELECT 
						to_number(to_char(AccountingPeriod.StartDate, 'mm') + 52) GMFSDate,
						SUM( COALESCE( TransactionAccountingLine.Credit, 0 ) - COALESCE( TransactionAccountingLine.Debit, 0 ) ) AS NetIncome
						FROM 
						Transaction	
						INNER JOIN TransactionAccountingLine ON ( TransactionAccountingLine.Transaction = Transaction.ID )
						INNER JOIN Account ON ( Account.ID = TransactionAccountingLine.Account )
						INNER JOIN AccountingPeriod ON ( AccountingPeriod.ID = Transaction.PostingPeriod )	
						INNER JOIN (SELECT Transaction, MAX(Subsidiary) Subsidiary FROM TransactionLine GROUP BY Transaction) TL ON TL.Transaction = TransactionAccountingLine.Transaction
						WHERE
						( Transaction.PostingPeriod BETWEEN ${soPer} AND ${epPer} ) 
						AND ( Transaction.Posting = 'T' )
						AND ( Account.AcctType IN ( 'Income', 'COGS', 'Expense', 'OthIncome' ) )
						AND (TL.Subsidiary = 2 )
						GROUP BY to_char(AccountingPeriod.StartDate, 'mm')  
						UNION
						SELECT GMFSDate, NetIncome FROM (
						SELECT 53 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 54 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 55 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 56 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 57 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 58 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 59 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 60 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 61 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 62 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 63 as GMFSDate, 0 as NetIncome
						UNION
						SELECT 64 as GMFSDate, 0 as NetIncome
						)) GROUP BY GMFSDate ORDER BY GMFSDate`;
					var pgOneNI = query.runSuiteQL({query: niSql}).asMappedResults(); 
					pgOneNI.forEach(function(result) {
						let valueItem = [];
						valueItem.push(result.netincome);
						niLines.push(valueItem);
						return true;
					});
					var ySql = `select a3.id, a3.startdate from accountingperiod a1
						right join accountingperiod a2 on a2.id = a1.parent
						right join accountingperiod a3 on a3.id = a2.parent
						where a1.id = ${ePer}`;
					var yPeriod = query.runSuiteQL({query: ySql}).asMappedResults();	
					var yPer = Number(yPeriod[0].id);
					var bsSearch = search.create({
					   type: "transaction",
					   filters:
					   [
						  ["accountingperiod.internalidnumber","lessthanorequalto",ePer], 
						  "AND", 
						  ["posting","is","T"], 
						  "AND", 
						  ["subsidiary","anyof",runLocations]
					   ],
					   columns:
					   [
						  search.createColumn({
							 name: "formulatext",
							 summary: "GROUP",
							 formula: "REGEXP_REPLACE({account.number},'[^0-9]+','')",
							 label: "Formula (Text)"
						  }),
						  search.createColumn({
							 name: "accounttype",
							 summary: "GROUP",
							 label: "Account Type"
						  }),
						  search.createColumn({
							 name: "account",
							 summary: "GROUP",
							 label: "Account"
						  }),
						  search.createColumn({
							 name: "amount",
							 summary: "SUM",
							 label: "Amount"
						  }),
						  search.createColumn({
							 name: "number",
							 join: "account",
							 summary: "GROUP",
							 label: "Number"
						  })
					   ]
					});
					var bsLines = [];
					bsSearch.run().each(function(result){
							let valueItem = [];
							valueItem.push(result.getValue(bsSearch.columns[0]));
							valueItem.push(result.getValue(bsSearch.columns[1]));
							valueItem.push(result.getText(bsSearch.columns[2]));
							valueItem.push(Number(result.getValue(bsSearch.columns[3])));
							valueItem.push(result.getValue(bsSearch.columns[4]));
							bsLines.push(valueItem);
					   return true;
					});
					console.log('Run', 'Balance Sheet');
					setTimeout(function() {self.setContentAppend('<br>Processing balance sheet')},2000);
					var isSearch = search.create({
					   type: "transaction",
					   filters:
					   [
						  ["accountingperiod.internalidnumber","between",sPer,ePer],
						  "AND", 
						  ["posting","is","T"], 
						  "AND", 
						  ["subsidiary","anyof",runLocations]
					   ],
					   columns:
					   [
						  search.createColumn({
							 name: "formulatext",
							 summary: "GROUP",
							 formula: "REGEXP_REPLACE({account.number},'[^0-9]+','')",
							 label: "Formula (Text)"
						  }),
						  search.createColumn({
							 name: "accounttype",
							 summary: "GROUP",
							 label: "Account Type"
						  }),
						  search.createColumn({
							 name: "account",
							 summary: "GROUP",
							 label: "Account"
						  }),
						  search.createColumn({
							 name: "amount",
							 summary: "SUM",
							 label: "Amount"
						  }),
						  search.createColumn({
							 name: "number",
							 join: "account",
							 summary: "GROUP",
							 label: "Number"
						  })
					   ]
					});
					var isLines = [];
					isSearch.run().each(function(result){
							let valueItem = [];
							valueItem.push(result.getValue(isSearch.columns[0]));
							valueItem.push(result.getValue(isSearch.columns[1]));
							valueItem.push(result.getText(isSearch.columns[2]));
							valueItem.push(Number(result.getValue(isSearch.columns[3])));
							valueItem.push(result.getValue(isSearch.columns[4]));
							isLines.push(valueItem);
					   return true;
					});
					console.log('Run', 'YTD Income Statement');
					setTimeout(function() {self.setContentAppend('<br>Processing YTD income statement')},2000);
					var ismSearch = search.create({
					   type: "transaction",
					   filters:
					   [
						  ["accountingperiod.internalidnumber","equalto",ePer],
						  "AND", 
						  ["posting","is","T"], 
						  "AND", 
						  ["subsidiary","anyof",runLocations]
					   ],
					   columns:
					   [
						  search.createColumn({
							 name: "formulatext",
							 summary: "GROUP",
							 formula: "REGEXP_REPLACE({account.number},'[^0-9]+','')",
							 label: "Formula (Text)"
						  }),
						  search.createColumn({
							 name: "accounttype",
							 summary: "GROUP",
							 label: "Account Type"
						  }),
						  search.createColumn({
							 name: "account",
							 summary: "GROUP",
							 label: "Account"
						  }),
						  search.createColumn({
							 name: "amount",
							 summary: "SUM",
							 label: "Amount"
						  }),
						  search.createColumn({
							 name: "number",
							 join: "account",
							 summary: "GROUP",
							 label: "Number"
						  })
					   ]
					});
					var ismLines = [];
					ismSearch.run().each(function(result){
							let valueItem = [];
							valueItem.push(result.getValue(ismSearch.columns[0]));
							valueItem.push(result.getValue(ismSearch.columns[1]));
							valueItem.push(result.getText(ismSearch.columns[2]));
							valueItem.push(Number(result.getValue(ismSearch.columns[3])));
							valueItem.push(result.getValue(ismSearch.columns[4]));
							ismLines.push(valueItem);
					   return true;
					});
					console.log('Run', 'MTD Income Statement');
					setTimeout(function() {self.setContentAppend('<br>Processing MTD income statement')},2000);
					var arSql = `SELECT  AccountSubsidiaryMap.subsidiary AS subsidiary,
						SUM( CASE WHEN ( TRUNC( TO_DATE('${endDate}','MM/DD/YYYY') ) - TO_DATE(TO_CHAR(Transaction.TranDate)) ) < 1 
						THEN COALESCE( TransactionAccountingLine.AmountUnpaid, 0 ) - COALESCE( TransactionAccountingLine.PaymentAmountUnused, 0 )
						ELSE 0 END ) AS Current,
						SUM( CASE WHEN ( TRUNC( TO_DATE('${endDate}','MM/DD/YYYY') ) - TO_DATE(TO_CHAR(Transaction.TranDate)) ) BETWEEN 1 AND 30 THEN 
						COALESCE( TransactionAccountingLine.AmountUnpaid, 0 ) - COALESCE( TransactionAccountingLine.PaymentAmountUnused, 0 )
						ELSE 0 END ) AS Balance30,
						SUM( CASE WHEN ( TRUNC( TO_DATE('${endDate}','MM/DD/YYYY') ) - TO_DATE(TO_CHAR(Transaction.TranDate)) ) BETWEEN 31 AND 60 THEN 
						COALESCE( TransactionAccountingLine.AmountUnpaid, 0 ) - COALESCE( TransactionAccountingLine.PaymentAmountUnused, 0 )
						ELSE 0 END ) AS Balance60,	
						SUM( CASE WHEN ( TRUNC( TO_DATE('${endDate}','MM/DD/YYYY') ) - TO_DATE(TO_CHAR(Transaction.TranDate)) ) BETWEEN 61 AND 90
						THEN COALESCE( TransactionAccountingLine.AmountUnpaid, 0 ) - COALESCE( TransactionAccountingLine.PaymentAmountUnused, 0 )
						ELSE 0 END ) AS Balance90,		
						SUM( CASE WHEN ( TRUNC( TO_DATE('${endDate}','MM/DD/YYYY') ) - TO_DATE(TO_CHAR(Transaction.TranDate)) ) > 90 THEN 
						COALESCE( TransactionAccountingLine.AmountUnpaid, 0 ) - COALESCE( TransactionAccountingLine.PaymentAmountUnused, 0 )
						ELSE 0 END ) AS Balance90Plus,		
						SUM ( COALESCE( TransactionAccountingLine.AmountUnpaid, 0 ) - COALESCE( TransactionAccountingLine.PaymentAmountUnused, 0 ) ) AS Total
						from Transaction
						INNER JOIN Customer on ( Customer.ID = Transaction.Entity )
						INNER JOIN TransactionAccountingLine ON ( TransactionAccountingLine.Transaction = Transaction.ID )
						INNER JOIN Account on ( Account.id = TransactionAccountingLine.account )
						INNER JOIN AccountSubsidiaryMap on (Account.id = AccountSubsidiaryMap.account)
						WHERE
						(Transaction.TranDate <= '${endDate}')
						AND ( Transaction.Posting = 'T' )
						AND ( Transaction.Voided = 'F' )
						and ((TransactionAccountingLine.AmountUnpaid <> 0 )
						OR ( TransactionAccountingLine.PaymentAmountUnused <> 0 ))
						AND (AccountSubsidiaryMap.subsidiary in ${arLocations})  GROUP BY AccountSubsidiaryMap.subsidiary`;
					try {
						var arData = {};
						var arLines = [];
						let ar = [];
							ar.push('subsidiary');
							ar.push('current');
							ar.push('balance30');
							ar.push('balance60');
							ar.push('balance90');
							ar.push('90plus');
							ar.push('total');
							arLines.push(ar);
						console.log('Run', 'Start AR');
						setTimeout(function() {self.setContentAppend('<br>Processing AR')},2000);
						var resultIterator = query.runSuiteQLPaged({
							query: arSql,
							pageSize: 1000,
							customScriptId: 'arSuiteQL'
						}).iterator()
						resultIterator.each(function(page) {
							var pageIterator = page.value.data.iterator();
							pageIterator.each(function(row) {
								arLines.push(row.value.values);
								return true;
							});
							return true;
						});
						console.log('Run', 'End AR Lines: ' + arLines.length);
						arData.values = arLines;		
					} catch(e) {		
						log.error('SuiteQL', e.message);
					}
					var page1 = xlsx.Sheets['Page1'];	
					XLSX.utils.sheet_add_aoa(page1, [[startMo, startDay, startYear]], {origin:{r:7, c:5}});
					XLSX.utils.sheet_add_aoa(page1, [[endMo, endDay, endYear]], {origin:{r:8, c:5}});
					XLSX.utils.sheet_add_aoa(page1, [[nPer]], {origin:{r:55, c:20}});
					var arpage = xlsx.Sheets['AR'];
					XLSX.utils.sheet_add_aoa(arpage, [arData.values], {origin: {r:1, c:1}});
					if (niLines.length > 0) {
						XLSX.utils.sheet_add_aoa(page1, [niLines], {origin: {r:53, c:14}});
					}
					var data1page = xlsx.Sheets['DATA1'];			
					var dataClear = [];
					for (var i = 0; i < bsLines.length + 100; i++) {
						var dataLine = [];
						dataClear.push(dataLine);
					}
					XLSX.utils.sheet_add_aoa(data1page, [dataClear], {origin: {r:1, c:1}});
					XLSX.utils.sheet_add_aoa(data1page, [bsLines], {origin: {r:1, c:1}});
					var data2page = xlsx.Sheets['DATA2'];			
					var dataClear = [];
					for (var i = 0; i < isLines.length + 100; i++) {
						var dataLine = [];
						dataClear.push(dataLine);
					}
					XLSX.utils.sheet_add_aoa(data2page, [dataClear], {origin: {r:1, c:1}});
					XLSX.utils.sheet_add_aoa(data2page, [isLines], {origin: {r:1, c:1}});
					var data3page = xlsx.Sheets['DATA3'];			
					var dataClear = [];
					for (var i = 0; i < ismLines.length + 100; i++) {
						var dataLine = [];
						dataClear.push(dataLine);
					}
					XLSX.utils.sheet_add_aoa(data3page, [dataClear], {origin: {r:1, c:1}});
					XLSX.utils.sheet_add_aoa(data3page, [ismLines], {origin: {r:1, c:1}});
					var newXlsx = XLSX.writeFile(xlsx, 'GMFS-'+startMo+'-'+startYear+'-to-'+endMo+'-'+endYear+'.xlsx',{bookSST:true});
					}
					else {
						setTimeout(function() {self.setContentAppend('<br>Error obtaining valid accounting period codes')},2000);
					}
				}
			});
		}
		
	}
		
	return {
		pageInit: pageInit,
		processInfo: processInfo
	};
});