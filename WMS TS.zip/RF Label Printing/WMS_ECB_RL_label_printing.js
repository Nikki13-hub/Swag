/**
 * Copyright (c) 1998-2018 Oracle-NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 * 
 * * Version    Date            Author           		Remarks
 *   1.00       Oct 18, 2018	Alexander Bordad		Initial Version
 *
 * 
 * @NApiVersion 2.x
 * @NScriptType Restlet
 *
 **/

define(['N/runtime','./WMS_ECB_RL_label_printing_lib.js'],
function(NS_Runtime,ecb_lab_print) {

	/* This function accepts requests to print labels */
	function post(context) {
		
		var stLogTitle = 'post';

		var objResult = {};

		try{

			log.debug(stLogTitle, ' ----  START  ---- ');
			log.debug(stLogTitle, context);
			var arrWmsPrintLbl		= context.wms_print_label;
			if(isEmpty(arrWmsPrintLbl.name) || isEmpty(context.recordType)){
				objResult.success = false;
				objResult.message = 'Missing script parameter(s).';
				objResult.request = context;

			}else{
				objResult = ecb_lab_print.post_wms_label_printing(arrWmsPrintLbl,context.recordType);
			}
			
			//log.debug(stLogTitle, 'sec: ' + (new Date() - startTime) / 1000 + ' rem units: ' + NS_Runtime.getCurrentScript().getRemainingUsage() + '/5000.');

		}catch(e){
			log.error(stLogTitle, e.message);
			objResult.success = false;
			objResult.message = e.message;
			objResult.request = context;
		}
		
		return objResult;
	}



	return {		
		post: post
	};
});


// This function returns true if the stValue is empty
function isEmpty(stValue) {
	if ((stValue == '') || (stValue == null) || (stValue == undefined)) {
		return true;
	}
	return false;
}