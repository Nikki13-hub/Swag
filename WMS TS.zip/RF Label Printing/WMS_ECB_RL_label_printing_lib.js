/**
 * Copyright (c) 1998-2018 Oracle-NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 * 
 * * Version    Date            Author           		Remarks
 *   1.00       Oct 18, 2018	Alexander Bordad		Initial Version
 *
 * 
 * @NApiVersion 2.x
 *
 **/

define(['N/record'],

	function(NS_record) {
	
          /* This function inserts a new WMS Label Printing record.  */
		function post_wms_label_printing(objRequest, recordType) {
			var stLogTitle = 'post_wms_label_printing';
			var objResult = {};
			objResult.inputData = objRequest;
			try{
				if(isEmpty(objRequest.name) || isEmpty(recordType)){
					objResult.success = false;
					objResult.message = 'Missing script parameter(s).';
					return objResult;
				}

				var arrRequest = Object.keys(objRequest);
				var newLblPrintRecord = NS_record.create({
			       type: recordType,
			       isDynamic: false                       
			   	});
				for(var i=0;i < arrRequest.length; i++){
					var lineId = arrRequest[i];
					var lineValue = objRequest[lineId];
					if(!isEmpty(lineValue)){
						if(lineId == 'custrecord_wmsse_label_data'){
							var lineValue = lineValue.replace(/'/g, '"');
						}
						newLblPrintRecord.setValue({
						    fieldId: lineId,
						    value: lineValue
						});
					}
				}
				var newRecordId = newLblPrintRecord.save();
				objResult.success = true;
				objResult.message = 'WMS Label printing created successfully';
				objResult.newRecordId = newRecordId;
				return objResult;
			}catch(error){
				objResult.success = false;
				objResult.message = error.message;
				return objResult;
			}
		}

   
    return {
        post_wms_label_printing: post_wms_label_printing
    };
    
});

// This function returns true if the stValue is empty
function isEmpty(stValue) {
	if ((stValue == '') || (stValue == null) || (stValue == undefined)) {
		return true;
	}
	return false;
}