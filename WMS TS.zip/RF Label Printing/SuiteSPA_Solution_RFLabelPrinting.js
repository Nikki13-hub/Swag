/**
 *  This is the JS FIle that contains the solution specific definition and functions.
 *  
 * To Do List...
 * - AK's templates from SS Account need to be moved back into WMS TS Dav and SKP's account.
 * - Remember Last Printer
 * - Remember Last Label Format
 * - Add code to block browser back button
 * - Conditionally show/skip a step (e.g. login)
 * - Add/remove spinner on potential long-running synchronous actions (search).
 * - Show selected data in more data section
 * - Conditional action item display (e.g. the login button)
 * - Add SuiteSearch Table Actions
 * - Add sorting table actions
 * - Back based on previous step (e.g all the lists call common print screen)
 * - Revise StoreDefault loading to be based on set keys 
 * - generic: Back to re-display (not refresh) previous step.
 * - Make Menu 100% dynamic and remove condition in setBody
 * - Make Body 100% dynamic
 *  
 * Changes 20181126 - Version 1.0:
 * - Removed Common from setSPASolutionDefaults
 * - added loader to searches
 * - added validateInput to searches
 * - added new recallLastValue: true property/behavior
 * - added recallLastValue: true to Printer and Label format on all 4 detail forms. 
 * 
 * Changes 20190121 - Version 1.1:
 * - Changed names of the hardcoded templates
 * Changes 20190121 - Version 1.1.1:
 * - Added new hardcoded templates
 * Changes 20190205 - Version 1.1.2
 * - Added new labeltype filter and datalist
 * 
 * Changes 20210531 - version ? - EC
 * - Updated workflows to include sorting and filtering in searchResults step.
 * - 
 * 
 * Changes 20210609 - version ? - EC
 * - Updated all workflows based on the After Receipt Labels workflow that Steve modified with:
 *      * removed summarization, added a table of selected results at the bottom of the "printXlabelsdetail" step.
 *      * added multiple label printing
 * 
 * Changes 20210622 - version ? - SRP & EC
 * - Updated all workflows with the following:
 *      * removed hyperlink on each row in the search results step to avoid inconsistent navigation when selecting rows to print (multiple vs single), now the user must select a single result via checkbox.
 *      * added logic to clear any selected rows when user navigates back into search step.
 *      * updated all steps with new validations to prevent user from:
 *          * navigating into search results step without entering any search criteria
 *          * navigating into label details step without selecting at least 1 row to print
 * 
 * 20220221 SRP
 * - Added SCM Printers datalist and input to all print detail pages in preparation for printing via Mobile Printing / PrintNode.
 * 
 */


addToArray(Store.defaults.firstActionsRemoteSPA, [], 'moveValueToEnd'); // These actions are executed before authentication. Typically these are not set in the solution file. 
addToArray(Store.defaults.firstActions, ['setSPASolutionDefaults_RFLabelPrinting', 'buildAllDatalists'], 'moveValueToEnd');

if (Store.debug) { console.log(indent() + 'Finished loading SuiteSPA Solution: RF Label Printing.') };

function setSPASolutionDefaults_RFLabelPrinting() {
    // Add the override settings to Store.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setSPASolutionDefaults: called.') };


    updateObjectProperties(Store.defaults, {
        title: 'Print Labels',
        getWMSLabelTemplate: { scriptID: 'customscript_wms_ts_get_wms_label_temp', deploymentID: '1' },
        postWMSLabelPrinting: { scriptID: 'customscript_wms_rl_ecb_label_printing', deploymentID: '1' },
        postInventoryMoveByLP: { scriptID: 'customscript_wmsecb_rl_invmove_service', deploymentID: '1' },
        postWMSLabels: { scriptID: 'customscript_wmsts_rl_file_create_print', deploymentID: '1'},
        labelsFolder: 'RFLP Labels'
    });


    //updateObjectProperties(Store.workflowSteps.workflowMenu, {
    Store.workflowSteps.RFLabelPrintingMenu = {
        name: "RFLabelPrintingMenu",
        title: 'Print Labels - Choose Label Type',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'closeTab' }],
        elements: [
            {
                type: 'section',
                typeAs: 'orderedList',
                name: 'RFLabelPrintingMenu',
                class: 'workflowForm',
                elements: [
                    { type: 'listItem', name: 'printItemLabelsSearch', label: 'Print Labels From Items ', action: 'printItemLabelsSearch' },
                    { type: 'listItem', name: 'printInventoryLabelsSearch', label: 'Print Labels From Inventory ', action: 'printInventoryLabelsSearch' },
                    { type: 'listItem', name: 'printBeforeReceiptLabelsSearch', label: 'Print Labels Before Receiving', action: 'printBeforeReceiptLabelsSearch' },
                    { type: 'listItem', name: 'printAfterReceiptLabelsSearch', label: 'Print Labels After Receiving', action: 'printAfterReceiptLabelsSearch' },
                    { type: 'listItem', name: 'printFordLabelsSearch', label: 'Print Ford Labels', action: 'printFordLabelsSearch' },
                    { type: 'listItem', name: 'printGMLabelsSearch', label: 'Print GM Labels', action: 'printGMLabelsSearch' }
                ]
            }
        ]
    }


    // Item Label Workflow Steps
    Store.workflowSteps.printItemLabelsSearch = {
        name: 'printItemLabelsSearch',
        title: 'Print Labels - Search Items to Print',
        tip: '<details><summary>Enter your search and tap Next...</summary><p>Enter some search criteria and tap next. This will search for the records to print.</p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: [
                    'showLoader',
                    'setWorkingInputValues',
                    'validateInput',
                    'validateForm',
                    'prepareSearchRequest',
                    ['getSearchResults',
                        'persistSearchResults',
                        'printItemLabelsSearchResults',
                        'clearLoader']]
            }
        ],
        searchRequest: {
            name: 'printItemLabelsSearch',
            searchID: 'customsearch_sswms_item_general',
            selectedResults: []
        },
        elements: [
            {
                type: 'section',
                name: 'printItemLabelsSearch',
                class: 'workflowForm',
                validations: [{ name: 'atLeastXRequired', minimumInputs: 1, inputNames: ['itemid', 'displayname', 'upccode'] }],
                elements: [
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'itemid',
                        label: 'Item Number'
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'displayname',
                        label: 'Display Name'
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'upccode',
                        label: 'UPC'
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printItemLabelsSearchResults = {
        name: 'printItemLabelsSearchResults',
        title: 'Print Labels - Item Search Results',
        tip: 'Tap any row you want to print',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'processActionArray', actions: ['printItemLabelsSearch', 'setWorkingInputValues'] },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            { name: 'print', label: 'Next', action: 'processActionArray', actions: ['validateForm', 'printItemLabelsDetail'] }
        ],
        searchRequest: Store.workflowSteps.printItemLabelsSearch.searchRequest,
        summarizationArray: [
            { targetProperty: 'itemListString', sourceProperty: 'itemid', summarizationType: 'listUniqueString' },
            { targetProperty: 'upcListString', sourceProperty: 'upccode', summarizationType: 'listUniqueString' },
            { targetProperty: 'displayNameListString', sourceProperty: 'displayname', summarizationType: 'listUniqueString' }
        ],
        itemsSummary: {},
        //singleResultAction: 'printItemLabelsDetail',
        elements: [
            {
                name: 'printItemLabelsSearchResults',
                type: 'searchResultsTable',
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                validations: [{ name: 'atLeastXResultsSelected', minimumSelectedResults: 1 }],
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: ['itemid', 'displayname', 'salesdescription'],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                elements: [
                    {
                        type: 'rowSelector',
                        name: 'rowSelected',
                        label: '☐',
                        labelAction: 'selectAllAndSummarize',
                        action: 'selectAndSummarize'
                    },
                    {
                        label: 'Item Name',
                        name: 'itemid',
                        type: 'searchResultsTableColumn',
                        filter: true,
                        labelAction: 'sortTable'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "displayname",
                        label: "Display Name",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "upccode",
                        label: "UPC",
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printItemLabelsDetail = {
        name: 'printItemLabelsDetail',
        title: 'Print Labels - Print Item Labels Detail',
        tip: '<details><summary>Choose the Printer, Enter the number of copies, and Tap Next...</summary><p>This will send your labels to be printed on the printer you select. <br> Please Note: this my take 30 seconds or more before the printer will print them. </p></details>',
        //labelTemplateName: 'SS WMS ITEM LABEL (4x6)',
        //labelTemplateID: '101',
        searchRequest: Store.workflowSteps.printItemLabelsSearch.searchRequest,
        searchRequestSelected: { searchResultFlat: Store.workflowSteps.printItemLabelsSearch.searchRequest.selectedResults },
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printItemLabelsSearchResults' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Print', action: 'processActionArray',
                actions: ['setWorkingInputValues', 'validateInput', 'printMultipleLabels', 'RFLabelPrintingMenu']
                /*actions: [ 
                    'setWorkingInputValues', 
                    'validateInput', 
                    'labelPreparePost', 
                    'mergeTemplateAndData', 
                    'postWMSLabelPrinting', // note, this is an async process, but no need to wait for the process. 
                    'RFLabelPrintingMenu']*/
            }
        ],
        elements: [
            {
                type: 'section',
                name: 'printItemLabelsDetail',
                class: 'workflowForm',
                elements: [
                    /*{
                        type: 'input',
                        name: 'selectedItem',
                        label: 'Selected Item',
                        valueDefaultProperty: 'itemid',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedUPC',
                        label: 'Selected UPC',
                        valueDefaultProperty: 'upccode',
                        visibility: 'readonly'
                    },*/
                    {
                        type: 'input',
                        typeAs: 'number',
                        name: 'labelCount',
                        min: 1,
                        max: 1000,
                        label: 'Number of Labels',
                        valueDefault: '1',
                        //validations: [['required'], ['integer'], ['min'], ['max'], ['step'], ['maxlength'], ['pattern']]
                        validations: [{ name: 'required' }, { name: 'integer' }, { name: 'min' }, { name: 'max' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'SCMPrinter',
                        label: 'SCM Printer',
                        recallLastValue: true,
                        datalistSource: 'SCMPrinters',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    },
                    // {
                    //     type: 'input',
                    //     typeAs: 'search',
                    //     name: 'SCMPrinter', 
                    //     label: 'SCM Printer',
                    //     recallLastValue: true,
                    //     datalistSource: 'SCMPrinters',
                    //     validations: [{ name:'required'}, { name:'inDatalist', propertyName: 'name' }]
                    // },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'labelTemplate',
                        label: 'Choose Format',
                        recallLastValue: true,
                        //datalistValues: ['SS WMS ITEM Only LABEL (4x6)'],
                        //datalistValues: ['Item Label (2x3)', 'Item Label (4x6)', 'Item Pallet Label (4x6)'],
                        datalistSource: 'WMSLabelTemplatesItem',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    }
                ]
            }
            ,
            {
                type: 'searchResultsTable',
                name: 'printItemLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                searchRequestToUse: 'searchRequestSelected',
                elements: [
                    //{ 
                    //    type: 'rowSelector', 
                    //    name: 'rowSelected', 
                    //    label: '☐', 
                    //    labelAction: 'selectAllAndSummarize', 
                    //    action: 'selectAndSummarize' 
                    //},
                    {
                        label: 'Item Name',
                        name: 'itemid',
                        type: 'searchResultsTableColumn',
                        filter: true,
                        labelAction: 'sortTable'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "displayname",
                        label: "Display Name",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "upccode",
                        label: "UPC",
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };




    // Inventory Label Workflow Steps
    Store.workflowSteps.printInventoryLabelsSearch = {
        name: 'printInventoryLabelsSearch',
        title: 'Print Labels - Search Inventory to Print',
        tip: '<details><summary>Enter your search and tap Next...</summary><p>Enter some search criteria and tap next. This will search for the records to print.</p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: [
                    'showLoader',
                    'setWorkingInputValues',
                    'validateInput',
                    'validateForm',
                    'prepareSearchRequest', [
                        'getSearchResults',
                        'persistSearchResults',
                        'printInventoryLabelsSearchResults',
                        'clearLoader']]
            }
        ],
        searchRequest: {
            name: 'printInventoryLabelsSearch',
            searchRecordType: 'InventoryBalance',
            searchID: 'customsearch_wmsts_inv_bal_general',
            searchRequestFilters: [
                ['location', 'is', Store.queryParameters.custparam_whlocation]
            ],
            selectedResults: [],
            searchResultFlat: []
        },
        elements: [
            {
                type: 'section',
                name: 'printInventoryLabelsSearch',
                class: 'workflowForm',
                validations: [{ name: 'atLeastXRequired', minimumInputs: 1, inputNames: ['item.itemid', 'item.upccode', 'inventoryNumber', 'binnumber'] }],
                elements: [
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'item.itemid',
                        label: 'Item Number'
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'item.upccode',
                        label: 'UPC #'
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'inventoryNumber',
                        label: 'Lot/Serial #',
                        filterFieldTreatment: ['formulatext: {', '}']
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        //name: 'inventoryNumberBinOnHand.binnumber',
                        name: 'binnumber',
                        label: 'Bin',
                        filterFieldTreatment: ['formulatext: {', '}']
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printInventoryLabelsSearchResults = {
        name: 'printInventoryLabelsSearchResults',
        title: 'Print Labels - Inventory Search Results',
        tip: 'Tap any row you want to print',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printInventoryLabelsSearch' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            { name: 'print', label: 'Next', action: 'processActionArray', actions: ['validateForm', 'printInventoryLabelsDetail'] }
        ],
        searchRequest: Store.workflowSteps.printInventoryLabelsSearch.searchRequest,
        summarizationArray: [
            { targetProperty: 'itemListString', sourceProperty: 'item.itemid', summarizationType: 'listUniqueString' },
            { targetProperty: 'upcListString', sourceProperty: 'item.upccode', summarizationType: 'listUniqueString' },
            { targetProperty: 'inventoryNumberListString', sourceProperty: 'inventoryNumber', summarizationType: 'listUniqueString' }],
        itemsSummary: {},
        elements: [
            {
                name: 'printInventoryLabelsSearchResults',
                type: 'searchResultsTable',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: ['itemid', 'displayname', 'salesdescription'],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                validations: [{ name: 'atLeastXResultsSelected', minimumSelectedResults: 1 }],
                hideIfEmpty: false,
                elements: [
                    {
                        type: 'rowSelector',
                        name: 'rowSelected',
                        label: '☐',
                        labelAction: 'selectAllAndSummarize',
                        action: 'selectAndSummarize'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'binnumber',
                        label: 'Bin #',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'item',
                        label: 'Item Name',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.upccode",
                        label: "UPC",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "inventorynumber",
                        label: "Lot/Serial #",
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printInventoryLabelsDetail = {
        name: 'printInventoryLabelsDetail',
        title: 'Print Labels - Print Inventory Labels Detail',
        tip: '<details><summary>Choose the Printer, Enter the number of copies, and Tap Next...</summary><p>This will send your labels to be printed on the printer you select. <br> Please Note: this my take 30 seconds or more before the printer will print them. </p></details>',
        labelTemplateName: 'Item Label (4x6)',
        labelTemplateID: '101',
        searchRequest: Store.workflowSteps.printInventoryLabelsSearch.searchRequest,
        searchRequestSelected: { searchResultFlat: Store.workflowSteps.printInventoryLabelsSearch.searchRequest.selectedResults },
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printInventoryLabelsSearchResults' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Print', action: 'processActionArray',
                //actions: ['setWorkingInputValues', 'validateInput', 'labelPreparePost', 'mergeTemplateAndData', 'postWMSLabelPrinting', 'RFLabelPrintingMenu']
                actions: ['setWorkingInputValues', 'validateInput', 'printMultipleLabels', 'RFLabelPrintingMenu']
            }
        ],
        elements: [
            {
                type: 'section',
                name: 'printInventoryLabelsDetail',
                class: 'workflowForm',
                elements: [
                    /*{
                        type: 'input',
                        name: 'selectedItem',
                        label: 'Selected Item',
                        valueDefaultProperty: 'itemid',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedUPC',
                        valueDefaultProperty: 'upccode',
                        label: 'Selected UPC',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedInvNum',
                        valueDefaultProperty: 'inventoryNumber.inventorynumber',
                        label: 'Selected Inv #',
                        visibility: 'readonly'
                    },*/
                    {
                        type: 'input',
                        typeAs: 'number',
                        name: 'labelCount',
                        min: 1,
                        max: 1000,
                        label: 'Number of Labels',
                        valueDefault: '1',
                        //validations: [['required'], ['integer'], ['min'], ['max'], ['step'], ['maxlength'], ['pattern']]
                        validations: [{ name: 'required' }, { name: 'integer' }, { name: 'min' }, { name: 'max' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'SCMPrinter',
                        label: 'SCM Printer',
                        recallLastValue: true,
                        datalistSource: 'SCMPrinters',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    },
                    // {
                    //     type: 'input',
                    //     typeAs: 'search',
                    //     name: 'SCMPrinter', 
                    //     label: 'SCM Printer',
                    //     recallLastValue: true,
                    //     datalistSource: 'SCMPrinters',
                    //     validations: [{ name:'required'}, { name:'inDatalist', propertyName: 'name' }]
                    // },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'labelTemplate',
                        label: 'Choose Format',
                        recallLastValue: true,
                        //datalistValues: ['SS WMS ITEM LABEL (4x6)', 'SS WMS ITEM LABEL (2x3)'],
                        //datalistValues: ['Item with Lot/Serial (2x3)', 'Item with Lot/Serial (4x6)', 'Item Pallet Label (4x6)', 'Item Pallet with Lot/Serial Label (4x6)', 'Inventory Item (2x3)', 'Inventory Item (4x6)'],
                        datalistSource: 'WMSLabelTemplatesInventory',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    }
                ]
            },
            {
                type: 'searchResultsTable',
                name: 'printInventoryLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                searchRequestToUse: 'searchRequestSelected',
                elements: [
                    //{ 
                    //    type: 'rowSelector', 
                    //    name: 'rowSelected', 
                    //    label: '☐', 
                    //    labelAction: 'selectAllAndSummarize', 
                    //    action: 'selectAndSummarize' 
                    //},
                    {
                        type: 'searchResultsTableColumn',
                        name: 'binnumber',
                        label: 'Bin #',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'item',
                        label: 'Item Name',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "inventorynumber",
                        label: "Lot/Serial #",
                        //action: 'printAfterReceiptLabelsDetail',
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };



    // Before Receipt Label Workflow Steps
    Store.workflowSteps.printBeforeReceiptLabelsSearch = {
        name: 'printBeforeReceiptLabelsSearch',
        title: 'Print Labels - Search for Order Items',
        tip: '<details><summary>Enter your search and tap Next...</summary><p>Enter some search criteria and tap next. This will search for the records to print.</p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: [
                    'showLoader',
                    'setWorkingInputValues',
                    'validateInput',
                    'validateForm',
                    'prepareSearchRequest', [
                        'getSearchResults',
                        'persistSearchResults',
                        'printBeforeReceiptLabelsSearchResults',
                        'clearLoader']]
            }
        ],
        searchRequest: {
            name: 'printBeforeReceiptLabelsSearch',
            searchID: 'customsearch_sswms_pallet_prereceipt',
            selectedResults: []
        },
        elements: [
            {
                type: 'section',
                name: 'printBeforeReceiptLabelsSearch',
                class: 'workflowForm',
                validations: [{ name: 'atLeastXRequired', minimumInputs: 1, inputNames: ['tranid', 'item'] }],
                elements: [
                    {
                        type: 'input', typeAs: 'search', name: 'tranid', label: 'Order Number',
                        filterFieldTreatment: ['formulatext: {', '}']
                    },
                    {
                        type: 'input', typeAs: 'search', name: 'item', label: 'Item Number',
                        filterFieldTreatment: ['formulatext: {', '}']
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printBeforeReceiptLabelsSearchResults = {
        name: 'printBeforeReceiptLabelsSearchResults',
        title: 'Print Labels - Receipt Search Results',
        tip: 'Tap any row you want to print',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printBeforeReceiptLabelsSearch' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            { name: 'print', label: 'Next', action: 'processActionArray', actions: ['validateForm', 'printBeforeReceiptLabelsDetail'] }
        ],
        searchRequest: Store.workflowSteps.printBeforeReceiptLabelsSearch.searchRequest,
        summarizationArray: [
            { targetProperty: 'itemListString', sourceProperty: 'item', summarizationType: 'listUniqueString' },
            { targetProperty: 'upcListString', sourceProperty: 'item.upccode', summarizationType: 'listUniqueString' }
            /*,{targetProperty: 'inventoryNumberListString', sourceProperty: 'formulatext', summarizationType: 'listUniqueString'}*/
        ],
        itemsSummary: {},
        elements: [
            {
                type: 'searchResultsTable',
                name: 'printBeforeReceiptLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                validations: [{ name: 'atLeastXResultsSelected', minimumSelectedResults: 1 }],
                elements: [
                    {
                        type: 'rowSelector',
                        name: 'rowSelected',
                        label: '☐',
                        labelAction: 'selectAllAndSummarize',
                        action: 'selectAndSummarize'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'tranid',
                        label: 'Order',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item",
                        label: "Item",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.displayname",
                        label: "Display Name",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.upccode",
                        label: "UPC",
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printBeforeReceiptLabelsDetail = {
        name: 'printBeforeReceiptLabelsDetail',
        title: 'Print Labels - Print Post Receiving Labels Detail',
        tip: '<details><summary>Choose the Printer, Enter the number of copies, and Tap Next...</summary><p>This will send your labels to be printed on the printer you select. <br> Please Note: this my take 30 seconds or more before the printer will print them. </p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printBeforeReceiptLabelsSearchResults' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Print', action: 'processActionArray',
                //actions: ['setWorkingInputValues', 'validateInput', 'labelPreparePost', 'mergeTemplateAndData', 'postWMSLabelPrinting', 'RFLabelPrintingMenu']
                actions: ['setWorkingInputValues', 'validateInput', 'printMultipleLabels', 'RFLabelPrintingMenu']
            }
        ],
        searchRequest: Store.workflowSteps.printBeforeReceiptLabelsSearch.searchRequest,
        searchRequestSelected: { searchResultFlat: Store.workflowSteps.printBeforeReceiptLabelsSearch.searchRequest.selectedResults },
        elements: [
            {
                type: 'section',
                name: 'printBeforeReceiptLabelsDetail',
                class: 'workflowForm',
                elements: [
                    /*{
                        type: 'input',
                        name: 'selectedItem',
                        label: 'Selected Item',
                        valueDefaultProperty: 'item',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedUPC',
                        valueDefaultProperty: 'item.upccode',
                        label: 'Selected UPC',
                        visibility: 'readonly'
                    },*/
                    {
                        type: 'input',
                        typeAs: 'number',
                        name: 'labelCount',
                        min: 1,
                        max: 1000,
                        label: 'Number of Labels',
                        valueDefault: '1',
                        //validations: [['required'], ['integer'], ['min'], ['max'], ['step'], ['maxlength'], ['pattern']]
                        validations: [{ name: 'required' }, { name: 'integer' }, { name: 'min' }, { name: 'max' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'SCMPrinter',
                        label: 'SCM Printer',
                        recallLastValue: true,
                        datalistSource: 'SCMPrinters',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    },
                    // {
                    //     type: 'input',
                    //     typeAs: 'search',
                    //     name: 'SCMPrinter', 
                    //     label: 'SCM Printer',
                    //     recallLastValue: true,
                    //     datalistSource: 'SCMPrinters',
                    //     validations: [{ name:'required'}, { name:'inDatalist', propertyName: 'name' }]
                    // },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'labelTemplate',
                        label: 'Choose Format',
                        recallLastValue: true,
                        //datalistValues: ['SS WMS PO ITEM LABEL (4x6)', 'SS WMS PO ITEM LABEL (2x3)', 'SS WMS PALLET LABEL (4x6)'],
                        //datalistValues: ['Receiving Item Label (2x3)','Receiving Item Label (4x6)','Pre Receiving Pallet Label (4x6)'],
                        datalistSource: 'WMSLabelTemplatesBeforeReceipt',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    }
                ]
            },
            {
                type: 'searchResultsTable',
                name: 'printBeforeReceiptLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                searchRequestToUse: 'searchRequestSelected',
                elements: [
                    //{ 
                    //    type: 'rowSelector', 
                    //    name: 'rowSelected', 
                    //    label: '☐', 
                    //    labelAction: 'selectAllAndSummarize', 
                    //    action: 'selectAndSummarize' 
                    //},
                    {
                        type: 'searchResultsTableColumn',
                        name: 'tranid',
                        label: 'Order',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'item',
                        label: 'Item',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.displayname",
                        label: "Display Name",
                        //action: 'printAfterReceiptLabelsDetail', 
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.upccode",
                        label: "UPC",
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ],
        moreDataElements: [
            { note: 'this section will be to display a grid/form of the selected row to be printed.' }
        ]
    };



    // After Receipt Label Workflow Steps
    Store.workflowSteps.printAfterReceiptLabelsSearch = {
        name: 'printAfterReceiptLabelsSearch',
        title: 'Print Labels - Search Receipts to Print',
        tip: '<details><summary>Enter your search and tap Next...</summary><p>Enter some search criteria and tap next. This will search for the records to print.</p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: [
                    'showLoader',
                    'setWorkingInputValues',
                    'validateInput',
                    'validateForm',
                    'prepareSearchRequest',
                    ['getSearchResults',
                        'persistSearchResults',
                        'printAfterReceiptLabelsSearchResults',
                        'clearLoader']]
            }
        ],
        searchRequest: {
            name: 'printAfterReceiptLabelsSearch',
            searchID: 'customsearch_sswms_pallet_postreceipt',
            selectedResults: [],
            searchRequestFilters_Additional: [["mainline", "is", "F"], 'and', ["type", "anyof", "ItemRcpt"]]
        },
        elements: [
            {
                type: 'section',
                name: 'printAfterReceiptLabelsSearch',
                class: 'workflowForm',
                validations: [{ name: 'atLeastXRequired', minimumInputs: 1, inputNames: ['createdfrom', 'trandate', 'item', 'inventoryDetail.inventorynumber'] }],
                elements: [
                    {
                        type: 'input', typeAs: 'search', name: 'createdfrom', label: 'Order Number',
                        filterOperator: 'contains',
                        filterFieldTreatment: ['formulatext: {', '}']
                    },
                    {
                        type: 'input', typeAs: 'date', name: 'trandate', label: 'Receipt Date',
                        filterOperator: 'on',
                        filterValueTreatment: 'dateToUsEn'
                    },
                    {
                        type: 'input', typeAs: 'search', name: 'item', label: 'Item Number',
                        filterFieldTreatment: ['formulatext: {', '}']
                    },
                    {
                        type: 'input', typeAs: 'search', name: 'inventoryDetail.inventorynumber', label: 'Lot/Serial #',
                        filterFieldTreatment: ['formulatext: {', '}']
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printAfterReceiptLabelsSearchResults = {
        name: 'printAfterReceiptLabelsSearchResults',
        title: 'Print Labels - Receipt Search Results',
        tip: 'Tap any row you want to print',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printAfterReceiptLabelsSearch' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            {
                name: 'print', label: 'Next',
                action: 'processActionArray', actions: ['validateForm', 'printAfterReceiptLabelsDetail']
            }
        ],
        searchRequest: Store.workflowSteps.printAfterReceiptLabelsSearch.searchRequest,
        summarizationArray: [
            { targetProperty: 'itemListString', sourceProperty: 'item', summarizationType: 'listUniqueString' },
            { targetProperty: 'upcListString', sourceProperty: 'item.upccode', summarizationType: 'listUniqueString' },
            { targetProperty: 'inventoryNumberListString', sourceProperty: 'formulatext', summarizationType: 'listUniqueString' }],
        itemsSummary: {},
        elements: [
            {
                type: 'searchResultsTable',
                name: 'printAfterReceiptLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                validations: [{ name: 'atLeastXResultsSelected', minimumSelectedResults: 1 }],
                elements: [
                    {
                        type: 'rowSelector',
                        name: 'rowSelected',
                        label: '☐',
                        labelAction: 'selectAllAndSummarize',
                        action: 'selectAndSummarize'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'createdfrom',
                        label: 'Order',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'trandate',
                        label: 'Received',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item",
                        label: "Item",
                        //action: 'printAfterReceiptLabelsDetail', 
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.displayname",
                        label: "Item Display Name",
                        //action: 'printAfterReceiptLabelsDetail', 
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.upccode",
                        label: "UPC",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "formulatext",
                        label: "Lot/SN #",
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printAfterReceiptLabelsDetail = {
        name: 'printAfterReceiptLabelsDetail',
        title: 'Print Labels - Print Post Receiving Labels Detail',
        tip: '<details><summary>Choose the Printer, Enter the number of copies, and Tap Next...</summary><p>This will send your labels to be printed on the printer you select. <br> Please Note: this my take 30 seconds or more before the printer will print them. </p></details>',
        searchRequest: Store.workflowSteps.printAfterReceiptLabelsSearch.searchRequest,
        searchRequestSelected: { searchResultFlat: Store.workflowSteps.printAfterReceiptLabelsSearch.searchRequest.selectedResults },
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printAfterReceiptLabelsSearchResults' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Print', action: 'processActionArray',
                //actions: ['setWorkingInputValues', 'validateInput', 'labelPreparePost', 'mergeTemplateAndData', 'postWMSLabelPrinting', 'RFLabelPrintingMenu']
                actions: ['setWorkingInputValues', 'validateInput', 'printMultipleLabels', 'RFLabelPrintingMenu']
            }
        ],
        elements: [
            {
                type: 'section',
                name: 'printAfterReceiptLabelsDetail',
                class: 'workflowForm',
                elements: [
                    /* {
                        type: 'input',
                        name: 'selectedItem',
                        label: 'Selected Item',
                        valueDefaultProperty: 'itemListString',
                        valueDefaultObject: 'Store.workflowSteps.printAfterReceiptLabelsSearchResults.itemsSummary',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedUPC',
                        valueDefaultProperty: 'upcListString',                        
                        valueDefaultObject: 'Store.workflowSteps.printAfterReceiptLabelsSearchResults.itemsSummary',
                        label: 'Selected UPC',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedInvNum',
                        valueDefaultProperty: 'inventoryNumberListString',
                        valueDefaultObject: 'Store.workflowSteps.printAfterReceiptLabelsSearchResults.itemsSummary',
                        //valueDefaultProperty: 'GROUP(inventoryDetail.inventorynumber)',
                        label: 'Selected Inv #',
                        visibility: 'readonly'
                    }, */
                    {
                        type: 'input',
                        typeAs: 'number',
                        name: 'labelCount',
                        min: 1,
                        max: 1000,
                        label: 'Number of Labels',
                        valueDefault: '1',
                        //validations: [['required'], ['integer'], ['min'], ['max'], ['step'], ['maxlength'], ['pattern']]
                        validations: [{ name: 'required' }, { name: 'integer' }, { name: 'min' }, { name: 'max' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'SCMPrinter',
                        label: 'SCM Printer',
                        recallLastValue: true,
                        datalistSource: 'SCMPrinters',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    },
                    // {
                    //     type: 'input',
                    //     typeAs: 'search',
                    //     name: 'SCMPrinter', 
                    //     label: 'SCM Printer',
                    //     recallLastValue: true,
                    //     datalistSource: 'SCMPrinters',
                    //     validations: [{ name:'required'}, { name:'inDatalist', propertyName: 'name' }]
                    // },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'labelTemplate',
                        label: 'Choose Format',
                        recallLastValue: true,
                        // datalistValues: ['SS WMS PO ITEM LABEL (4x6)', 'SS WMS PO ITEM LABEL (2x3)', 'SS WMS PALLET LABEL (4x6)'],
                        //datalistValues: ['Receiving Label with Lot/Serial (2x3)', 'Receiving Label with Lot/Serial (4x6)', 'Pallet Label with Lot/Serial (4x6)', 'Receiving Pallet Label (4x6)', 'Receiving Inventory Item (2x3)', 'Receiving Inventory Item (4x6)'],
                        datalistSource: 'WMSLabelTemplatesAfterReceipt',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    }
                ]
            },
            {
                type: 'searchResultsTable',
                name: 'printAfterReceiptLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                searchRequestToUse: 'searchRequestSelected',
                elements: [
                    //{ 
                    //    type: 'rowSelector', 
                    //    name: 'rowSelected', 
                    //    label: '☐', 
                    //    labelAction: 'selectAllAndSummarize', 
                    //    action: 'selectAndSummarize' 
                    //},
                    {
                        type: 'searchResultsTableColumn',
                        name: 'createdfrom',
                        label: 'Order',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'trandate',
                        label: 'Received',
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item",
                        label: "Item",
                        //action: 'printAfterReceiptLabelsDetail', 
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.displayname",
                        label: "Item Display Name",
                        //action: 'printAfterReceiptLabelsDetail', 
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.upccode",
                        label: "UPC",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "formulatext",
                        label: "Lot/SN #",
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };


    // Ford Label Workflow Steps
    Store.workflowSteps.printFordLabelsSearch = {
        name: 'printFordLabelsSearch',
        title: 'Print Ford Labels - Search for Waved Orders',
        tip: '<details><summary>Enter your search and tap Next...</summary><p>Enter some search criteria and tap next. This will search for the records to print.</p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: [
                    'showLoader',
                    'setWorkingInputValues',
                    'validateInput',
                    'validateForm',
                    'prepareSearchRequest', [
                        'getSearchResults',
                        'persistSearchResults',
                        'printFordLabelsSearchResults',
                        'clearLoader']]
            }
        ],
        searchRequest: {
            name: 'printFordLabelsSearch',
            searchID: 'customsearch_sswms_custom_labels',
            searchRequestFilters_Additional: ["location","anyof","24","5","6","7"],
            selectedResults: []
        },
        elements: [
            {
                type: 'section',
                name: 'printFordLabelsSearch',
                class: 'workflowForm',
                validations: [ { name: 'atLeastXRequired', minimumInputs: 1 , inputNames: ['wavename', 'status'] } ],
                elements: [
                    {
                        type: 'input', typeAs: 'search', name: 'wavename', label: 'Wave',
                        filterOperator: 'is',
                        filterFieldTreatment: ['formulatext: {', '}']
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'status',
                        label: 'Pick Status',
                        datalistSource: 'pickStatus',
                        recallLastValue: true,
                        filterOperator: 'anyof',
                        validations: [{ name:'inDatalist', propertyName: 'pickStatusCode' }]
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printFordLabelsSearchResults = {
        name: 'printFordLabelsSearchResults',
        title: 'Print Ford Labels - Waved Orders Search Results',
        tip: 'Tap any row you want to print',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printFordLabelsSearch' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            { name: 'print', label: 'Next', action: 'processActionArray', actions: ['validateForm', 'printFordLabelsDetail'] }
        ],
        searchRequest: Store.workflowSteps.printFordLabelsSearch.searchRequest,
        summarizationArray: [
            {targetProperty: 'itemListString', sourceProperty: 'item.itemid', summarizationType: 'listUniqueString'},
            //{targetProperty: 'upcListString', sourceProperty: 'item.upccode', summarizationType: 'listUniqueString'}
            /*,{targetProperty: 'inventoryNumberListString', sourceProperty: 'formulatext', summarizationType: 'listUniqueString'}*/
        ],
        itemsSummary : {},
        elements: [
            {
                type: 'searchResultsTable',
                name: 'printFordLabelsSearch',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                validations: [{ name: 'atLeastXResultsSelected', minimumSelectedResults: 1 }],
                elements: [
                    {
                        type: 'rowSelector',
                        name: 'rowSelected',
                        label: '☐',
                        labelAction: 'selectAllAndSummarize',
                        action: 'selectAndSummarize'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.tranid',
                        label: 'Order #' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.trandate',
                        label: 'Order Date' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.itemid",
                        label: "Item",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.salesdescription",
                        label: "Item Description" ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "formulatext",
                        label: "VIN #" ,
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printFordLabelsDetail = {
        name: 'printFordLabelsDetail',
        title: 'Print Labels - Print Ford Labels Detail',
        tip: '<details><summary>Choose the Printer, Enter the number of copies, and Tap Next...</summary><p>This will send your labels to be printed on the printer you select. <br> Please Note: this my take 30 seconds or more before the printer will print them. </p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printFordLabelsSearchResults' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Print', action: 'processActionArray',
                //actions: ['setWorkingInputValues', 'validateInput', 'labelPreparePost', 'mergeTemplateAndData', 'postWMSLabelPrinting', 'RFLabelPrintingMenu']
                actions:  ['setWorkingInputValues', 'validateInput', 'printMultipleLabels', 'RFLabelPrintingMenu']
            }
        ],
        searchRequest: Store.workflowSteps.printFordLabelsSearch.searchRequest,
        searchRequestSelected: { searchResultFlat: Store.workflowSteps.printFordLabelsSearch.searchRequest.selectedResults },
        elements: [
            {
                type: 'section',
                name: 'printFordLabelsDetail',
                class: 'workflowForm',
                elements: [
                    /*{
                        type: 'input',
                        name: 'selectedItem',
                        label: 'Selected Item',
                        valueDefaultProperty: 'item',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedUPC',
                        valueDefaultProperty: 'item.upccode',
                        label: 'Selected UPC',
                        visibility: 'readonly'
                    },*/
                    {
                        type: 'input',
                        typeAs: 'number',
                        name: 'labelCount',
                        min: 1,
                        max: 1000,
                        label: 'Number of Labels',
                        valueDefault: '1',
                        //validations: [['required'], ['integer'], ['min'], ['max'], ['step'], ['maxlength'], ['pattern']]
                        validations: [{ name:'required'}, { name: 'integer' }, { name: 'min' }, { name: 'max' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'SCMPrinter',
                        label: 'SCM Printer',
                        recallLastValue: true,
                        datalistSource: 'SCMPrinters',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'labelTemplate',
                        label: 'Choose Format',
                        recallLastValue: true,
                        //datalistValues: ['SS WMS PO ITEM LABEL (4x6)', 'SS WMS PO ITEM LABEL (2x3)', 'SS WMS PALLET LABEL (4x6)'],
                        //datalistValues: ['Receiving Item Label (2x3)','Receiving Item Label (4x6)','Pre Receiving Pallet Label (4x6)'],
                        datalistSource: 'WMSLabelTemplatesFord',
                        validations: [{ name:'required'}, { name:'inDatalist', propertyName: 'name' }]
                    }
                ]
            },
            {
                type: 'searchResultsTable',
                name: 'printFordLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                searchRequestToUse: 'searchRequestSelected',
                elements: [
                    {
                        type: 'rowSelector',
                        name: 'rowSelected',
                        label: '☐',
                        labelAction: 'selectAllAndSummarize',
                        action: 'selectAndSummarize'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.tranid',
                        label: 'Order #' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.trandate',
                        label: 'Order Date' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.itemid",
                        label: "Item",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.salesdescription",
                        label: "Item Description" ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "formulatext",
                        label: "VIN #" ,
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ],
        moreDataElements: [
            { note: 'this section will be to display a grid/form of the selected row to be printed.' }
        ]
    };


    // GM Label Workflow Steps
    Store.workflowSteps.printGMLabelsSearch = {
        name: 'printGMLabelsSearch',
        title: 'Print GM Labels - Search Waved Orders',
        tip: '<details><summary>Enter your search and tap Next...</summary><p>Enter some search criteria and tap next. This will search for the records to print.</p></details>',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: [
                    'showLoader',
                    'setWorkingInputValues',
                    'validateInput',
                    'validateForm',
                    'prepareSearchRequest',
                    ['getSearchResults',
                        'persistSearchResults',
                        'printGMLabelsSearchResults',
                        'clearLoader']]
            }
        ],
        searchRequest: {
            name: 'printGMLabelsSearch',
            searchID: 'customsearch_sswms_custom_labels',
            selectedResults: [],
            searchRequestFilters_Additional: ["location","anyof","13","8"]
        },
        elements: [
            {
                type: 'section',
                name: 'printGMLabelsSearch',
                class: 'workflowForm',
                validations: [ { name: 'atLeastXRequired', minimumInputs: 1 , inputNames: ['wavename', 'status'] } ],
                elements: [
                    {
                        type: 'input', typeAs: 'search', name: 'wavename', label: 'Wave',
                        filterOperator: 'is',
                        filterFieldTreatment: ['formulatext: {', '}']
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'status',
                        label: 'Pick Status',
                        datalistSource: 'pickStatus',
                        recallLastValue: true,
                        filterOperator: 'anyof',
                        validations: [{ name:'inDatalist', propertyName: 'pickStatusCode' }]
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printGMLabelsSearchResults = {
        name: 'printGMLabelsSearchResults',
        title: 'Print GM Labels - Waved Orders Search Results',
        tip: 'Tap any row you want to print',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printGMLabelsSearch' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            { name: 'print', label: 'Next',
                action: 'processActionArray', actions: ['validateForm', 'printGMLabelsDetail'] }
        ],
        searchRequest: Store.workflowSteps.printGMLabelsSearch.searchRequest,
        summarizationArray: [
            {targetProperty: 'itemListString', sourceProperty: 'item.itemid', summarizationType: 'listUniqueString'}
            //,{targetProperty: 'upcListString', sourceProperty: 'item.upccode', summarizationType: 'listUniqueString'},
            //{targetProperty: 'inventoryNumberListString', sourceProperty: 'formulatext', summarizationType: 'listUniqueString'}
        ],
        itemsSummary : {},
        elements: [
            {
                type: 'searchResultsTable',
                name: 'printGMLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                validations: [{ name: 'atLeastXResultsSelected', minimumSelectedResults: 1 }],
                elements: [
                    {
                        type: 'rowSelector',
                        name: 'rowSelected',
                        label: '☐',
                        labelAction: 'selectAllAndSummarize',
                        action: 'selectAndSummarize'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.tranid',
                        label: 'Order #' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.trandate',
                        label: 'Order Date' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.itemid",
                        label: "Item",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.salesdescription",
                        label: "Item Description" ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "formulatext",
                        label: "VIN #" ,
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.printGMLabelsDetail = {
        name: 'printGMLabelsDetail',
        title: 'Print GM Labels - Print GM Labels Detail',
        tip: '<details><summary>Choose the Printer, Enter the number of copies, and Tap Next...</summary><p>This will send your labels to be printed on the printer you select. <br> Please Note: this my take 30 seconds or more before the printer will print them. </p></details>',
        searchRequest: Store.workflowSteps.printGMLabelsSearch.searchRequest,
        searchRequestSelected: { searchResultFlat: Store.workflowSteps.printGMLabelsSearch.searchRequest.selectedResults },
        userActions: [
            { name: 'backAction', label: 'Back', action: 'printGMLabelsSearchResults' },
            { name: 'backAction', label: 'Menu', action: 'RFLabelPrintingMenu' },
            {
                name: 'nextAction', label: 'Print', action: 'processActionArray',
                //actions: ['setWorkingInputValues', 'validateInput', 'labelPreparePost', 'mergeTemplateAndData', 'postWMSLabelPrinting', 'RFLabelPrintingMenu']
                actions: ['setWorkingInputValues', 'validateInput', 'printMultipleLabels', 'RFLabelPrintingMenu']
            }
        ],
        elements: [
            {
                type: 'section',
                name: 'printGMLabelsDetail',
                class: 'workflowForm',
                elements: [
                    /* {
                        type: 'input',
                        name: 'selectedItem',
                        label: 'Selected Item',
                        valueDefaultProperty: 'itemListString',
                        valueDefaultObject: 'Store.workflowSteps.printAfterReceiptLabelsSearchResults.itemsSummary',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedUPC',
                        valueDefaultProperty: 'upcListString',
                        valueDefaultObject: 'Store.workflowSteps.printAfterReceiptLabelsSearchResults.itemsSummary',
                        label: 'Selected UPC',
                        visibility: 'readonly'
                    },
                    {
                        type: 'input',
                        name: 'selectedInvNum',
                        valueDefaultProperty: 'inventoryNumberListString',
                        valueDefaultObject: 'Store.workflowSteps.printAfterReceiptLabelsSearchResults.itemsSummary',
                        //valueDefaultProperty: 'GROUP(inventoryDetail.inventorynumber)',
                        label: 'Selected Inv #',
                        visibility: 'readonly'
                    }, */
                    {
                        type: 'input',
                        typeAs: 'number',
                        name: 'labelCount',
                        min: 1,
                        max: 1000,
                        label: 'Number of Labels',
                        valueDefault: '1',
                        //validations: [['required'], ['integer'], ['min'], ['max'], ['step'], ['maxlength'], ['pattern']]
                        validations: [{ name:'required'}, { name: 'integer' }, { name: 'min' }, { name: 'max' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'SCMPrinter',
                        label: 'SCM Printer',
                        recallLastValue: true,
                        datalistSource: 'SCMPrinters',
                        validations: [{ name: 'required' }, { name: 'inDatalist', propertyName: 'name' }]
                    },
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'labelTemplate',
                        label: 'Choose Format',
                        recallLastValue: true,
                        // datalistValues: ['SS WMS PO ITEM LABEL (4x6)', 'SS WMS PO ITEM LABEL (2x3)', 'SS WMS PALLET LABEL (4x6)'],
                        //datalistValues: ['Receiving Label with Lot/Serial (2x3)', 'Receiving Label with Lot/Serial (4x6)', 'Pallet Label with Lot/Serial (4x6)', 'Receiving Pallet Label (4x6)', 'Receiving Inventory Item (2x3)', 'Receiving Inventory Item (4x6)'],
                        datalistSource: 'WMSLabelTemplatesGM',
                        validations: [{ name:'required'}, { name:'inDatalist', propertyName: 'name' }]
                    }
                ]
            },
            {
                type: 'searchResultsTable',
                name: 'printGMLabelsSearchResults',
                /*label: 'Store.current.searchRequest.searchName',
                columnsSource: 'Store.current.searchRequest.columns',
                filterableColumns: [],
                rowAction: 'goToThisRowsValue',
                columnAction: 'sortOnThisColumnsID',*/
                filterAction: 'filterTable',
                hideRowCounts: false,
                hideIfEmpty: false,
                searchRequestToUse: 'searchRequestSelected',
                elements: [
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.tranid',
                        label: 'Order #' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'transaction.trandate',
                        label: 'Order Date' ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.itemid",
                        label: "Item",
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "item.salesdescription",
                        label: "Item Description" ,
                        labelAction: 'sortTable',
                        filter: true
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: "formulatext",
                        label: "VIN #" ,
                        labelAction: 'sortTable',
                        filter: true
                    }
                ]
            }
        ]
    };



    // Data Lists 
    Store.datalists.locations = {
        name: 'locations',
        data: [],
        searchRequest: {
            name: 'locations',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'location',
            searchRequestUserInputs: [],
            searchRequestFilters: 'none',
            searchRequestColumns: ['name', 'internalid'], /** for this release the first column will be shown in datalists, second column is unique id */
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.WMSPrinterDetails = {
        name: 'WMSPrinterDetails',
        data: [],
        searchRequest: {
            name: 'WMSPrinterDetails',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsse_printer_preferences',
            searchRequestUserInputs: [],
            searchRequestFilters: 'none',
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsse_printer_printername', 'custrecord_wmsse_printer_zone', 'custrecord_wmsse_printer_workstation', 'custrecord_wmsse_printer_carrier', 'custrecord_wmsse_printer_workstationtype', 'custrecord_wmsse_printer_printmode'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.SCMPrinters = {
        name: 'SCMPrinters',
        data: [],
        searchRequest: {
            name: 'SCMPrinters',
            searchRESTletFullPOST: '',
            searchRequestFilters: ['isinactive', 'is', false],
            searchID: 'customsearch_wmsts_mobile_printers',//WMS TS | Printers (Script Use)
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.WMSLabelTemplates = {
        name: 'WMSLabelTemplates',
        data: [],
        searchRequest: {
            name: 'WMSLabelTemplates',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsts_label_template',
            searchRequestUserInputs: [],
            searchRequestFilters: 'none',
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsts_active', 'custrecord_wmsts_location', 'custrecord_wmsts_company', 'custrecord_wmsts_template_data', 'custrecord_wmsts_task_type', 'custrecord_wmsts_label_type', 'scriptid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.WMSLabelTemplatesBeforeReceipt = {
        name: 'WMSLabelTemplatesBeforeReceipt',
        data: [],
        inputs: [],
        searchRequest: {
            name: 'WMSLabelTemplatesBeforeReceipt',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsts_label_template',
            searchRequestUserInputs: [],
            searchRequestFilters: ['custrecord_wmsts_label_type', 'contains', 'printBeforeReceiptLabelsDetail'],
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsts_active', 'custrecord_wmsts_location', 'custrecord_wmsts_company', 'custrecord_wmsts_template_data', 'custrecord_wmsts_task_type', 'custrecord_wmsts_label_type', 'scriptid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.WMSLabelTemplatesAfterReceipt = {
        name: 'WMSLabelTemplatesAfterReceipt',
        data: [],
        inputs: [],
        searchRequest: {
            name: 'WMSLabelTemplatesAfterReceipt',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsts_label_template',
            searchRequestUserInputs: [],
            searchRequestFilters: ['custrecord_wmsts_label_type', 'contains', 'printAfterReceiptLabelsDetail'],
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsts_active', 'custrecord_wmsts_location', 'custrecord_wmsts_company', 'custrecord_wmsts_template_data', 'custrecord_wmsts_task_type', 'custrecord_wmsts_label_type', 'scriptid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.WMSLabelTemplatesInventory = {
        name: 'WMSLabelTemplatesInventory',
        data: [],
        inputs: [],
        searchRequest: {
            name: 'WMSLabelTemplatesInventory',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsts_label_template',
            searchRequestUserInputs: [],
            searchRequestFilters: ['custrecord_wmsts_label_type', 'contains', 'printInventoryLabelsDetail'],
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsts_active', 'custrecord_wmsts_location', 'custrecord_wmsts_company', 'custrecord_wmsts_template_data', 'custrecord_wmsts_task_type', 'custrecord_wmsts_label_type', 'scriptid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.WMSLabelTemplatesItem = {
        name: 'WMSLabelTemplatesItem',
        data: [],
        inputs: [],
        searchRequest: {
            name: 'WMSLabelTemplatesItem',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsts_label_template',
            searchRequestUserInputs: [],
            searchRequestFilters: ['custrecord_wmsts_label_type', 'contains', 'printItemLabelsDetail'],
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsts_active', 'custrecord_wmsts_location', 'custrecord_wmsts_company', 'custrecord_wmsts_template_data', 'custrecord_wmsts_task_type', 'custrecord_wmsts_label_type', 'scriptid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };


    // Custom Data Lists for Ford and GM label templates

    Store.datalists.WMSLabelTemplatesFord = {
        name: 'WMSLabelTemplatesFord',
        data: [],
        inputs: [],
        searchRequest: {
            name: 'WMSLabelTemplatesFord',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsts_label_template',
            searchRequestUserInputs: [],
            searchRequestFilters: ['custrecord_wmsts_label_type','contains','printFordLabelsDetail'],
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsts_active', 'custrecord_wmsts_location', 'custrecord_wmsts_company', 'custrecord_wmsts_template_data', 'custrecord_wmsts_task_type', 'custrecord_wmsts_label_type', 'scriptid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.WMSLabelTemplatesGM = {
        name: 'WMSLabelTemplatesGM',
        data: [],
        inputs: [],
        searchRequest: {
            name: 'WMSLabelTemplatesGM',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'customrecord_wmsts_label_template',
            searchRequestUserInputs: [],
            searchRequestFilters: ['custrecord_wmsts_label_type','contains','printGMLabelsDetail'],
            searchRequestColumns: ['name', 'internalid', 'custrecord_wmsts_active', 'custrecord_wmsts_location', 'custrecord_wmsts_company', 'custrecord_wmsts_template_data', 'custrecord_wmsts_task_type', 'custrecord_wmsts_label_type', 'scriptid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };

    Store.datalists.pickStatus = {
        name: 'pickStatus',
        deferred: false,
        data: [
            { pickStatusCode: 'COMPLETED' },
            { pickStatusCode: 'INPROGRESS' },
            { pickStatusCode: 'PENDING' },
            { pickStatusCode: 'READY' }],
        datalistTextProperty: 'pickStatusCode',
        datalistValueProperty: 'pickStatusCode',
        datalistMoreAttributes: [] // future: flat result properties in this list will be added as attributes ot the datalist options in the DOM.
    }

    document.title = Store.defaults.title;

    // conditionally complete initialization based on remote status
    if (!Store.environment.remoteSPA) {
        //Store.debug = false;
        Store.defaults.url = Store.defaults.urlInternal;
        //buildAllDatalists();
    } else {
        //Store.debug = false;
        Store.defaults.url = Store.defaults.urlExternal;
    }

    if (Store.debug) { console.log(indent() + 'setSPASolutionDefaults: returning.') };
    callStackDepth--;
}

var printerParams = { 
    'headers': { 
        'Content-Type': "application/json" 
    }, 
    'params': { 
        'filePath': option.filePath, 
        'noOfCopies': option.noOfCopies, 
        'printer': option.printer, 
        'appName': 'NSWMS' 
    } 
};


function printMultipleLabels() {
    // this function is used to print multiple labels if multiple results are selected.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'printMultipleLabels: called.') };

    // get the selected search results
    var theseSelectedResults = Store.currentWorkflowStep.searchRequest.selectedResults;

    // call labelPreparePost
    labelPreparePost();

    // iterate 
    for (var thisResultIndex in theseSelectedResults) {
        var thisSelectedResult = theseSelectedResults[thisResultIndex];

        // call mergeTemplateAndData
        mergeTemplateAndData(undefined, undefined, undefined, thisSelectedResult);

        // (Deprecated - Old Print Driver approach.
        // call postWMSLabelPrinting
        // postWMSLabelPrinting();

        postWMSLabels();

    }


    if (Store.debug) { console.log(indent() + 'printMultipleLabels: returning.') };
    callStackDepth--
}


function labelPreparePost() {
    // this function prepares labels, submits them to NS for printing, and returns to the menu.  
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'labelPreparePost: called.') };

    // get the user inputs
    // this should be refactored into a common function that retrieves and stores form values from the workflowStep definition. 
    Store.current.label = {};
    Store.current.label.labelCount = document.getElementById('labelCount').value;
    Store.current.label.labelPrinter = document.getElementById('SCMPrinter').value;
    Store.current.label.labelTemplateName = document.getElementById('labelTemplate').value;

    if (Store.debug) { console.log(indent() + 'getWMSLabelTemplate: Store.current.label.labelTemplateName: ', Store.current.label.labelTemplateName) };
    //load the label template from the Store
    Store.current.label.labelTemplate = getSearchResultValueByPropertyValue(Store.datalists.WMSLabelTemplates.searchRequest.searchResultData, 'name', Store.current.label.labelTemplateName, 'custrecord_wmsts_template_data');
    Store.current.label.labelPrinterExtId = getSearchResultValueByPropertyValue(Store.datalists.SCMPrinters.searchRequest.searchResultData, 'name', Store.current.label.labelPrinter, 'custrecord_print_id');
    if (Store.debug) { console.log(indent() + 'getWMSLabelTemplate: Store.current.labelTemplate: ', Store.current.labelTemplate) };

    if (Store.debug) { console.log(indent() + 'labelPreparePost: set Store.current.label: ', Store.current.label) };

    // reset the labelTemplateWithData.
    Store.current.label.labelTemplateWithData = '';

    // now substitute the template with the label data from the search results. 
    //mergeTemplateAndData(); // moved to action array

    // now pots the merged template and data to the WMS Label Printing record. 
    //postWMSLabelPrinting() //Moved to action array


    // merge the selected result into the label template.

    // send the label to WMS Label Printing record

    // call the workflow Menu
    //RFLabelPrintingMenu();
    if (Store.debug) { console.log(indent() + 'labelPreparePost: returning.') };
    callStackDepth--
}


function mergeTemplateAndData_OLD() {
    // This function merges the sleeted data from the search results with the template that was retrieved from NS.
    // the process replaces all Template String Literals with the corresponding 
    //    column from selected entry in the searchResultData.  
    // the template string format is {$netSuiteSearchResultColumnID} and the 
    //    netSuiteSearchResultColumnID is the column id as is is returned from 
    //    the search. 
    // A special notation/reserved literal will be used for the number of copies
    //    ${NumberOfCopiesToPrint}.  If not set by the user, it defaults to 1.
    // Any Template String Literals that do not have a corresponding value in the 
    //    selected entry in the searchResultData will receive an empty string ('').
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'mergeTemplateAndData: called.') };
    // If the template has a number of copies tag, replace it with the number from the UI
    if (Store.current.label.labelTemplate) {
        Store.current.label.labelTemplate = Store.current.label.labelTemplate.replace('${NumberOfCopiesToPrint}', Store.current.label.labelCount);
    }
    if (Store.current.label.labelTemplate) {
        var regex = /\$\{\S+?\}/g;
        Store.current.label.labelTemplateWithData = Store.current.label.labelTemplate.replace(regex, function (match) {
            return Store.workflowSteps[Store.current.workflowStep]['searchRequest']['searchResultFlat'][Store.current.clickedDataIndex][match.substring(3, match.length - 2)] || '';
        });
    }
    if (Store.debug) { console.log(indent() + 'mergeTemplateAndData: Store.current.label.labelTemplateWithData: ', Store.current.label.labelTemplateWithData) };
    if (Store.debug) { console.log(indent() + 'mergeTemplateAndData: returning.') };
    callStackDepth--
}


function mergeTemplateAndData(workflowStep, thisActionItem, thisActionItemChildren, labelDataObject) {
    // This function merges the sleeted data from the search results with the template that was retrieved from NS.
    // the process replaces all Template String Literals with the corresponding 
    //    column from selected entry in the searchResultData.  
    // the template string format is `{$netSuiteSearchResultColumnID}` and the 
    //    netSuiteSearchResultColumnID is the column id as is is returned from 
    //    the search. 
    // A special notation/reserved literal will be used for the number of copies
    //    `${NumberOfCopiesToPrint}`.  If not set by the user, it defaults to 1.
    // Any Template String Literals that do not have a corresponding value in the 
    //    selected entry in the searchResultData will receive an empty string ('').
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'mergeTemplateAndData: called.') };
    //if (Store.debug) {console.log(indent() + 'mergeTemplateAndData: called with:', labelDataObject)};

    // If the template has a number of copies tag, replace it with the number from the UI

    if (Store.current.label.labelTemplate) {
        Store.current.label.labelTemplate = Store.current.label.labelTemplate.replace('`${NumberOfCopiesToPrint}`', Store.current.label.labelCount);
    }

    // set the record to process
    if (typeof labelDataObject === 'object') {
        var thisData = labelDataObject;
    } else {
        //var thisData = Store.currentWorkflowStep['searchRequest']['searchResultFlat'][Store.current.clickedDataIndex];
        var thisData = Store.current.clickedSearchResult;
    }


    if (Store.current.label.labelTemplate) {
        var regex = /`\$\{\S+?\}`/g;
        Store.current.label.labelTemplateWithData = Store.current.label.labelTemplate.replace(regex, function (match) {
            //if (Store.debug) {console.log(indent() + 'mergeTemplateAndData: called with match:', match)};
            //if (Store.debug) {console.log(indent() + 'mergeTemplateAndData: called with thisData:', thisData)};
            return thisData[match.substring(3, match.length - 2)] || '';
        });
    }

    // call the secondary data processor 

    if (Store.debug) { console.log(indent() + 'mergeTemplateAndData: Store.current.label.labelTemplateWithData: ', Store.current.label.labelTemplateWithData) };

    if (Store.debug) { console.log(indent() + 'mergeTemplateAndData: returning.') };
    callStackDepth--
}


function postWMSLabelPrinting() {
    // This function sends merged searchResultData and Label Templates to NetSuite for printing via the Print Driver.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'postWMSLabelPrinting: called.') };

    // After the data is merged into the template, the the merged label data, 
    //    the location, and printer are sent to NetSuite via the 
    //    postWMSLabelPrint RESTlet.

    // After the data is successfully posted, the success message is set and 
    //    the next UI step is called. 

    // now post the template with data to the WMS Label Printing RESTlet/record

    var RESTletFullURL = Store.defaults.url + '?script=' + Store.defaults.postWMSLabelPrinting.scriptID + '&deploy=' + Store.defaults.postWMSLabelPrinting.deploymentID;

    if (Store.debug) { console.log(indent() + 'postWMSLabelPrinting: RESTletFullURL: ', RESTletFullURL) };

    // this builds the "POST" Body
    var WMSLabelPrintingRecord = {
        // the following are the possible fields in the WMS Label Printing record 
        recordType: "customrecord_wmsse_labelprinting",
        wms_print_label: {
            custrecord_wmse_label_formattype: "",
            custrecord_wmsse_label_item: "",
            custrecord_wmse_label_itemqty: "",
            custrecord_wmsse_label_lp: "",
            custrecord_wmsse_label_data: "",
            custrecord_wmsse_label_type: "ZEBRALABEL",
            custrecord_wmsse_label_location: "2",
            name: "set dynamically",
            custrecord_wmse_label_print: false,
            custrecord_wmsse_label_printername: "",
            custrecord_wmsse_label_refno: "ItemLabel"
        }
    }

    // Now prepare the label record to send to NetSuite
    WMSLabelPrintingRecord.wms_print_label.name = Date.now() + ' - ' + Store.current.label.labelTemplateName;
    WMSLabelPrintingRecord.wms_print_label.custrecord_wmse_label_formattype = Store.current.label.labelTemplateName;
    WMSLabelPrintingRecord.wms_print_label.custrecord_wmsse_label_location = getSearchResultValueByPropertyValue(Store.datalists.WMSPrinterDetails.searchRequest.searchResultData, 'name', Store.current.label.labelPrinter, 'custrecord_wmsse_printer_zone');
    WMSLabelPrintingRecord.wms_print_label.custrecord_wmsse_label_data = Store.current.label.labelTemplateWithData;
    WMSLabelPrintingRecord.wms_print_label.custrecord_wmsse_label_printername = getSearchResultValueByPropertyValue(Store.datalists.WMSPrinterDetails.searchRequest.searchResultData, 'name', Store.current.label.labelPrinter, 'custrecord_wmsse_printer_printername');

    if (Store.debug) { console.log(indent() + 'postWMSLabelPrinting: WMSLabelPrintingRecord: ', WMSLabelPrintingRecord) };

    //Store.current.RESTletFullPOST = JSON.stringify(WMSLabelPrintingRecord);
    //var currentWorkflowStep = Store.workflowSteps[Store.current.workflowStep];
    Store.currentWorkflowStep.RESTletFullPOST = JSON.stringify(WMSLabelPrintingRecord);
    //if (Store.debug) { console.log(indent() + 'postWMSLabelPrinting: Post Label Body: ', Store.current.RESTletFullPOST) };
    if (Store.debug) { console.log(indent() + 'postWMSLabelPrinting: Post Label Body: ', Store.currentWorkflowStep.RESTletFullPOST) };

    // call the Get WMS Label Template RESTlet
    var xhr = new XMLHttpRequest();

    xhr.open("POST", RESTletFullURL, true);

    xhr.setRequestHeader("Content-Type", "application/json");
    setAuthHeader(xhr);

    xhr.onreadystatechange = function () { //Call a function when the state changes.
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {

            // Because the request is Asynchronous, this code will not run util the response is returned.
            var xhrResponseData = JSON.parse(xhr.responseText);

            // if no results were returned set the error message
            if (xhrResponseData.success != true) {
                Store.current.successMessage = '';
                Store.current.errorMessage = 'Sorry, I was not abel to print the last label you requested.';
                setErrorTip();
            } //else {
            //Store.current.successMessage = 'I queued the label for printing.';
            //Store.current.errorMessage = '';
            //setSuccessTip();
            //}

            if (Store.debug) { console.log(indent() + 'postWMSLabelPrinting: xhrResponseData: ', xhrResponseData) };
        }
    }
    xhr.send(Store.currentWorkflowStep.RESTletFullPOST);

    if (Store.debug) { console.log(indent() + 'postWMSLabelPrinting: returning.') };
    callStackDepth--
}


function postWMSLabels(){
    // This function replaces "postWMSLabelPrinting". This function creates the label files in NetSuite's File Cabinet.
    callStackDepth++;

    if (Store.debug) { console.log(indent() + 'postWMSLabels: called.') };

    var RESTletFullURL = Store.defaults.url + '?script=' + Store.defaults.postWMSLabels.scriptID + '&deploy=' + Store.defaults.postWMSLabels.deploymentID;

    if (Store.debug) { console.log(indent() + 'postWMSLabels: RESTletFullURL: ', RESTletFullURL) };

    // this builds the "POST" Body
    var WMSLabelFile = {
        folder: "",
        fileName: "",
        fileContent: ""
    }

    WMSLabelFile.folder = Store.defaults.labelsFolder;
    WMSLabelFile.fileContent = Store.current.label.labelTemplateWithData;
    WMSLabelFile.fileName = getDate() + '.zpl';
    WMSLabelFile.printerExtId = Store.current.label.labelPrinterExtId;

    if (Store.debug) { console.log(indent() + 'postWMSLabels: WMSLabelFile: ', WMSLabelFile) };

    Store.currentWorkflowStep.RESTletFullPOST = JSON.stringify(WMSLabelFile);

    if (Store.debug) { console.log(indent() + 'postWMSLabels: Post Label Body: ', Store.currentWorkflowStep.RESTletFullPOST) };

    var xhr = new XMLHttpRequest();

    xhr.open("POST", RESTletFullURL, true);

    xhr.setRequestHeader("Content-Type", "application/json");
    setAuthHeader(xhr);

    xhr.onreadystatechange = function () { //Call a function when the state changes.
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {

            // Because the request is Asynchronous, this code will not run util the response is returned.
            var xhrResponseData = JSON.parse(xhr.responseText);

            // if no results were returned set the error message
            if (xhrResponseData.success != true) {
                Store.current.successMessage = '';
                Store.current.errorMessage = 'Sorry, I was not able to create the last label file you requested.';
                setErrorTip();
            }

            if (Store.debug) { console.log(indent() + 'postWMSLabels: xhrResponseData: ', xhrResponseData) };
        }
    }
    xhr.send(Store.currentWorkflowStep.RESTletFullPOST);

    if (Store.debug) { console.log(indent() + 'postWMSLabels: returning.') };
    callStackDepth--

}


function selectAllAndSummarize() {
    //this function processes the selected search result row and recalculates the summary.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'selectAllAndSummarize: called.') };
    toggleResultSelectionAll();
    summarizeSelectedRows();
    updateSummaryPresentation();
    if (Store.debug) { console.log(indent() + 'selectAllAndSummarize: returning.') };
    callStackDepth--;
}


function selectAndSummarize() {
    //this function processes the selected search result row and recalculates the summary.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'selectAndSummarize: called.') };
    toggleResultSelection();
    summarizeSelectedRows();
    //controlReleaseAction();
    //controlNextAction(); ALEX: REMOVED THIS FOR NOW
    updateSummaryPresentation();
    if (Store.debug) { console.log(indent() + 'selectAndSummarize: returning.') };
    callStackDepth--;
}


function summarizeSelectedRows() {
    // This function summarizes the selected rows. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'summarizeSelectedRows: called.') };
    // defein the search request to use
    // TODO: @AB or SRP this needs to find the search request based on the section.
    var thisSearchRequest = Store.currentWorkflowStep.searchRequest;
    // initialize the selected array
    if (Store.currentWorkflowStep.searchRequest.selectedResults) { /*itemsSelected*/
        Store.currentWorkflowStep.searchRequest.selectedResults.length = 0; /*itemsSelected*/
    } else {
        Store.currentWorkflowStep.searchRequest.selectedResults = []; /*itemsSelected*/
    }
    var theseSelectedItems = Store.currentWorkflowStep.searchRequest.selectedResults /*itemsSelected*/;
    // now add all the selected row references to the selected array
    var currentResults = thisSearchRequest.searchResultFlat;
    for (var selectedRowIndex = 0; selectedRowIndex < currentResults.length; selectedRowIndex++) {
        if (currentResults[selectedRowIndex].rowSelected === true) {
            theseSelectedItems.push(currentResults[selectedRowIndex]);
        }
    }
    // now summarize the selected results.
    if (theseSelectedItems.length < 1) {
        initializeItemsSummary();
    } else {
        summarizeArray(theseSelectedItems, Store.currentWorkflowStep.itemsSummary, Store.currentWorkflowStep.summarizationArray);
        //console.log(Store.orderRelease.orderReleaseSummary);
    }
    if (Store.debug) { console.log(indent() + 'summarizeSelectedRows: returning.') };
    callStackDepth--;
}


function initializeItemsSummary() {
    //this function initializes the Item Summary properties and falues if there were not resutls.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'initializeItemsSummary: called.') };
    if (!Store.currentWorkflowStep.itemsSummary) {
        Store.currentWorkflowStep.itemsSummary = {};
    }
    var tempObjProperties = {};
    Store.currentWorkflowStep.summarizationArray.forEach(function (row) {
        tempObjProperties[row.targetProperty] = '&nbsp;'
    })
    updateObjectProperties(Store.currentWorkflowStep.itemsSummary, tempObjProperties);
    if (Store.debug) { console.log(indent() + 'initializeItemsSummary: returning.') };
    callStackDepth--;
}


function updateSummaryPresentation() {
    //update UI for any values that have changed
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'updateSummaryPresentation: called.') };
    for (var summarizationArrayIndex = 0; summarizationArrayIndex < Store.currentWorkflowStep.summarizationArray.length; summarizationArrayIndex++) {
        var workingProperty = Store.currentWorkflowStep.summarizationArray[summarizationArrayIndex].targetProperty;
        var UIObject = document.getElementById(workingProperty);
        if (UIObject && UIObject.value != Store.currentWorkflowStep.itemsSummary[workingProperty]) {
            UIObject.value = Store.currentWorkflowStep.itemsSummary[workingProperty] || '';
            UIObject.innerHTML = Store.currentWorkflowStep.itemsSummary[workingProperty] || '&nbsp;';
        }
    }
    if (Store.debug) { console.log(indent() + 'updateSummaryPresentation: returning.') };
    callStackDepth--;
}


function getDate(){
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1;
    var yyyy = today.getFullYear();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    if(dd<10) {dd='0'+dd};
    if(mm<10) {mm='0'+mm};
    if(h<10) {h='0'+h};
    if(m<10) {m='0'+m};
    if(s<10) {s='0'+s};
    return (mm+"-"+dd+"-"+yyyy+"-"+h+"-"+m+"-"+s)
}


function isEmpty(stValue){
    if ((stValue == null) || (stValue == '') || (stValue == undefined))
    {
        return true;
    }
    else
    {
        return false;
    }
}


