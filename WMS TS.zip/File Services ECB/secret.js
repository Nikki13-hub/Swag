define([], function() {
    return {
        consumer: {
            public: 'db8502d992ec64d6a6801825bd7a247386a25444906fd83467f5966d70baa406',
            secret: '3e5a8ebbff49cdc56f65227a7352602b1c579990165d05cd8f83c0cb65f2a034'
        },
        token: {
            public: '3e587a88f559325c80b5e077943a1cbd7c5e9c2e569971324692eb7e86a3b59b',
            secret: '97b22375d505439039db758013328494fb2e37eae2cefc3ee80a4b8ed5a555f5'
        },
        realm: '6827316_SB1', //from company info record, grab Account Id (ie:  "6827316_SB1")
        url:'https://6827316-sb1.restlets.api.netsuite.com/app/site/hosting/restlet.nl?script=604&deploy=1',// use the deployemnt ExternalId of script customscript_print_rl_trigger_print,
        method:'post',
    }
});