/**
 * Copyright (c) 1998-2018 Oracle-NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 * 
 * * Version    Date            Author           		Remarks
 *   1.00       01 Nov, 2021	Sudheer K.R Pellakuru   Initial Version
 * 
 * @NApiVersion 2.1
 * @NScriptType restlet
 *
 *

RL Called with a request object that contains
1.	filePath: the Path to the file from the root of the file cabinet (e.g. '/SuiteScript/WMS TS || RF Label Printing/'.
2.	fileName: the File Name to create (e.g. 'WO Label 2021110101010101.zpl').
3.	fileContent: the File Content (e.g. '^XA … ^XZ'). 

RL Processing 
1.	Verify the path/folder exists.
2.	Verify the file does not already exist in the folder.
3.	Create the file in the folder with the content.

RL Returns the original request object and the respose object that contains:
1.	success: true/false
2.	message: the error message if any.
3.	folderId: the id of the folder that the file was found in.
4.	fileId: the id of the new file that was created

 **/

define(['N/search', 'N/runtime', 'N/file'],
    function (search, runtime, file) {
        function createFileObj(requestObject) {
            log.debug("createFileObj", 'Started.');
            log.debug("requestObject", requestObject);
            var logTitle = 'createFileObj';
            /*
              requestObject = {
                  filePath: the Path to the file from the root of the file cabinet (e.g. '/SuiteScript/WMS TS || RF Label Printing/'.
                  fileName: the File Name to create (e.g. 'WO Label 2021110101010101.zpl').
                  fileContent: the File Content (e.g. '^XA … ^XZ'). 
              }

              responseObject = {
                        'success': false,
                        'message': 'Input Folder/Path ' + requestObject.filePath + ' does not exist. Please add the folder or change the path and try again. ',
                        'folderId': vFolderId,
                        'fileId': vFileId
              }
   
            */

            var requestObject = requestObject || {};

            // define the vFolderId
            if ( requestObject.folderId && parseInt(requestObject.folderId) > 0 ) {
                var vFolderId = requestObject.folderId;
            } else {
                var vFolderId = -1;
            }

            // define the vFileId
            if ( requestObject.fileId && parseInt(requestObject.fileId) > 0 ) {
                var vFileId = requestObject.fileId;
            } else {
                var vFileId = -1;
            }

            //define the responseObject
            var responseObject = {
                'input': requestObject,
                'success': false,
                'message': 'unknown',
                'folderId': vFolderId,
                'fileId': vFileId
            }


            try {

                if ( vFolderId > 0 ) {
                    //validate the folder exists
                } else {
                    // Get the folder passed in the request Object
                    var folderSearchObj = search.create({
                        type: "folder",
                        filters:
                            [
                                ["name", "is", requestObject.filePath]//,
                                //"AND",
                                //["parent", "anyof", "@NONE@"]
                            ],
                        columns:
                            [
                                search.createColumn({
                                    name: "name",
                                    sort: search.Sort.ASC,
                                    label: "Name"
                                }),
                                search.createColumn({ name: "foldersize", label: "Size (KB)" }),
                                search.createColumn({ name: "lastmodifieddate", label: "Last Modified" }),
                                search.createColumn({ name: "parent", label: "Sub of" }),
                                search.createColumn({ name: "numfiles", label: "# of Files" }),
                                search.createColumn({ name: "internalid", label: "Internal ID" })
                            ]
                    });
                    var searchResultCount = folderSearchObj.runPaged().count;
                    log.debug("folderSearchObj result count", searchResultCount);

                    if ( searchResultCount > 0 ) {
                        folderSearchObj.run().each(function (result) {
                            // .run().each has a limit of 4,000 results
                            vFolderId = result.getValue('internalid');
                            log.debug("folderSearchObj vFolderId", vFolderId);
                            return true;
                        });
                    }

                    log.debug("vFolderId", vFolderId);

                    if (vFolderId === -1) {
                        responseObject.success = false;
                        responseObject.message = 'Input Folder/Path ' + requestObject.filePath + ' does not exist. Please add the folder or change the path and try again. ';
                        responseObject.folderId = vFolderId;
                        responseObject.fileId = vFileId;

                        log.debug("folderSearchObj returning.", responseObject);
                        return responseObject;
                    }
                }

                log.debug("vFolderId, vFileId", vFolderId + ' ' + vFileId);

                if ( vFileId > 0 ) {
                    // if the field id was sent in, return an error... the file cannot exist if we are creating it.
                    responseObject.success = false;
                    responseObject.message = 'the File ID cannot be set manually when creating a new file (you sent fileId: ' + requestObject.fileId + ' ). ';
                    responseObject.folderId = vFolderId;
                    responseObject.fileId = vFileId;

                    log.debug("folderSearchObj returning.", responseObject);
                    return responseObject;
                } else {
                    // verify the file name does not exist in the folder. If it does, return an error. 
                    var fileSearchObj = search.create( {
                        type: "file",
                        filters:
                            [
                                ["name", "is", requestObject.fileName],
                                'AND',
                                ['folder','is','folderId']
                            ],
                        columns:
                            [
                                search.createColumn({
                                    name: "name",
                                    sort: search.Sort.ASC,
                                    label: "Name"
                                }),
                                search.createColumn({ name: "folder", label: "Folder" }),
                                search.createColumn({ name: "documentsize", label: "Size (KB)" }),
                                search.createColumn({ name: "url", label: "URL" }),
                                search.createColumn({ name: "created", label: "Date Created" }),
                                search.createColumn({ name: "modified", label: "Last Modified" }),
                                search.createColumn({ name: "filetype", label: "Type" }),
                                search.createColumn({ name: "internalid", label: "Internal ID" }),
                                search.createColumn({ name: "folder", label: "Folder" })
                            ]
                    });
                    var searchResultCount = fileSearchObj.runPaged().count;

                    log.debug("fileSearchObj result count", searchResultCount);

                    fileSearchObj.run().each(function (result) {
                        // .run().each has a limit of 4,000 results
                        vFileId = result.getValue('internalid');
                        return true;
                    });

                    if (vFileId !== -1) {
                        responseObject.success = false;
                        responseObject.message = 'The file name ( ' + requestObject.fileName + ') already exists in the folder ( vFolderId: ' + vFolderId + ' ). ';
                        responseObject.folderId = vFolderId;
                        responseObject.fileId = vFileId;
    
                        return responseObject;
                    }
                }

                let fileObj = file.create({
                    name: requestObject.fileName,
                    fileType: file.Type.PLAINTEXT,
                    contents: requestObject.fileContent,
                    folder: vFolderId,
                    isOnline: true
                });

                // Save the file
                //let vFileId = fileObj.save();
                vFileId = fileObj.save();


                return {
                    'success': true,
                    'message': '',
                    'folderId': vFolderId,
                    'fileId': vFileId,
                    'requestObject': requestObject
                }
            }
            catch (e) {
                return {
                    'success': false,
                    'message': e.message,
                    'folderId': vFolderId,
                    'fileId': vFileId,
                    'requestObject': requestObject

                }
            }

        }
        return {
            post: createFileObj
        };
    });

