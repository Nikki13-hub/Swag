define(['N/https', './oauth.js', './secret.js'],

    function (https, oauth, secret) {

        function submitPrintNode(option) {
            var url = secret.url;
            var method = secret.method;
            var headers = oauth.getHeaders({
                url: url,
                method: method,
                tokenKey: secret.token.public,
                tokenSecret: secret.token.secret,
            });
            var printerParams = { 'headers': { 'Content-Type': "application/json" }, 'params': { 'filePath': option.filePath, 'noOfCopies': '1', 'printer': option.printer, 'appName': 'NSWMS' } };
            headers['Content-Type'] = 'application/json';
            var restResponse = https.post({
                url: url,
                headers: headers,
                body: JSON.stringify(printerParams)
            });
            log.debug('restResponse', restResponse);
        }
        return {
            submitPrintNode: submitPrintNode
        };

    });

// sample filepath: '/suitescripts/labels/label.zpl'