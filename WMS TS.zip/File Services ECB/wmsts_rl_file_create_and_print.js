/**
 * Copyright (c) 1998-2020 NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 */

/**
 * @NApiVersion 2.0
 * @NScriptType restlet
 * @NModuleScope Public
 *
 * Version    Date          Author        Remarks
 * 1.00       [date]        [User]        Initial Commit
 *
 */

define(['N/search', 'N/runtime', 'N/file', './wmsts_lib_submitprintnode.js'],
    function (search, runtime, file, print) {

    /**
     *
     * Returns the HTTP response body.
     *  - Returns a string when request Content-Type is 'text/plain'.
     *  - Returns an Object when request Content-Type is 'application/json'.
     *
     * @param requestBody = [string | Object]
     * @returns {[string | object]}
     */
    function postMethod(requestBody) {

        log.debug("Request Received to create & print a label", '-----------BEGIN-----------');
        log.debug("Request received this 'requestBody'", requestBody);


        var requestObject = requestBody || {};

        // define the vFolderId
        if (!isEmpty(requestObject.folder)) {
            var vFolderId = requestObject.folder;
        } else {
            var vFolderId = -1;
        }
        log.debug("Validated file folder.", vFolderId);

        // define the vFileId
        if (!isEmpty(requestObject.fileName)) {
            var vFileId = requestObject.fileName;
        } else {
            var vFileId = -1;
        }
        log.debug("Validated file name.", vFileId);

        //define the responseObject
        var responseObject = {
            'input': requestObject,
            'success': false,
            'message': 'unknown',
            'folderId': vFolderId,
            'fileId': vFileId
        }

        try {

            if (vFolderId == -1 || vFileId == -1 ) {

                responseObject.success = false;
                responseObject.message = 'The Folder and/or File Name is empty. Please check that a file name is assigned (you sent name: ' + requestObject.fileName + ', and folder: ' + requestObject.folder +').';
                responseObject.folderId = vFolderId;
                responseObject.fileId = vFileId;
                return responseObject;

            } else {
                // Get the folder passed in the request Object
                var folderSearchObj = search.create({
                    type: "folder",
                    filters:
                        [
                            ["name", "is", requestObject.folder]//,
                            //"AND",
                            //["parent", "anyof", "@NONE@"]
                        ],
                    columns:
                        [
                            search.createColumn({
                                name: "name",
                                sort: search.Sort.ASC,
                                label: "Name"
                            }),
                            search.createColumn({ name: "foldersize", label: "Size (KB)" }),
                            search.createColumn({ name: "lastmodifieddate", label: "Last Modified" }),
                            search.createColumn({ name: "parent", label: "Sub of" }),
                            search.createColumn({ name: "numfiles", label: "# of Files" }),
                            search.createColumn({ name: "internalid", label: "Internal ID" })
                        ]
                });
                var folderSearchResultCount = folderSearchObj.runPaged().count;
                log.debug("folderSearchObj result count", folderSearchResultCount);

                if ( folderSearchResultCount > 0 ) {
                    folderSearchObj.run().each(function (result) {
                        // .run().each has a limit of 4,000 results
                        vFolderId = result.getValue('internalid');
                        log.debug("folderSearchObj vFolderId", vFolderId);
                        return true;
                    });
                }

                var fileSearchObj = search.create( {
                    type: "file",
                    filters:
                        [
                            ["name", "is", requestObject.fileName],
                            'AND',
                            ['folder','is',vFolderId]
                        ],
                    columns:
                        [
                            search.createColumn({
                                name: "name",
                                sort: search.Sort.ASC,
                                label: "Name"
                            }),
                            search.createColumn({ name: "folder", label: "Folder" }),
                            search.createColumn({ name: "documentsize", label: "Size (KB)" }),
                            search.createColumn({ name: "url", label: "URL" }),
                            search.createColumn({ name: "created", label: "Date Created" }),
                            search.createColumn({ name: "modified", label: "Last Modified" }),
                            search.createColumn({ name: "filetype", label: "Type" }),
                            search.createColumn({ name: "internalid", label: "Internal ID" }),
                            search.createColumn({ name: "folder", label: "Folder" })
                        ]
                });
                var fileSearchResultCount = fileSearchObj.runPaged().count;

                log.debug("fileSearchObj result count", fileSearchResultCount);

                if (fileSearchResultCount >0) {
                    fileSearchObj.run().each(function (result) {
                        // .run().each has a limit of 4,000 results
                        vFileId = result.getValue('internalid');
                        return true;
                    });

                    responseObject.success = false;
                    responseObject.message = 'The file name ( ' + requestObject.fileName + ') already exists in the folder ( vFolderId: ' + vFolderId + ' ). ';
                    responseObject.folderId = vFolderId;
                    responseObject.fileId = vFileId;
                    return responseObject;
                }

            }

            log.debug("vFolderId, vFileId", vFolderId + ' ' + vFileId);

            var fileObj = file.create({
                name: requestObject.fileName,
                fileType: file.Type.PLAINTEXT,
                contents: requestObject.fileContent,
                folder: vFolderId,
                isOnline: true
            });

            // Save the file
            //let vFileId = fileObj.save();
            vFileId = fileObj.save();
            log.debug('File successfully created and saved in the File Cabinet.', vFileId);

            var fileObj = file.load({
                id: vFileId
            });

            var pnObj = {};

            pnObj.filePath = fileObj.path;
            pnObj.printer = requestObject.printerExtId;

            print.submitPrintNode(pnObj);

            log.debug('Submitted PrintNode job with this object:', pnObj);

            return {
                'success': true,
                'message': '',
                'folderId': vFolderId,
                'fileId': vFileId,
                'requestObject': requestObject
            }
        }

        catch (e) {
            return {
                'success': false,
                'message': e.message,
                'folderId': vFolderId,
                'fileId': vFileId,
                'requestObject': requestObject

            }
        }

    }

    return {
        post: postMethod,
    }

    function isEmpty(stValue){
            if ((stValue == null) || (stValue == '') || (stValue == undefined))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

});