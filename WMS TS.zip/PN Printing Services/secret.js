define([], function() {
    return {
        consumer: {
            public: 'abee35d969686a5fd9a70b58fee94d4677a1bc8c0147b9f3200bbbd1d96a6cd5',
            secret: 'c8494c4e9aa15902a9bd416656f551f173a44c0f5ee96e9c259d4bc7b02f137f'
        },
        token: {
            public: '2eec42e30c8b4d378ac07f6ff0b5b1b5f6a6699e71c16cb2232b5d967f90be5b',
            secret: '09070669500de45f9d79d874b81ed9772648c6df36fbaff0586d0dee43d4efdf'
        },
        realm: '', //company info
        url:'',// use the deployemnt ExternalId of script customscript_print_rl_trigger_print,
        method:'post',
    }
});