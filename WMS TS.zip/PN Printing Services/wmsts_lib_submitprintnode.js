define(['N/https', './oauth.js', './secret.js'],

    function (https, oauth, secret) {

        function submitPrintNode(option) {
            let url = secret.url;
            let method = secret.method;
            let headers = oauth.getHeaders({
                url: url,
                method: method,
                tokenKey: secret.token.public,
                tokenSecret: secret.token.secret,
            });
            let printerParams = { 'headers': { 'Content-Type': "application/json" }, 'params': { 'filePath': option.filePath, 'noOfCopies': option.noOfCopies, 'printer': option.printer, 'appName': 'NSWMS' } };
            headers['Content-Type'] = 'application/json';
            let restResponse = https.post({
                url: url,
                headers: headers,
                body: JSON.stringify(printerParams)
            });
            log.debug('restResponse', restResponse)
        }
        return {
            submitPrintNode: submitPrintNode
        };

    });