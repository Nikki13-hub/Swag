/** This is the core JS file for the SuiteSPA
    * This file is called from the SuiteSPA.html
    * Customer/ECB specific changes could be made
    *      in the ./SuiteSPASolution.js file.
    *
    * SRP 20181016
    *
    * Typical event flow:
    *  - User: logs into NetSuite WMS RF and taps a Custom Menu Item
    *  - SuiteLet: NetSuite WMS RF Custom Menu SuiteScript calls the Render SuiteSPA SuiteLet
    *  - SuiteLet: The Render SuiteSPA SuiteLet downloads the SPA (including the SPA Foundation HTML, CSS, and JS, and the SPA Solution JS and CSS)
    *  - SPA: the SPA initiates in the browser sets up the Store, loads data lists, and attaches the workflowActionRouter to the document.
    *  - SPA: renders first step, typically the workflow Menu based on the SPA solution JS definition.
    *  - User: The user taps a menu option
    *  - SPA: The browser recognizes an event has occurred and calls the appropriate workflow step function based on the workflow step definition (e.g. a search form).
    *  - SPA: The workflow step function builds the UI input form from the workflow step definition.
    *  - SPA: The build step calls the function to render the workflow step UI (Sets the title, tip, error tip, success tip, body, and action items from the workflow step definition)
    *  - User: the user enters search data and taps next
    *  - SPA: The browser recognizes an event has occurred and calls functions based on the workflow step definition from the SPA Solution JS.
    *      - The form inputs are validated based on the workflow step definition from the SPA Solution JS.
    *      - The get search results function is called based on the workflow step definition from the SPA Solution JS.
    *          - the get search results function prepares the NetSuite Search Request and calls the Get Search Results RESTlet as a POST
    *              - the Get Search Results RESTlet performs the search and returns the results as a JSON response
    *          - the get search results function stores the response in the store and calls the Make Table function.
    *      - The search request search results from NS
    *  - RESTlet builds results UI
    *  - system
    *
    * Change Log
    * 20181126 SRP:
    * - refactored form input away from using the Store.current to using the workflowStep object
    * - added validations for: match, patchPattern, matchToInputIndex, matchToArrayValue, numeric, integer, min, max, date,
    * - login workflow step and process are now in the foundation JS
    * - added hidden input type (typeAs 'hidden')
    *
    * 20181128 SRP:
    * - changed getArrayValueByPropertyValue change so null/empty returns array Index
    * - Added support for action: processActionArray and actions [...] on searchResultsTable elements.
    * - Reset root debug to false in HTML
    *
    * 20181201 SRP:
    * - added selective update of object keys updateObjectProperties and started migrating defaults.
    * - removed assumed menu in HTML
    * - refactored actions to workingObject.actionsArrays
    * - Added the ability for a search result to call another search result (action and actions supported on search result elements)
    * - Added the ability for action router to recognize the change in workflow steps to support processing several steps
    *
    * 20181213 SRP:
    * - Merged back revise foundation files CD
    * - Multi-language integration
    * - - language object in foundation and solution js
    *
    * 20181215 SRP:
    * - Added functions for polling all language objects to verify they have translations
    *
    * 20190211 SRP:
    * - changed prepareSearchRequest to allow filters to be defined on datalists... this was error because the inputs were empty.
    * - single result redirect
    * 
    * 20190317 SRP: 
    * - integrated search result table sorting based on Mahesh T's efforts. 
    * - - table elements require "labelAction:'sortTable'" property... optional "sortDirection: 'asc' (or 'desc')" will display the direction. 
    * 
    *
    * 20190426 MT/SRP
    * - Table Filtering
    * - Render Table from searchResultFilter not Flat
    * - SummarizeArrayToArray
    * - - This supports summarizing an array like a SQL summary where there can be multiple resulting summarized objects in the results array
    * 
    * 20190505 SRP
    * - Worked the issue of searching a second time "remembering" the first searches inputs if the input was empty the second time
    * - - Modified makePresentation
    * - - - the workflowStep.<name>.inputs was being added as a reference to the workflowStep.<name>.elements, so the element itself was getting the value.
    * - - - Changed this so the inputs would be a copy of the input object, not a reference to the input object 
    * - - Modified the prepareSearchRequest 
    * - - - now the function will always update the searchRequestFilters... the last search filters were being reused if NO inputs were set.
    * - - Started the Conditional Behaviors changes
    * 
    * 20190507 SRP 
    * - Working on Deferred Datalists
    * - - if a datalist has a new property "deferred" and if it is set to true, the datalist is not called during initialization.
    * 
    * 20190518
    * - workflowActionRouter
    * - - Renamed to actionRouter to differentiate. 
    * - - - change in JS  and HTML
    * - - now supports optional action type prefix function., workflowStep., or datalist. 
    * - New function updateDatalist triggers the update of the datalist
    * - - from a workflow action or actions, datalist name (or reference?)
    * - - - object with datalist properties to update e.g. 
    * - - - {searchRequest: {searchRequestFilters: [ [ 'inventorydetail.location', 'anyof', Store.current.captureData.locationId ], 'AND', ['name', 'is', currentItem] ] }}
    * - Added initializationActions behavior...
    * - - If a workflow contains an initializationActions property (actions array), the actions will be run prior to loading
    * - - Added initializationActions() to call call processActionArray() if actions exist on the current workflow step 
    * - - Modified updateUI() to call initializationActions()
    * - Added onReadyActions behavior...
    * - - If a workflow contains an onReadyActions property (actions array), the actions will be run prior to loading
    * - - Added onReadyActions() to call call processActionArray() if actions exist on the current workflow step 
    * - - Modified updateUI() to call onReadyActions()
    * - Change workflowStep.actions to workflowStep.userActions
    * 
    * 20190523 AB: 
    * - Added capability of not showing the table headers if the table is empty (thisSearchRequest.renderIfEmpty = true), this is to prevent showing the table on the cases that we use a table under a form
    * - Updated inDatalist validation  
    * - merged - Prevented an error when the input object didn't have a value (because isn't being populated from the UI, this is on the cases that we use the function alone)
    * 
    * 20190613 and 20190614 SRP
    * - Added table row selection, deselection, select all, deselect all
    * - enhanced summarizeArray to include new functions for min, max, and listUnique and cleaned up some others.
    * - - the listUnique builds an Array of the unique values for the property. 
    * - Corrected how the initial workflowStep is called. 
    * - - HTML sets the starting firstActions, firstActionsRemoteSPA, firstWorkflowStep, and firstWorkflowStepRemoteSPA
    * - - Each solution file can add the functions it needs called (typical) or manipulate the firstActions array based on its needs.
    * - - The one firstWorkflowStep is called after the firstActions array completes. 
    * - - Control from a deployment should not be necessary, but if it is, override firstActions, firstActionsRemoteSPA, firstWorkflowStep, and firstWorkflowStepRemoteSPA could be added and honored.
    * - Added displayTransformation to convert values in the innerHTML
    * - Added new class in CSS to show disabled actions (.buttonDisabled)
    * - Added new class in CSS to allow the input div to use the width of the screen (.workflowFormWide)
    * 
    * 20190619 SRP
    * - Added the ability to select "similar" rows.  e.g. select all rows with a order number that matches the selected row's order number.
    * - Refined the sorting process and the sorting UI indicators 
    * - Enhanced table rendering to add the table name ot the DOM to support multiple sections in a workflow step.
    * 
    * 20190627 SRP 
    * - Added nextAction and backAction classes set by make presentation 
    * - added the ability to redisplay the selected row selector after sorting or coming back to a table with selected rows. 
    * 
    * 20190629 SRP
    * - Added Store.currentWorkflowStep to eliminate mst functions from needing to do Store.workflowSteps[Store.current.workflowStep]...
    * - Cleared a lot of extra/noisy debug consol logging. 
    * - Added new Sort model based on a sort array stored o the section being sorted.
    * - - this maintains the sort array [{property:'x',sort:'asc/desc'},...] in the section.
    * - - supports multi-level sorting (I think, haven tested) 
    * - - this is half implemented... need to remove the old model and finish new. 
    * - Added section-level data, so different sections show data from the searchResultFlat and have different sorts and filters
    * - - render looks for section data, filtered data, and then flat data.
    * - Working toward model where every render prepares the section data with filter and sort before rendering. 
    * - Added two new methods to addToArray... 
    * - - addValueToEnd: this method pushes each value in the source to the end of the target array.
    * - - addValueToStart: this method unshift each value in the source to the start of the target array.
    * 
    * 20190705 AB:
    * - Added support for multiple tables using multiple searchRequest properties (You will need to add on the element this property 'searchRequestToUse' and fill it with the name of searchRequest), per default is using the standard searchRequest
    * - Support for editable fields on tables. typeAs 'editable'
    * 
    * 20190815 AB:
    * - Added an id for each table using the same name as the searchRequest property used (for multiple tables + using editable fields)
    * - Added searchRequest.noResultErrorMessage , to hide unwanted 'Sorry, No results for that' when loading a datalist
    * 
    * 20191008 AB:
    * - Updated to use search result filter instead of search result flat
    * 
    * 20191024 AB:
    * - Added 'rowFixedValue' to display static data on a cell in a table
    * 
    * 20191101 SRP:
    * - Revised the initialization cycle
    * - - Standard Cycle
    * - - - firstActionsRemoteSPA: [], // these actions are executed before authentication
    * - - - - initialized as empty in HTML, 
    * - - - - Foundation JS and Solution JS file adds any actions/functions that need to be called before authentication as the JS files are loaded into the browser.
    * - - - firstActions: [], // these actions are executed after authentication 
    * - - - - initialized as empty in HTML, 
    * - - - - Foundation JS and Solution JS file adds any actions/functions that need to be called after authentication as the JS files are loaded into the browser.
    * - - - firstWorkflowStepRemoteSPA: '', // this is the first screen to be called if not authenticated (remote development)
    * - - - - initialized as empty in HTML, 
    * - - - - Foundation JS adds this as 'login' as JS field is loaded by the browser.  Solution JS files can override (but don't normally).  Last file loaded that sets this wins! 
    * - - - firstWorkflowStep: '' // this is the first screen to be called if or after authenticated (called from NS or after login)Load store with empty 
    * - - - - initialized as empty in HTML, 
    * - - - - Foundation JS and Solution JS files set this as each JS file is loaded by the browser.  Last file loaded that sets this wins! 
    * - - Initialization will
    * - - - call all the actions in the firstActionsRemoteSPA
    * - - - if unauthenticated (Remote Dev), call the firstWorkflowStepRemoteSPA (typically login)
    * - - - call all the actions in the firstActions
    * - - - call the firstWorkflowStep
    * 
    * 20191110 SRP:
    * - Added a new user object for holding information about the user that is logged into the solution. 
    *  - - Need to complete the loadCurrentUserInformation function and move it here.  
    * 
    * 20191113 AB:
    * - Added the option to select the begin and end quantity of the search results (default is begin from 0 to 1000)
    * - Added an extra message when there are 1000 results TO DO: @SRP ENHANCE THE MESSAGE
    * 
    * 20191126 SRP
    * - 1) Change to updateUI (handle object being set in current.workflowStep, 
    * - 2) change to prepareSearchRequest to assure searchRequestUserInputs exists before checking its length, 
    * - 3) refinement of prepareSearchRequest2 (adding preset filters to user filters), and 
    * - 4) started lateBind function. 
    * 
    * 20191227 SRP
    * - fixed recallLastValue 
    * 
    * 20191228 SRP
    * - working on solving the problem around
    * - - Asynchronous vs Synchronous Initial Actions (e.g. getting the user info)
    * - - - firstActions vs firstActionsSynchronous?
    * - - - should addToArray moveToEnd move to the end of the deepest array?  last array? 
    * - - Deferring initial workflow step until synchronous actions finish 
    * - - Conditional display of first step (e.g. select location if no default set, else menu. )
    * 
    * 20191230 SRP
    * - processAction now supports passing the actionsArray when using the datalist.datalistName notation or if thisAction is a datalist. 
    * - prepareSearchRequest2: added some additional logic to avoid errors
    * - prepareSearchRequest2: added optional late binding check to filters array if the array value is an object { lateBind: 'Store.x.y' }
    * - lateBind: completed the lateBind function. 
    * - deepArrayLateBind: added function to search nested arrays and replace call lateBind function for any object { lateBind: 'Store.x.y' }
    * - commented out unnecessary locations 1 and 2 datalists.
    * 
    * 20191231 SRP 
    * - corrected some places in code where the new objects were being referenced and not resetting the original array or object in get and flatten search results functions. 
    *  
    * 20200101 SRP
    * - Added late binding of inputs with presentationObjectElement.valueDefaultProperty && presentationObjectElement.valueDefaultObject
    * - - simply make the valueDefaultObject on the input object a string and not an object, and the path in the string will be late bound when making the presentation. 
    * - - e.g. change valueDefaultObject: Store.current.inStoreData, valueDefaultProperty: 'locationName' to  valueDefaultObject: 'Store.current.inStoreData', valueDefaultProperty: 'locationName'
    * 
    * 20200105 SRP
    * - Added conditional action items
    * - - the actionItem will display or not display depending on the value of the new optional condition property on the (in the userAction array of the current workflow step) 
    * - - if the value is false, the action item is not rendered.  if it is true or missing it is rendered. So, the default is true.
    * - - if the value is 
    * - - - boolean, it is used directly.
    * - - - string, it is checked ot see if it is a function... if it is a function, the function is called and returns true or false. Note, the function can have parameters. 
    * - - future: add other types of conditions like the NS filter array syntax for evaluating true/false.
    * 
    * 20200108 SRP
    *  - enhanced updateDatalist and setDatalistOptionsFromArray to properly handle actions array being passed in. 
    * 
    * 20200109 SRP 
    * - Added minimumLength input field validation (validations: [['minimumLength','3']]).
    * - Added an override description to the match and matchPattern validations (validations: [['match','200', 'your IQ'],['matchPattern','/[A-Z]/g','starting with a capital letter']]).
    * 
    * 20200113 SRP- 
    * - working on comparison functions (e.g. whereCompare)
    * - added matchValues inputValidation. 
    * - started revised sort results function for single results array (vs. flat, sorted, filtered).
    * 
    * 20200228 - 20200302 SRP
    * 1.	all searchResultFilter is now searchResultFlat... 
    * 2.	filtering now sets the filterMatch property on the searchResultFlat object
    * 3.	sorting occurs to searchResultFlat
    * 4.	the persistSearchResults and makePresentation functions call updateSearchResultVisibility to update the visibility property on each row and update the count properties 
    * 5.	rewrote filter to be more efficient, not duplicate results and update the filterMatch property on searchResultFlat instead of writing to separate object.
    * 6.	rewrote sorting to use searchResultFlat... more love is needed here. 
    * 7.	makePresentation now looks at searchResultVisible property of the searchResultFlat (if it exists, it must be true) to render or not render a result
    * 8.	new updateSearchResultVisibility function can be called any time custom filtering or setting/clearing of the filterMatch or resultPosted property.
    * 9.	Added optional table header label (add a label to the section to show)
    * 10.	Added result count "showing x of y" to the table header (property on the section is hideRowCounts to suppress)
    * 11.	Added section table filters to the table header (property on the section is filterAction: 'filterTable' to show on section)
    * 
    * 20200302 SRP - Working on
    * - Action Router Refactor 
    * - Add Table Input Support
    * 
    * 20200319 SRP - updated loading mask functions to survive body changes.
    * 
    * 20200320 - 20200322 SRP
    *   actionRouter now uses the searchRequestToUse DOM attribute to set Store.current.clickedSearchRequest
    *   Refactored toggleResultSelection and toggleAllRowSelection to build/clear a selectedResults array in the search request object
    *       Each selection/deselection adds or removes the selected/deselected row from the array
    *       Selection/deselection of the header adds/removes all rows to/from the array
    *   postProcessedRecords function
    *       added this process to generically handle posted selected values
    *       updates the resultPosted flag to true, the rowSelected flag to false, and the searchResultVisible flag to false.
    *   postWMSTSQueueAction function 
    *       added this process to generically post WMS TS Queue requests. 
    *       expects a WMSTSQ object in the workflowStep with a payload object and a processingOptions object and searchRequest.
    *       sends the request, adds the response to the WMSTSQ.response object, and calls the next steps in the actionsArray.
    *   noVisibleResultActions
    *       added a foundation action that is called on updateUI if there is a noVisibleResultActions array on the workflowStep
    *       typical use case to to redirect back to the search (instead of the results) if some process set all the results to searchResultVisible: false
    *   updateSearchResultVisibility
    *       this function evaluates search results, sets it's visibility, and updates the counts for a given searchRequest
    *       it Covers Total, Filtered, Processed 
    *   validateRowsSelected
    *       added this standard validation to verify that the user has selected rows before progressing to the next step in an actions array 
    *       example: action: 'processActionArray', actions: ['validateRowsSelected','inStoreLocatorDetail']
    *   confirmToContinue 
    *       prompts the user to confirm before allowing the user to continue (okay continues, cancel sets error message so the user stays where they are). 
    *       For use in actions array. 
    *   processAction
    *       can now process a function with parameters... please don't abuse this!
    *       currently, this requires the action be prefixed with "function." (which was from a previous release)
    *       example: action: 'processActionArray', actions: ['showLoader','function.confirmToContinue("Are you sure you want to do that stuff?")','doStuff','clearLoader']]
    *  processWMSTSQAction
    *   
    * 20200401 - 20200407
    * - updateDatalist now calls summarizeResultsAll after it persists the search results.
    * Added 
    * - selectAllResults - sets all search results flat to selected and adds to the selected results array
    * - summarizeResultsAll - a generic function that summarizes results into a searchResultSummarizedAll object on the searchRequest if summarizationArrayAll array is defined on the searchRequest.
    * - summarizeResultsSelected - a generic function that summarizes the selected results into a searchResultSummarizedSelected object on the searchRequest if summarizationArraySelected array is defined on the searchRequest.
    * 
    * 20200411 SRP
    * - refactored toggleAllRowSelection/toggleSelectAllRows to toggleResultSelectionAll across foundation and solution files
    * 
    * 20200412 SRP
    * - refactored dateToUsEn to properly send browser date 2020-04-12 to NS as 04/12/2020 
    * 
    * 20200422 SRP
    * - refactored element-level validations from arrays to objects to better handle parameters.  e.g. validations: [['required']] is now validations: [{name:'required'}]
    * - added errorMessage that can be overridden on all standard validations.  e.g. validations: [{name:'required', errorMessage: 'Hold up there dude, that field is required!'}]
    * - added validateForm to process form-level validations like we do with validateInput.  The fist form validation is 
    *   - e.g. validations: { name:'atLeastXRequired', minimumInputs: 1, inputNames: ['bar_codes','itemid', 'CUSTRECORD_ITEM.custrecord_item_location']}
    * 
    * 20200424 SRP
    * - refactored setBody to set the focus on the first input even if there are multiple sections
    * - refactored setWorkingInputs
    * - refactored setDatalistOptionsFromSearchResult to support using a optional template string to define the values of the datalist options.
    * - - template string e.g.: datalistTemplate: { properties: ['entityid','internalid'], template: 'Emp: ${properties.entityid} (${properties.internalid})' },
    * - refactored setWorkingInputs input to add the datalist and the selected row to the inputs object 
    * - - All datalist: Store.workflowSteps.xyz.inputObject.datalist
    * - - the selected datalist object: Store.workflowSteps.xyz.inputObject.datalistOption
    * 
    * 20200507 SRP
    * - updated the allResultsProcessed function to use the summarized new standard values on search request instead of array length
    * - updated the summarizeAndGroupArray property to Array from Object (because it is an array and not an object :-)
    * 
    * 20200513 SRP
    * - resolved issue in setWorkingInputValues when the value in the datalist input field was not in the datalist.
    * 
    * 20200514 SRP
    * - ISSUE: new setWorkingInputValues not correctly handling fixed "data: " datalists. 
    * 
    * 20200520 SRP
    * - Resolved the issue with table filtering when the table included a filterable number property.
    * 
    * 20200520 AB
    * - updated clickedSearchResult to use Store.current.clickedSearchRequest instead of Store.currentWorkflowStep.searchRequest
    * 
    * 20200525 AB
    * - updated validateForm to fix following issue: if an input filed specified in the array is not in actual input form elements it will skip the validation
    * 
    * 20200604 SRP
    * - Min and Max error messages were not right.
    * 
    * 20200703 SRP 
    * - corrected issue with filterAllowNull.
    * - using an in-field operator will now ignore the filterAllowNull.
    * 
    * 20200722 SRP
    * - commented out and deleted some unused functions.
    * - commented out some of the more noisy debug console logs
    * - added form image
    * - added defaultImage
    * - added summarizeResultsAllBySearchRequest to forcibly recalculate summarized data
    * - corrected some issues with the listUnique in the summarize function.
    * 
    * 20200727
    * - added onBeforeUnload to warn the user if they are going to leave the page.  
    * 
    * 20200813 SRP
    * - refined the prepareSearchRequest function to ignore inputs if the input element searchField property has a space in it (never valid in NS).  
    *   - this is also leveraged in the solution so show elements on forms that the developer does not want to be submitted to NS as search filters. 
    * 
    * 20200814 SRP
    * - Extended the matchValues validation to support lateBind objects. 
    * 
    * 20200816 SRP 
    * -  postWMSTSQueueAction: Added support to define a success message on the Queue Request thisQueueRequest.successMessage
    * 
    * 20201231
    * - Added ability to control input group styles (inputGroupClass property) to allow labels on top (needs latest CSS)
    * - Revised initial filed focus code (there were edge-cases where it would not actually focus).
    * - Added the ability to set the initial focus to an input other than the first input (input property initialFocus:true)
    * - Transitioned displayTransformation from array-based ot object based
    * - Added transformations for Array or JSON Array to ordered list, unordered list, text list, or custom
    * - Added lateBind to table data (needs to be able to access "working" table data) for efficiency
    * - added the ability to set mouse-over (tap on mobile) tooltips on table data
    * - added no-wrap class ... will move to property at some point.
    * 
    * 202101-03 SRP
    * - Added ability to exclude inputs from being included in building search filters by using a filterFieldTreatment of ['ignore'] 
    * 
    * SRP 20210326 
    * - modified getReferenceFromPath so that the path can reference an array entry (e.g. somObject.someChileArray[0]).
    * 
    * SRP 20210327
    * - modified getReferenceFromPath to support property names that have . in them (e.g. somObject.someChildArray['fish.lips']).
    * - modified lateBind to match the getReferenceFromPath logic.
    *   !!!!! NOTE: this could be a breaking change... the old logic should not have worked with arrays or properties with ., so this should not be an issue.  
    * 
    * 20210401 - 20210414 SRP 
    * - Started textarea input
    * - started search via SQL Query
    * 
    * 20210420-20210426 SRP
    * - Added ability for datalists to be conditionally built from other datalists 
    * - - if a datalist has a property of datalistSource, it will populate it's data array from the sources data array or searchResultFlat array
    * - - if the datalist also has a datalist filters array, the data populated from the datalistSource will only include data objects that match the criteria
    * - - - the datalistFilters property holds an array of criteria objects 
    * - - - - e.g. datalistFilters: [ { property: 'custrecord_wmsts_zone_vna_zone', operator: '===', value: 'Include' } ]
    * - - - at the moment only one criteria is supported... we can unlimited in the future.
    * - Added a valueCompare(value1, operator, value2) function that returns true or false depending on what is passed in.
    * - - this needs to be combined into the other comparison functions
    * 
    * 20210428 SRP 
    * - Continued refinement of datalist handling
    * - - datalists that used the .data array (as opposed to searchResultFlat) were not setting the datalistOption for the selected option in the input Option.
    * - Added downloadAsFile function that allows foundation to write "content" (e.g. test, JSON, binary) a file to the local device. 
    * - Extended valueCompare(value1, operator, value2) to support values passed in as lateBind objects. 
    * 
    * 20210508 SRP
    * - commented out a lot of noisy console logging
    * - datalists (buildAllDatalists, setDatalistOptionsFromSearchResults, setDatalistOptionsFromArray) now supports additionalActions that can be executed following search, each time the datalist is updated.
    * - processActionArray: started support for actions to be objects.
    * - added prepareInputObject that builds the inputObject from elements.
    * - slightly modified how makePresentation builds/populates inputObject
    * - prepareSearchRequest now support "searchRequestFilters_required" ... this filter array will be appended to the filters from user input.
    * - prepareSearchRequest3 temporarily added with new features ... this will move to prepareSearchRequest when proven stable. 
    * - - searchRequestFilters_Additional filters
    * - tweaked downloadAsFile
    * 
    * 20210513 SRP
    * - modified setWorkingInputValues to be more specific when setting datalistOption for selected value. 
    * 
    * To do: 
    * - dataBind the input fields in tables
    * - Add section searchRequestArrayToUse when using searchRequestToUse (this allows foundation to point to one of the summarized arrays in the results)
    * - property transformation while rendering a value (e.g. show an array as a comma separated list, or mask a phone number, etc. )
    * - Conditional Behaviors
    * - - (e.g. { action: 'mainMenu' type: workflowStep, condition: ['Store.user.location', '!=', null] } )
    * - - conditional evaluation function 
    * - - conditional visibility 
    * - - conditional validations
    * - - conditional actions 
    * - Filtered Datalists - Make Dynamic (e.g. look to a another property while rendering if defined on the element)
    * - async host process management
    * - - message to the user that the request was queued and is processing
    * - - visual indicator that an async process is executing
    * - - UX when the async process succeeds or fails
    * - - protection from executing that same async process multiple times if NS can't handle it.
    * - validate if setFiltersFromInput is being called/used
    * - refactor all action to actions
    * 
    *
*/


// Foundation Initialization Actions.  This executes as soon as the JS is returned to the browser.
addToArray(Store.defaults.firstActionsRemoteSPA, ['setQueryParameters','setSPAFoundationDefaults'], 'moveValueToEnd'); // this adds entries to the list of initialization actions that will be run before authentication.
addToArray(Store.defaults.firstActions, ['buildAllDatalists'], 'moveValueToEnd'); // this adds entries to the list of initialization actions that will be run after authentication.
Store.defaults.firstWorkflowStepRemoteSPA = 'login'; // This is the first user screen before authenticated (local dev instance).  This is typically login. 
Store.defaults.firstWorkflowStep = 'mainMenu'; // This is the first user screen after authenticated.  This is typically overridden by the solution JS file. 


if (Store.debug) { console.log(indent() + 'finished loading SuiteSPA Foundation') };

// Initialization Functions 
function setSPAFoundationDefaults() {
    callStackDepth++;
    // This function load the initial Store values.
    if (Store.debug) { console.log(indent() + 'setSPAFoundationDefaults: called.') };

    updateObjectProperties(Store.user, {
        userId: null,
        userEmail: null,
        userSignature: null,
        userRole: null,
        userPermissions: [],
        userLocation: null,
        userLocations: [],
        temporary: { // note: this is only needed when executing the SPA outside of NS.
            test: {
                nlauth_account: '3938531', 
                nlauth_email: '',
                nlauth_signature: '',
                nlauth_role: '3'
            }
        }
    });

    updateObjectProperties(Store.current, {
        clickedSearchResult: '',
        language: '',
        location: '',
        workflowStep: 'login',
        workingOnAction: '',
        errorMessage: '',
        remoteSPA: false,
        successMessage: '',
        temporary: { // note: this is only needed when executing the SPA outside of NS.
            test: {
                nlauth_account: '3938531', 
                nlauth_email: '',
                nlauth_signature: '',
                nlauth_role: '3'
            }
        }
    });

    updateObjectProperties(Store.defaults, {
        title: 'SuiteSPA',
        url: '',
        urlExternal: 'https://rest.netsuite.com/app/site/hosting/restlet.nl',
        urlInternal: '/app/site/hosting/restlet.nl',
        getSearchResults: { scriptID: 'customscript_wms_restlet_search', deploymentID: '1' },
        filterOperator: 'contains',
        filterFieldTreatment: ['', ''],
        filterValueTreatment: '', // this is a function name that will be run on the value as the filter string is being built. 
        datatype: 'string', //SRP 20191117 
        filterAllowNull: false, //SRP 20191117
        BeginRecord: 0,
        EndRecord: 1000,
        mainMenu: 'mainMenu',
        hideRowCounts: false,
        defaultImage: '/images/nav/ns_x.gif'
    });

    updateObjectProperties(Store.messageLibrary, {
        SuiteSPA: {
            setLanguageEnglish: {
                successMessage: 'The Language has been changed to English.'
            },
            setLanguageSpanish: {
                successMessage: 'The Language has been changed to Español.'
            },
            setLanguageHindi: {
                successMessage: 'The Language has been changed to Hindi.'
            },
            clearLanguage: {
                successMessage: 'The Language has been set back to the application default.'
            },
            prepareSearchRequest: {
                successMessage: 'prepareSearchRequest: a SearchId, searchName, or searchRecordType is required.'
            },
            getSearchResults: {
                'fileNotFound': { errorMessage: 'Sorry, There was an issue talking with the server.  Please check the logs... 404.' },
                'noResults': { errorMessage: 'Sorry, No Results for that.' },
                'serverIssues': { errorMessage: 'Sorry, There was an issue talking with the server.  Please check the logs.' }
            },
            persistSearchResults: {
                'successPrefix': { successMessage: 'I found ' },
                'successSuffix': { successMessage: ' results.' },
                'noResults': { errorMessage: 'persistSearchResults: Sorry, No Results for that.' }
            },
            validateInput: {
                'required': { errorMessage: ' is required. ' },
                'matchValue': { errorMessage: ' input needs to be ' },
                'matchPattern': { errorMessage: ' input needs to match ' },
                'matchKey': { errorMessage: ' input needs to be ' },
                'numeric': { errorMessage: ' input needs to be a number. ' },
                'integer': { errorMessage: ' input needs to be a whole number. ' },
                'max': { errorMessage: ' input needs to be no more than ' },
                'min': { errorMessage: ' input needs to be at least ' },
                'date': { errorMessage: ' needs to be a valid date.' },
                'moreErrors': { errorMessage: ' And,<br>' }
            }
        }
    });

    /*Store.language = {
        'Back': {in:'Back Hindi'},
        'Change to English (English)': { en: 'Change to English (English)', es: 'Cambiar a Inglés (English)', in: 'अंग्रेजी में बदलें (English)' },
        'Change to Hindi (बदलें)': { en: 'Change to Hindi (बदलें)', es: 'Cambiar a hindi (बदलें)', in: 'हिंदी में बदलें (बदलें)' },
        'Change to Spanish (Español)': { en: 'Change to Spanish (Español)', es: 'Cambio a español (Español)', in: 'Espanol में बदलें (Español)' },
        'Current Location': {},
        'I found ': {},
        ' input needs to be ': {},
        ' input needs to match ': {},
        ' input needs to be ': {},
        ' input needs to be a number. ': {},
        ' input needs to be a whole number. ': {},
        ' input needs to be no more than ': {},
        ' input needs to be at least ': {},
        ' is required. ': {},
        ' needs to be a valid date.': {},
        'Item': {},
        'Location': {},
        'Menu': {},
        'Next': {},
        'persistSearchResults: Sorry, No Results for that.': {},
        ' results.': {},
        'Scan': {},
        'Sorry, There was an issue talking with the server.  Please check the logs... 404.': {},
        'Sorry, No Results for that.': {},
        'Sorry, There was an issue talking with the server.  Please check the logs.': {},
        'Tap a row for more details': {},
        'Type': {}
    };*/

    Store.workflowSteps.login = {
        name: 'login',
        title: Store.defaults.title + ' - ' + 'Login',
        tip: '<details><summary>Enter your credentials and tap Next...</summary><p> this is your login to your NetSuite account.</p></details>',
        initializationActions: [],
        onReadyActions: [],
        userActions: [
            { name: 'backAction', label: 'Back', action: 'mainMenu' },
            { name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: ['setWorkingInputValues', 'validateInput', 'setLogin'] }
        ],
        elements: [
            {
                type: 'section',
                name: 'login',
                class: 'workflowForm',
                validations: [['allRequired']], // TODO: @SRP correct this
                elements: [
                    {
                        type: 'input',
                        name: 'nlauth_account',
                        label: 'NetSuite Account Number',
                        valueDefault: Store.current.temporary.test.nlauth_account,
                        validations: [{ name:'required'}]
                    },
                    {
                        type: 'input',
                        name: 'nlauth_email',
                        label: 'NetSuite Account User Email',
                        valueDefault: Store.current.temporary.test.nlauth_email,
                        validations: [{ name:'required'}]
                    },
                    {
                        type: 'input',
                        typeAs: 'password',
                        name: 'nlauth_signature',
                        label: 'NetSuite Account Password',
                        valueDefault: Store.current.temporary.test.nlauth_signature,
                        validations: [{ name:'required'}]
                    },
                    {
                        type: 'input',
                        typeAs: 'number',
                        name: 'nlauth_role',
                        label: 'NetSuite Account Role',
                        min: 1,
                        max: 9999,
                        valueDefault: Store.current.temporary.test.nlauth_role,
                        validations: [{ name:'required'}, { name: 'numeric' }, { name: 'integer' }, { name: 'min' }, { name: 'max' }]
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.mainMenu = {
        name: "mainMenu",
        title: Store.defaults.title + ' - ' + 'Main Menu',
        tip: 'Tap to select an option',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'goBackToCaller' }
        ],
        elements: [
            {
                type: 'section',
                typeAs: 'orderedList',
                name: 'mainMenu',
                class: 'workflowForm',
                elements: [
                    {
                        type: 'listItem',
                        name: 'login',
                        label: 'Login',
                        actions: ['login']
                    },
                    {
                        type: 'listItem',
                        name: 'languageSpanish',
                        label: 'Switch to Espanol',
                        actions: ['setLanguageSpanish']
                    }
                ]
            }
        ]
    };

    Store.workflowSteps.languageMenu = {
        name: "languageMenu",
        tip: "Select a search",
        title: Store.defaults.title + ' - ' + 'Language Menu',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'mainMenu' }
        ],
        elements: [
            {
                type: 'section',
                typeAs: 'orderedList',
                name: 'languageMenu',
                class: 'workflowForm',
                elements: [
                    { type: 'listItem', name: 'searchMenu', label: 'Change to English (English)', action: 'setLanguageEnglish' },
                    { type: 'listItem', name: 'searchMenu', label: 'Change to Spanish (Español)', action: 'setLanguageSpanish' },
                    { type: 'listItem', name: 'searchMenu', label: 'Change to Hindi (बदलें)', action: 'setLanguageHindi' },
                    { type: 'listItem', name: 'searchMenu', label: 'Clear the Language (default)', action: 'clearLanguage' },
                    {
                        type: 'listItem', name: 'searchMenu', label: 'Check for Language Entries',
                        actions: ['missingLanguageKeys', 'languageEntries']
                    },
                    { type: 'listItem', name: 'searchMenu', label: 'Change Language', action: 'changeLanguage' }
                ]
            }
        ]
    };

    Store.workflowSteps.changeLanguage = {
        name: 'changeLanguage',
        title: Store.defaults.title + ' - ' + 'Select Language',
        tip: 'Set or reset your language',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'mainMenu' },
            {
                name: 'nextAction', label: 'Next', action: 'processActionArray',
                actions: ['setWorkingInputValues', 'validateInput', 'setLanguage']
            }
        ],
        elements: [
            {
                type: 'section',
                name: 'changeLanguage',
                class: 'workflowForm',
                elements: [
                    {
                        type: 'input',
                        typeAs: 'search',
                        name: 'languageCode',
                        datalistSource: 'languages',
                        label: 'Select Language',
                        validations: [{ name:'required'}]
                    }
                ]
            },
            {
                type: 'section',
                typeAs: 'orderedList',
                name: 'language',
                class: 'workflowForm',
                elements: [
                    { type: 'listItem', name: 'searchMenu', label: 'Clear the Language (default)', action: 'clearLanguage' },
                    {
                        type: 'listItem', name: 'searchMenu', label: 'Check for Language Entries',
                        actions: ['missingLanguageKeys', 'languageEntries']
                    },
                    { type: 'listItem', name: 'searchMenu', label: 'Change Language', action: 'setLanguage' }
                ]
            }
        ]
    };

    Store.workflowSteps.languageEntries = {
        name: 'languageEntries',
        title: Store.defaults.title + ' - ' + 'Language Entries',
        tip: 'Tap a row for more details',
        userActions: [
            { name: 'backAction', label: 'Back', action: 'languageMenu' },
            { name: 'searchMenu', label: 'Menu', action: 'mainMenu' }
        ],
        searchRequest: {
            searchResultFlat: Store.languageEntries
        },
        elements: [
            {
                type: 'searchResultsTable',
                name: 'languageEntries',
                elements: [
                    {
                        type: 'searchResultsTableColumn',
                        name: 'foundInStore',
                        label: 'App String'
                        //,
                        //action: 'inventorySearchDetail'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'en',
                        label: 'English'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'in',
                        label: 'Hindi'
                    },
                    {
                        type: 'searchResultsTableColumn',
                        name: 'es',
                        label: 'Spanish'
                    }
                ]
            }
        ]
    };

    Store.datalists.languages = {
        name: 'languages',
        deferred: false,
        data: [
            { language: 'English (English)', languageCode: 'en' },
            { language: 'Spanish (Español)', languageCode: 'es' },
            { language: 'Hindi (बदलें)', languageCode: 'in' },
            { language: 'Reset to Default', languageCode: '' }],
        datalistTextProperty: 'language',
        datalistValueProperty: 'languageCode',
        datalistMoreAttributes: [] // future: flat result properties in this list will be added as attributes ot the datalist options in the DOM.
    }

    /*Store.datalists.locations = {
        name: 'locations',
        deferred: false,
        data: [],
        datalistTextProperty: 'name', // this optional property defines property in the search results that holds the inner text for the option in the data list. 
        datalistValueProperty: 'internalid', // this optional property defines property in the search results that holds the Value for the option in the data list.
        searchRequest: {
            name: 'locations',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'location',
            searchRequestUserInputs: [],
            searchRequestFilters: 'none',
            searchRequestColumns: ['name', 'internalid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };*/

    /*Store.datalists.locations2 = {
        // TODO: why is this list here?
        name: 'locations2',
        deferred: true,
        data: [],
        datalistTextProperty: 'name', // this optional property defines property in the search results that holds the inner text for the option in the data list. 
        datalistValueProperty: 'internalid', // this optional property defines property in the search results that holds the Value for the option in the data list.
        searchRequest: {
            name: 'locations2',
            searchRESTletFullPOST: '',
            searchID: '',
            searchName: '',
            searchRecordType: 'location',
            searchRequestUserInputs: [],
            searchRequestFilters: 'none',
            searchRequestColumns: ['name', 'internalid'],
            searchResultColumns: [],
            searchResultData: [],
            searchResultFlat: [],
            searchStatus: {
                localBeginTime: 0,
                RESTletBeginTime: 0,
                RESTletEndTime: 0,
                RESTletTotalTime: 0,
                RESTletStatusMessage: '',
                RESTletSuccess: null
            },
            searchSuccessTip: 'none'
        }
    };*/

    // add the listener for the default action (enter)
    document.getElementById('mainContainer').addEventListener("keyup", processDefaultAction);

    if (Store.debug) { console.log(indent() + 'setSPAFoundationDefaults: returning.') };
    callStackDepth--;
}

window.onbeforeunload = function(e) {
    // This warns the user before leaving the page (e.g back button or refresh)
    return "Warning, you are about to leave the solution.  Are you sure you want to leave?  Click OK to leave, or Cancel to stay in the solution. ";
};

function callFirstActions() {
    // This function calls the initialization actions once all the JS files are loaded.
    callStackDepth++
    if (Store.debug) { console.log(indent() + 'callFirstActions: called.') };

    setEnvironment(); // determine if we are running from NetSuite or in a local dev instance.

    if (Store.environment.remoteSPA === false) {
        // If the solution is being called from NetSuite, execute the following
        processActionArray(Store.defaults, Store.defaults.firstActionsRemoteSPA); // this loads the actions that need to be run first in local dev mode (before login)
        processActionArray(Store.defaults, Store.defaults.firstActions);
        processAction(Store.defaults, Store.defaults.firstWorkflowStep);
    } else {
        // If you are working in a local development environment, execute the following
        processActionArray(Store.defaults, Store.defaults.firstActionsRemoteSPA);
        processAction(Store.defaults, Store.defaults.firstWorkflowStepRemoteSPA);
    }

    if (Store.debug) { console.log(indent() + 'callFirstActions: returning.') };
    callStackDepth--;
}

function callFirstWorkflowStep() {
    // This function calls the initialization actions once all the JS files are loaded.
    callStackDepth++
    if (Store.debug) { console.log(indent() + 'callFirstWorkflowStep: called.') };

    if (Store.environment.remoteSPA === false) {
        // If the solution is being called from NetSuite, execute the following
        processAction(Store.defaults, Store.defaults.firstWorkflowStep);
    } else {
        // If you are working in a local development environment, execute the following
        processAction(Store.defaults, Store.defaults.firstWorkflowStepRemoteSPA);
    }

    if (Store.debug) { console.log(indent() + 'callFirstWorkflowStep: returning.') };
    callStackDepth--;
}

function setEnvironment() {
    // This function sets the environment variables
    callStackDepth++
    if (Store.debug) { console.log(indent() + 'setEnvironment: called.') };

    // check if the SPA was called from NS or remote environment.
    if (window.location.origin.indexOf('netsuite.com') >= 0) {
        Store.environment.remoteSPA = false;
    } else {
        Store.environment.remoteSPA = true;
    }
    if (Store.debug) { console.log(indent() + 'setEnvironment: remoteSPA: ', Store.environment.remoteSPA) };

    // check for IE
    if (navigator.appName == 'Microsoft Internet Explorer' || !!(navigator.userAgent.match(/Trident/) || navigator.userAgent.match(/rv:11/))) {
        alert("Please do not use IE.  An HTML 5 compatible browser is required. ");
        Store.environment.thisIsIE = true;
    } else {
        Store.environment.thisIsIE = false;
    }
    if (Store.debug) { console.log(indent() + 'setEnvironment: thisIsIE: ', Store.environment.thisIsIE) };

    if (Store.debug) { console.log(indent() + 'setEnvironment: returning.') };
    callStackDepth--;
}

function setQueryParameters() {
    callStackDepth++;
    //this function puts the query parameters into the Store
    if (Store.debug) { console.log(indent() + 'setQueryParameters: called.') };

    queryString = document.location.search.split('+').join(' ');

    var queryParameters = {};
    var tokens = '';
    var regex = /[?&]?([^=]+)=([^&]*)/g;

    while (tokens = regex.exec(queryString)) {
        queryParameters[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
    }

    Store.queryParameters = queryParameters;
    if (Store.debug) { console.log(indent() + 'setQueryParameters: returning.') };
    callStackDepth--;
}

function setLogin() {
    callStackDepth++;
    // this function allows the user to enter credentials for the NS requests. 
    // this is needed until the SPA is called from NS... i.e. for local development. 

    if (Store.debug) { console.log(indent() + 'setLogin: called.') };

    // Add the user's credentials into the Store for later use in REST calls.
    Store.current.temporary.test.nlauth_account = document.getElementById('nlauth_account').value;
    Store.current.temporary.test.nlauth_email = document.getElementById('nlauth_email').value;
    Store.current.temporary.test.nlauth_signature = document.getElementById('nlauth_signature').value;
    Store.current.temporary.test.nlauth_role = document.getElementById('nlauth_role').value;

    // Now call the post authentication initial actions and the first workflow step.
    if (Store.defaults.firstActions) {
        processActionArray(Store.defaults, Store.defaults.firstActions);
    } 
    processAction(Store.defaults, Store.defaults.firstWorkflowStep);

    if (Store.debug) { console.log(indent() + 'setLogin: returning.') };
    callStackDepth--;
}


//datalist Functions
function buildAllDatalists() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'buildAllDatalists: called.') };

    //this function calls the setDataListOptionsFromArray for each list defined in the Store. 
    var datalistNames = Object.keys(Store.datalists);
    //if (Store.debug) { console.log(indent() + 'buildAllDatalists: datalistNames:', datalistNames) };

    for (var datalistIndex = 0; datalistIndex < datalistNames.length; datalistIndex++) {

        var datalistName = datalistNames[datalistIndex];
        var thisDatalist = Store.datalists[datalistName];

        // build each datalist that is not set to deferred.
        if ( !thisDatalist.deferred || thisDatalist.deferred != true ) {
            if (Store.debug) { console.log(indent() + 'buildAllDatalists: working on:', datalistName) };

            if ( thisDatalist.searchRequest ) {
                var datalistActionsArray = ['getSearchResults', 'persistSearchResults', 'summarizeResultsAll', 'setDatalistOptionsFromSearchResults'];
                var newActionsArray = [datalistActionsArray];
                if ( thisDatalist.additionalActions && thisDatalist.additionalActions.length > 0 ) {
                    datalistActionsArray.push.apply( datalistActionsArray, thisDatalist.additionalActions );
                }
                // if ( actionsArray && Array.isArray(actionsArray) && actionsArray.length > 0 ) {
                //     datalistActionsArray.push.apply( datalistActionsArray, actionsArray );
                // }
                prepareSearchRequest(thisDatalist, newActionsArray);
                //prepareSearchRequest( thisDatalist, [['getSearchResults', 'persistSearchResults', 'setDatalistOptionsFromSearchResults']] );
            } else {
                var datalistActionsArray = [];
                var newActionsArray = [datalistActionsArray];
                if ( thisDatalist.additionalActions && thisDatalist.additionalActions.length > 0 ) {
                    datalistActionsArray.push.apply(datalistActionsArray, thisDatalist.additionalActions);
                }
                // if ( actionsArray && Array.isArray(actionsArray) && actionsArray.length > 0 ) {
                //     datalistActionsArray.push.apply( datalistActionsArray, actionsArray );
                // }
                //prepareSearchRequest(thisDatalist, newActionsArray);
                setDatalistOptionsFromArray( datalistName, thisDatalist.data, newActionsArray);
                //setDatalistOptionsFromArray( datalistName, thisDatalist.data );
            }
        }
    }
    if (Store.debug) { console.log(indent() + 'buildAllDatalists: returning.') };
    callStackDepth--;
}

function setDatalistOptionsFromSearchResults(workingObject, actionsArray) {
    // this function takes ans array of strings and appends them to the target datalist. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromSearchResults: called with: searchRequest:', workingObject.name) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'setDatalistOptionsFromSearchResults: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        console.log(indent() + 'setDatalistOptionsFromSearchResults: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    var datalistContainer = document.getElementById('datalistContainer');
    // remove the datalist from the DOM is it exists
    if (document.getElementById(searchRequest.name)) {
        datalistContainer.removeChild(document.getElementById(searchRequest.name));
    }
    // Add the datalist container.
    var newDatalist = document.createElement('datalist');
    newDatalist.id = searchRequest.name;
    datalistContainer.appendChild(newDatalist);

    var workingDatalist = document.getElementById(searchRequest.name);

    var theseSearchResults = searchRequest.searchResultFlat; 
    
    // process the template 
    //var datalistTemplate = { properties: ['entityid','internalid'], template: `Emp: ${properties.entityid} (${properties.internalid})`};
    if (workingObject.datalistTemplate) {
        var templatePropertyNames = workingObject.datalistTemplate.properties;
        var template = workingObject.datalistTemplate.template;
        var properties = {};
        if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromSearchResults: template', template) };
    }

    var datalistTextProperty = workingObject.datalistTextProperty || searchRequest.searchResultColumns[0]['name'];
    var datalistValueProperty = workingObject.datalistValueProperty || searchRequest.searchResultColumns[0]['name'];
    var optionText = '';
    var optionValue = '';

    for (var thisSearchResultIndex = 0; thisSearchResultIndex < theseSearchResults.length; thisSearchResultIndex++) {
        if (theseSearchResults.filterMatch || typeof theseSearchResults.filterMatch == 'undefined' ) {

            var thisSearchResult = theseSearchResults[thisSearchResultIndex];

            var option = document.createElement('option');
            // test the template
            if (workingObject.datalistTemplate) {
                for (var propertyIndex = 0; propertyIndex < templatePropertyNames.length; propertyIndex++) {
                    var propertyName = templatePropertyNames[propertyIndex];
                    properties[propertyName] = thisSearchResult[propertyName];
                    //option.setAttribute (propertyName, thisSearchResult[propertyName]);
                    //if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromSearchResults: properties', properties ) };
                }
                var templateOptionText = eval('`'+template+'`' );
                //if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromSearchResults: template eval', templateOptionText) };
            }

            // get the optionKey and optionValue
            optionText = templateOptionText || thisSearchResult[datalistTextProperty] || thisSearchResult[0];
            optionValue = thisSearchResult[datalistValueProperty];

            option.setAttribute ('value', optionText);
            option.setAttribute ('optionIndex', thisSearchResultIndex);
            option.setAttribute ('optionValue', optionValue);

            workingDatalist.appendChild(option);
        }
    }
    // now update any child datalists 
    updateAllChildDatalists( searchRequest.name );

    // Now, if any additional actions were passed in, execute the actions 
    if (actionsArray && Array.isArray(actionsArray) && actionsArray.length > 0) {
        processActionArray(workingDatalist, actionsArray);
    }

    if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromSearchResults: returning.') };
    callStackDepth--;
}

/*function setDatalistOptionsFromSearchResultsOld(workingObject, actionsArray) {
    // this function takes ans array of strings and appends them to the target datalist. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromSearchResultsOld: called with: searchRequest, actionsArray', workingObject.name, actionsArray) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'setDatalistOptionsFromSearchResultsOld: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        console.log(indent() + 'setDatalistOptionsFromSearchResultsOld: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    var datalistContainer = document.getElementById('datalistContainer');
    // remove the datalist from the DOM is it exists
    if (document.getElementById(searchRequest.name)) {
        datalistContainer.removeChild(document.getElementById(searchRequest.name));
    }
    // Add the datalist container.
    var newDatalist = document.createElement('datalist');
    newDatalist.id = searchRequest.name;
    datalistContainer.appendChild(newDatalist);

    var workingDatalist = document.getElementById(searchRequest.name);

    var sourceArray = searchRequest.searchResultFlat; // AB 20191008 updated to use search result filter instead of search result flat
    //var sourceArray = searchRequest.searchResultFilter; 
    var datalistTextProperty = workingObject.datalistTextProperty || searchRequest.searchResultColumns[0]['name'];
    var datalistValueProperty = workingObject.datalistValueProperty || searchRequest.searchResultColumns[0]['name'];

    for (var sourceArrayIndex = 0; sourceArrayIndex < sourceArray.length; sourceArrayIndex++) {
        if (sourceArray.filterMatch || typeof sourceArray.filterMatch == 'undefined' ) {
           // get the optionKey and optionValue
            var optionText = sourceArray[sourceArrayIndex][datalistTextProperty];
            var optionValue = sourceArray[sourceArrayIndex][datalistValueProperty];
            var option = document.createElement('option');
            option.value = optionValue;
            option.innerHTML = optionText || optionValue;
            workingDatalist.appendChild(option);
        }
    }

    if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromSearchResultsOld: returning.') };
    callStackDepth--;
}*/

function setDatalistOptionsFromArray(targetDatalist, sourceArray, actionsArray) {
    // this function takes ans array of strings and appends them to the target datalist. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromArray: called:', targetDatalist ) };

    // Add the datalist container if it does not exist.
    if (!document.getElementById(targetDatalist)) {
        var datalistContainer = document.getElementById('datalistContainer');
        var newDatalist = document.createElement('datalist');
        newDatalist.id = targetDatalist;
        datalistContainer.appendChild(newDatalist);
    } else {
        var datalistContainer = document.getElementById( targetDatalist );
        while (datalistContainer.firstChild) {
            datalistContainer.firstChild.remove();
        }
    }
    var workingDatalist = document.getElementById(targetDatalist);

    var datalistTextProperty = Store.datalists[targetDatalist].datalistTextProperty;
    var datalistValueProperty = Store.datalists[targetDatalist].datalistValueProperty;

    for (var sourceArrayIndex = 0; sourceArrayIndex < sourceArray.length; sourceArrayIndex++) {
        // get the optionKey and optionValue
        var optionText = sourceArray[sourceArrayIndex][datalistTextProperty];
        var optionValue = sourceArray[sourceArrayIndex][datalistValueProperty];
        //if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromArray: optionText, optionValue', optionText, optionValue ) };
        var option = document.createElement('option');
        option.value = optionValue || optionText;
        option.setAttribute ( 'optionIndex', sourceArrayIndex );
        option.innerHTML = optionText || optionValue;
        workingDatalist.appendChild(option);
    }

    // Now update any Child data lists if they exist
    updateAllChildDatalists( targetDatalist );

    // Now, if any additional actions were passed in, execute the actions 
    if (actionsArray && Array.isArray(actionsArray) && actionsArray.length > 0) {
        processActionArray(workingDatalist, actionsArray);
    }

    if (Store.debug) { console.log(indent() + 'setDatalistOptionsFromArray: returning.') };
    callStackDepth--;
}

function updateDatalist(datalistName, actionsArray) {
    // this function is use to update a datalist 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'updateDatalist: called.') };

    // get the working Object and return if not valid
    //var workingObject = getWorkingObject(datalistName);
    var thisDatalist = Store.datalists[datalistName];
    if (!thisDatalist) {
        console.log(indent() + 'setDatalistOptionsFromSearchResults: no thisDatalist, returning.');
        callStackDepth--;
        return;
    }

    if (thisDatalist.searchRequest) {
        var datalistActionsArray = ['getSearchResults', 'persistSearchResults', 'summarizeResultsAll', 'setDatalistOptionsFromSearchResults'];
        var newActionsArray = [datalistActionsArray];
        if (thisDatalist.additionalActions && thisDatalist.additionalActions.length > 0) {
            datalistActionsArray.push.apply(datalistActionsArray, additionalActions);
        }
        if (actionsArray && Array.isArray(actionsArray) && actionsArray.length > 0) {
            datalistActionsArray.push.apply(datalistActionsArray, actionsArray);
        }
        prepareSearchRequest(thisDatalist, newActionsArray);
    } else {
        var datalistActionsArray = [];
        var newActionsArray = [datalistActionsArray];
        if (thisDatalist.additionalActions && thisDatalist.additionalActions.length > 0) {
            datalistActionsArray.push.apply(datalistActionsArray, additionalActions);
        }
        if (actionsArray && Array.isArray(actionsArray) && actionsArray.length > 0) {
            datalistActionsArray.push.apply(datalistActionsArray, actionsArray);
        }
        //prepareSearchRequest(thisDatalist, newActionsArray);
        setDatalistOptionsFromArray(datalistName, thisDatalist.data, newActionsArray);
    }

    if (Store.debug) { console.log(indent() + 'updateDatalist: returning.') };
    callStackDepth--;
}

function updateAllChildDatalists( parentDatalistName, actionsArray ) {
    // this function finds all child data lists (those that build themselves from another datalist) and executes updateChildDatalist on each. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'updateAllChildDatalists: called.') };

    //var thisParentDatalist = Store.datalists[parentDatalistName];
    var allDatalistNames = Object.keys(Store.datalists);

    for (var datalistIndex = 0; datalistIndex < allDatalistNames.length; datalistIndex++) {
        var thisChildDatalistName = allDatalistNames[datalistIndex]
        //if (Store.debug) { console.log(indent() + 'updateAllChildDatalists: parentDatalistName, thisChildDatalistName:', parentDatalistName, thisChildDatalistName ) };
        var thisChildDatalist = Store.datalists[thisChildDatalistName];
        // if the datalist is sourced from the parentDatalistName, call updateChildDatalist to update the childDatalist.
        if ( thisChildDatalist.datalistSource && thisChildDatalist.datalistSource == parentDatalistName ) {
            updateChildDatalist(thisChildDatalistName, actionsArray);
        }
    }

    if (Store.debug) { console.log(indent() + 'updateAllChildDatalists: returning.') };
    callStackDepth--;
}

function updateChildDatalist(childDatalistName, actionsArray) {
    // this function updates a datalist's data from an existing datalist. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'updateChildDatalist: called.') };

    var thisChildDatalist = Store.datalists[childDatalistName];
    var thisParentDatalistName = thisChildDatalist.datalistSource
    if (thisParentDatalistName) {

        var thisParentDatalist = Store.datalists[thisParentDatalistName];
        // determine if the data is coming from data or searchResults
        if ( thisParentDatalist && thisParentDatalist.data && thisParentDatalist.data.length > 0) {
            var thisParentData = thisParentDatalist.data;
        } else if ( thisParentDatalist && thisParentDatalist.searchRequest && thisParentDatalist.searchRequest.searchResultFlat && thisParentDatalist.searchRequest.searchResultFlat.length > 0 ) {
            var thisParentData = thisParentDatalist.searchRequest.searchResultFlat;
        } else {
            //no data
            if (Store.debug) { console.log(indent() + 'updateChildDatalist: returning. No parent data: child, parent: ', childDatalistName, thisParentDatalistName ) };
            callStackDepth--;
            return;
        }

        var theseDatalistFilters = thisChildDatalist.datalistFilters;
        if ( theseDatalistFilters && theseDatalistFilters.length > 0 ) {
            for ( filterIndex in theseDatalistFilters ) {
                var thisDatalistFilter = theseDatalistFilters[filterIndex];
                if ( thisDatalistFilter.property && thisDatalistFilter.operator && thisDatalistFilter.value ) {
                    // now filter the source data
                    for (thisParentDatalistIndex in thisParentData) {
                        var thisParentDatalistData = thisParentData[thisParentDatalistIndex];
                        //if (Store.debug) { console.log(indent() + 'updateChildDatalist: thisDatalistFilter compare:', thisParentDatalistData, thisDatalistFilter.property, thisDatalistFilter.operator, thisDatalistFilter.value ) };
                        var thisComparisonResults = valueCompare( thisParentDatalistData[thisDatalistFilter.property], thisDatalistFilter.operator, thisDatalistFilter.value )
                        //if (Store.debug) { console.log(indent() + 'updateChildDatalist: thisComparisonResults:', thisComparisonResults ) };
                        if ( thisComparisonResults) {
                            thisChildDatalist.data.push(thisParentDatalistData);
                        }
                    }
                } else {
                    if (Store.debug) { console.log(indent() + 'updateChildDatalist: thisDatalistFilter property or operator or value not set', thisDatalistFilter.property, thisDatalistFilter.operator, thisDatalistFilter.value) };
                }
            }
        } else {
            thisChildDatalist.data.push.apply(thisChildDatalist.data, JSON.parse( JSON.stringify( thisParentData ) ) || [] );
        }
    } else {
        if (Store.debug) { console.log(indent() + 'updateChildDatalist: thisDatalistFilter source was not set', thisDatalistFilter.property, thisDatalistFilter.operator, thisDatalistFilter.value) };
    }
    // now update the child datalist options in the DOM.
    if ( thisChildDatalist.data && thisChildDatalist.data.length > 0 ) {
        setDatalistOptionsFromArray(childDatalistName, thisChildDatalist.data, actionsArray);
    }

    if (Store.debug) { console.log(indent() + 'updateChildDatalist: returning.') };
    callStackDepth--;
}




// Action Functions 
function actionRouter(event) {
    // This process fires every time there is a user action 
        // for performance, this is on a page once, and any element with a 'actionElement' attribute will be processed... all other elements will be ignored
        // 20200304 radical update
        // If the element has an 'actionElement' attribute, the process sets the following for use in subsequent processes
        // - Store.current.actionElementReference - the DOM element that was clicked (object reference)
        // - Store.current.actionElementAction - the action defined in the actionElement attribute (string)
        // - Store.current.actionElementActions - the actions defined in the actionElement attribute (array)
        // - Store.current.actionElementSearchResult - if the user action occurred inside an table/search result, this is the one object in the searchRequest.searchResultFlat that was clicked on (object reference).
        // - Store.current.actionElementSearchRequest - if the user action occurred inside an table/search result, this is the searchRequest that was clicked on (object reference).
        // - Store.current.actionElementSection - if the user action occurred inside a section in the elements, this this the section it occurred in (object reference)
        // - Store.current.actionElementWorkflowStep - this is the workflow step that the action occurred in (object reference)
        // After setting the current properties, the process calls the appropriate action/actions.
    //

    callStackDepth++;
    if (Store.debug) {
        console.log(indent() + 'actionRouter: called... previous step:', Store.current.previousWorkflowStep,
            ', current step:', Store.current.workflowStep, ', workingOnAction:', Store.current.workingOnAction)
    };

    // this verifies that the user has not already taken an action (to prevent clicking the same button multiple times)
    // this looks at what was clicked and determines the action (initially clicks, but more later)

    // prevent multiple requests if the user is "Captain Click" 
    if (!Store.current.workingOnAction) {
        // first look to see if the object clicked has a specific action associated with it...
        if (event.target.getAttribute('actionElementAction')) {

            // create variables with information about what was clicked.
            var clickedActionElement = event.target.getAttribute('actionElementAction');
            if (Store.debug) { console.log(indent() + 'actionRouter: clickedActionElement: ', clickedActionElement) };

            // first execute any specified clickedActionElement actions
            if (clickedActionElement) {
                // process the clicked action
                // set the current working action to avoid multiple actions. 
                Store.current.workingOnAction = clickedActionElement;

                // - Store.current.actionElementWorkflowStep - this is the workflow step that the action occurred in (object reference)
                // - TODO base this on the 
                if (event.target.getAttribute('actionElementWorkflowStepName')) {
                    //if (Store.debug) { console.log(indent() + 'actionRouter: actionElementWorkflowStepName: ', event.target.getAttribute('actionElementWorkflowStepName') )};
                    Store.current.actionElementWorkflowStep = Store.workflowSteps[event.target.getAttribute('actionElementWorkflowStepName')];
                } else {
                    Store.current.actionElementWorkflowStep = Store.currentWorkflowStep;
                }
                // - Store.current.actionElementReference - the DOM element that was clicked (object reference)
                Store.current.actionElementReference = event.target;
                // - Store.current.actionElementAction - the action defined in the actionElement attribute (string)
                Store.current.actionElementAction = clickedActionElement;
                // - Store.current.actionElementActions - the actions defined in the actionElement attribute (array)
                Store.current.actionElementActions = 'TODO';
                // - Store.current.actionElementSearchResult - if the user action occurred inside an table/search result, this is the one object in the searchRequest.searchResultFlat that was clicked on (object reference).
                // - Store.current.actionElementSearchRequest - if the user action occurred inside an table/search result, this is the searchRequest that was clicked on (object reference).
                if (event.target.getAttribute('searchRequestToUse')) {
                    Store.current.clickedSearchRequest = Store.currentWorkflowStep[event.target.getAttribute('searchRequestToUse')];
                } else {
                    Store.current.clickedSearchRequest = Store.currentWorkflowStep.searchRequest || {};
                }
                // - Store.current.actionElementSection - if the user action occurred inside a section in the elements, this this the section it occurred in (object reference)
                

                var clickedID = event.target.id;
                Store.current.clickedID = event.target.id;
                Store.current.clickedElement = event.target;
                Store.current.clickedActionElement = clickedActionElement;
    
                if (Store.debug) { console.log(indent() + 'actionRouter: clickedID: ', clickedID) };
    
                // SRP var currentWorkflowStep = Store.workflowSteps[Store.current.workflowStep];
                var currentWorkflowStep = Store.currentWorkflowStep;
                //Store.current.clickedWorkflowStep = Store.workflowSteps[Store.current.workflowStep];
    
                // set the clicked table in the current object.
                if (event.target.attributes && event.target.attributes.tableName && event.target.attributes.name) {
                    Store.current.clickedTableName = event.target.attributes.tableName.value;
                    Store.current.clickedName = event.target.attributes.name.value;
                    Store.current.clickedSection = getReferenceByPropertyValue(Store.currentWorkflowStep.elements, 'name', Store.current.clickedTableName);
                    Store.current.clickedTable = Store.current.clickedSection; 
                    if (Store.debug) { console.log(indent() + 'actionRouter: Store.current.clickedTable:', JSON.parse(JSON.stringify(Store.current.clickedTable))) };
                }
    
                if (event.target.attributes.resultsDataIndex) {
                    var clickedDataIndex = event.target.attributes.resultsDataIndex.value;
                    if (Store.debug) { console.log(indent() + 'actionRouter: clickedDataIndex: ', clickedDataIndex) };
                }
                if (event.target.attributes.actionsArray) {
                    var clickedActionsArray = event.target.attributes.actionsArray.value;
                    if (Store.debug) { console.log(indent() + 'actionRouter: clickedActionsArray: ', clickedActionsArray) };
                }
    
                // if the clicked element includes a resultsDataIndex (e.g. clicking on a data row), set it in Store.current
                if (clickedDataIndex) {
                    Store.current.clickedDataIndex = clickedDataIndex;
                    // AB 20200520
                    if(Store.current.clickedSearchRequest.searchResultFlat){
                        Store.current.clickedSearchResult = Store.current.clickedSearchRequest.searchResultFlat[clickedDataIndex];
                        if (clickedActionsArray && currentWorkflowStep.actionsArrays[clickedActionsArray]) {
                            if (Store.debug) { console.log(indent() + 'actionRouter: from data index: currentWorkflowStep.actionsArrays[clickedActionsArray]', currentWorkflowStep.actionsArrays[clickedActionsArray]) };
                            processActionArray(currentWorkflowStep, currentWorkflowStep.actionsArrays[clickedActionsArray]);
                            Store.current.workingOnAction = '';
                            if (Store.debug) { console.log(indent() + 'actionRouter: returning. ') };
                            callStackDepth--;
                            return;
                        }
                    } else if (currentWorkflowStep.searchRequest.searchResultFlat) {
                        Store.current.clickedSearchResult = currentWorkflowStep.searchRequest.searchResultFlat[clickedDataIndex];
                        if (clickedActionsArray && currentWorkflowStep.actionsArrays[clickedActionsArray]) {
                            if (Store.debug) { console.log(indent() + 'actionRouter: from data index: currentWorkflowStep.actionsArrays[clickedActionsArray]', currentWorkflowStep.actionsArrays[clickedActionsArray]) };
                            processActionArray(currentWorkflowStep, currentWorkflowStep.actionsArrays[clickedActionsArray]);
                            Store.current.workingOnAction = '';
                            if (Store.debug) { console.log(indent() + 'actionRouter: returning. ') };
                            callStackDepth--;
                            return;
                        }
                    }
                }

                processAction(currentWorkflowStep, clickedActionElement, currentWorkflowStep.actionsArrays[clickedActionsArray]);
            }
            Store.current.workingOnAction = '';
        }
    } else {
        // already working on another click.
        if (Store.debug) { console.log(indent() + 'actionRouter: Store.current.workingOnAction is already set to: ' + Store.current.workingOnAction) };
    }

    if (Store.debug) { console.log(indent() + 'actionRouter: returning.') };
    callStackDepth--;
}

function processAction(workingObject, thisAction, actionsArray) {
    // this function calls a single action 
    // 
    callStackDepth++;
    //if (Store.debug) { console.log(indent() + 'processAction: called.', workingObject, thisAction, actionsArray) };
    if (Store.debug) { console.log(indent() + 'processAction: called: thisAction: ', thisAction) };

    try {
        if (thisAction == 'processActionArray') {
            if (Store.debug) { console.log(indent() + 'processAction: calling processActionArray.: ', workingObject.name ) };
            processActionArray(workingObject, actionsArray);
        } else if (thisAction && thisAction.split(".").length > 1) {
            var thisActionType = thisAction.split(".")[0];
            var thisActionString = thisAction.split(".")[1];
            if (thisActionType === 'datalist') {
                if (Store.debug) { console.log(indent() + 'processAction: .thisAction is a datalist: ', thisAction) };
                updateDatalist(thisAction.split(".")[1], actionsArray);
            } else if (thisActionType === 'workflowStep') {
                if (Store.debug) { console.log(indent() + 'processAction: .thisAction is a workflowStep: ', thisAction) };
                updateUI(thisAction.split(".")[1]);
            } else if (thisActionType === 'function') {
                if (Store.debug) { console.log(indent() + 'processAction: .thisAction is a function: ', thisAction) };
                var thisActionParameters = ''
                var thisActionFunction = thisAction.split(".")[1];
                if (thisActionString.split("(") && thisActionString.split("(")) {
                    thisActionFunction = thisActionString.split("(")[0];
                    thisActionParameters = thisActionString.split("(")[1].split(")")[0];
                }
                window[thisActionFunction](thisActionParameters);
                // TODO: add the ability to append input parameters above.
            } else {
                if (Store.debug) { console.log(indent() + 'processAction: .thisAction could not be found: ', thisAction) };
                Store.current.errorMessage = 'processAction: .thisAction type could not be found: ' + thisActionType + '.'
                setErrorTip();
                clearLoader();
                callStackDepth = 0;
                return;
            }
        } else if (typeof window[thisAction] === "function") {
            if (Store.debug) { console.log(indent() + 'processAction: thisAction is a function: ', thisAction) };
            if (actionsArray && actionsArray.length > 0) {
                window[thisAction](workingObject, actionsArray);
            } else if (workingObject) {
                window[thisAction](workingObject);
            } else {
                window[thisAction]();
            }
        } else if (Store.workflowSteps[thisAction]) {
            if (Store.debug) { console.log(indent() + 'processAction: thisAction is a workflowStep: ', thisAction) };
            updateUI(thisAction);
        } else if (Store.datalists[thisAction]) {
            if (Store.debug) { console.log(indent() + 'processAction: thisAction is a datalist: ', thisAction) };
            updateDatalist(thisAction, actionsArray);
        } else {
            if (Store.debug) { console.log(indent() + 'processAction: thisAction could not be found... try: ', thisAction) };
            Store.current.errorMessage = 'processAction: thisAction could not be found... try: ' + thisAction + '.'
            setErrorTip();
            clearLoader();
            callStackDepth--;
            return;
        }
    }

    catch (err) {
        console.log(err)
        if (Store.debug) { console.log(indent() + 'processAction: thisAction could not be found... catch: ', thisAction) };
        Store.current.errorMessage = 'processAction: thisAction could not be found... catch: ' + thisAction + '.'
        setErrorTip();
        clearLoader();
        callStackDepth--;
        return;
    }
    if (Store.debug) { console.log(indent() + 'processAction: returning.') };
    callStackDepth--;
}

function processActionArray(workingObject, actionsArray) {
    // this action router function conditionally calls 0-n functions 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'processActionArray: called with: workingObject:', workingObject.name ) };

    activeWorkingObject = workingObject

    // call each action in the action array in sequence.
    if (!actionsArray) {
        if (Store.debug) { console.log(indent() + 'processActionArray: nothing to do, returning. ') };
    } else {
        for (var actionIndex = 0; actionIndex < actionsArray.length; actionIndex++) {
            if (Store.debug) { console.log(indent() + 'processActionArray: processing:', actionsArray[actionIndex]) };

            var initialCurrentWorkflowStep = Store.current.workflowStep;
            if (Store.debug) { console.log(indent() + 'processActionArray: initialCurrentWorkflowStep: ', initialCurrentWorkflowStep) };

            if (Store.current.errorMessage) {
                if (Store.debug) { console.log(indent() + 'processActionArray: error has been set: ', Store.current.errorMessage) };
                setErrorTip();
                setSuccessTip();
                clearLoader();
                break;
            }
            // call the action 
            //if (typeof actionsArray[actionIndex] == 'object') {
            if ( Array.isArray( actionsArray[actionIndex] ) ) {
                // need to handle nested actions
                // if the actionsArray[actionIndex] is an array, call the first value with the remaining parameters as the new action elements
                var thisActionItem = actionsArray[actionIndex][0];
                var thisActionItemChildren = [];
                for (var actionItemIndex = 1; actionItemIndex < actionsArray[actionIndex].length; actionItemIndex++) {
                    var thisActionItemChild = actionsArray[actionIndex][actionItemIndex];
                    thisActionItemChildren.push(thisActionItemChild);
                }
            } else {
                var thisActionItem = actionsArray[actionIndex];
                var thisActionItemChildren = [];
            }
            if (Store.debug) { console.log(indent() + 'processActionArray: processAction: '/*, activeWorkingObject*/, thisActionItem/*, thisActionItemChildren*/) }
            processAction( activeWorkingObject, thisActionItem, thisActionItemChildren );
            if ( initialCurrentWorkflowStep != Store.current.workflowStep ) {
                // SRP activeWorkingObject = Store.workflowSteps[Store.current.workflowStep];
                activeWorkingObject = Store.workflowSteps[Store.current.workflowStep];
                // AB activeWorkingObject = Store.currentWorkflowStep;
                if (Store.debug) { console.log(indent() + 'processActionArray: active working object changed to: ', activeWorkingObject.name ) };
            }
        }
    }
    
    if (Store.debug) { console.log(indent() + 'processActionArray: returning. ') };
    callStackDepth--;
}

function singleResultActions() {
    // the following performs the single result redirect if defined on the workingObject
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'singleResultActions: called.') };

    // SRP var workingObject = Store.workflowSteps[Store.current.workflowStep];
    var workingObject = Store.currentWorkflowStep;
    if (workingObject.singleResultActions &&
        workingObject.searchRequest &&
        workingObject.searchRequest.searchResultData &&
        workingObject.searchRequest.searchResultData.length == 1) {
        if (Store.debug) { console.log(indent() + 'singleResultActions: processing single result.') };
        // AB 20200520
        if (Store.current.clickedSearchRequest) {
            Store.current.clickedSearchResult = Store.current.clickedSearchRequest.searchResultFlat[0];
        } else {
            Store.current.clickedSearchResult = workingObject.searchRequest.searchResultFlat[0];
        }
        
        processActionArray(workingObject, workingObject.singleResultActions);
    }
    if (Store.debug) { console.log(indent() + 'singleResultActions: returning. ') };
    callStackDepth--;
}

function noVisibleResultActions() {
    // the following performs the no result redirect if defined on the workingObject
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'noVisibleResultActions: called.') };

    // SRP var workingObject = Store.workflowSteps[Store.current.workflowStep];
    var workingObject = Store.currentWorkflowStep;
    if (workingObject.noVisibleResultActions &&
        workingObject.searchRequest &&
        typeof workingObject.searchRequest.countVisible != 'undefined' &&
        workingObject.searchRequest.countVisible <= 0) {
            if (Store.debug) { console.log(indent() + 'noVisibleResultActions: no visible results.') };
            processActionArray(workingObject, workingObject.noVisibleResultActions);
        }
    if (Store.debug) { console.log(indent() + 'noVisibleResultActions: returning. ') };
    callStackDepth--;
}

var processDefaultAction = function (event) {
    // this function is what allows the user to hit enter and execute the default click event
    if (event.key !== "Enter") return;
    if (!document.getElementById('nextAction')) return;
    document.getElementById('nextAction').click(); // Things you want to do.
    event.preventDefault();
}

function confirmToContinue(continueMessage) {
    // prompts the user to confirm before allowing the user to continue (okay continues, cancel sets error message so the user stays where they are). for use in actions array. 
    callStackDepth++;
    if (Store.debug) {console.log(indent() + 'confirmToContinue: called.')};
    if (Store.debug) {console.log(indent() + 'confirmToContinue: continueMessage: ', continueMessage)};

    var thisContinueMessage = continueMessage || 'Do you want to continue?';
    var continueResponse = confirm(thisContinueMessage);
    if (!continueResponse == true) {
       Store.current.errorMessage = 'Action Canceled.';
        if (Store.debug) {console.log(indent() + 'confirmToContinue: user canceled action.')};
    }

    if (Store.debug) {console.log(indent() + 'confirmToContinue: returning.')};
    callStackDepth--
    return continueResponse;
}

function getWorkingObject(workingObject) {
    // this helper function returns the reference to the working object
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'getWorkingObject: called.') };

    if (!workingObject) {
        // check for a current workflow step with a search object
        // SRP if (Store.workflowSteps[Store.current.workflowStep]) {
        if (Store.currentWorkflowStep) {
            if (Store.debug) { console.log(indent() + 'getWorkingObject: returning with workingObject from current workflowStep.', Store.current.workflowStep) };
            callStackDepth--;
            //return Store.workflowSteps[Store.current.workflowStep];
            return Store.currentWorkflowStep;
        } else {
            if (Store.debug) { console.log(indent() + 'getWorkingObject: returning, no workingObject and no current workflowStep.') };
            callStackDepth--;
            return;
        }
    } else {
        if (typeof workingObject == 'object') {
            if (Store.debug) { console.log(indent() + 'getWorkingObject: returning, workingObject exists.', workingObject.name) };
            callStackDepth--;
            return workingObject;
        } else if (Store.workflowSteps[workingObject]) {
            if (Store.debug) { console.log(indent() + 'getWorkingObject: returning, current workflow step.', workingObject.name) };
            callStackDepth--;
            return Store.workflowSteps[workingObject];
        }
    }
    if (Store.debug) { console.log(indent() + 'getWorkingObject: something else.') };
    callStackDepth--;
    return workingObject;
}

/*function actionOnDataValue(LP) {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'actionOnDataValue: called.') };
    updateUI('commonDetail');
    if (Store.debug) { console.log(indent() + 'actionOnDataValue: returning.') };
    callStackDepth--;
}*/

/*function searchTable(){
    //From MT
    var  nameKey = document.getElementById("globalSearchInput").value;
    for (var i=0; i <= Store.workflowSteps[Store.current.workflowStep].searchRequest['searchResultFlat'].length; i++) {
        if (  Store.workflowSteps[Store.current.workflowStep].searchRequest['searchResultFlat'][i] === nameKey) {
            return Store.workflowSteps[Store.current.workflowStep].searchRequest['searchResultFlat'][i];
        }
    }
    //  updateUI()
} */

function filterTable() {
    // this filters the search results based on user input.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'filterTable: called.') };

    var thisFilterData = Store.currentWorkflowStep[Store.current.clickedSection.searchRequestToUse] || Store.currentWorkflowStep.searchRequest;

    var filterKeyValues = [];
    var theseElements = Store.current.clickedSection.elements; 
    //Checking which columns are selected for Filter 
    for (var thisElementIndex in theseElements ) { 
        var thisElement = theseElements[thisElementIndex]; 
        if (thisElement.filter) {
            filterKeyValues.push(thisElement.name);
        }
    }
    //if (Store.debug) { console.log(indent() + 'filterTable: thisFilterData:', JSON.parse(JSON.stringify(thisFilterData['searchResultFlat'])) ) };
    //if (Store.debug) { console.log(indent() + 'filterTable: filterKeyValues', filterKeyValues); }
    var searchValue = document.getElementById("globalSearchInput").value.toLowerCase().trim();

    //Now filter the data
    if (filterKeyValues.length > 0) {
        if (searchValue.length > 0) {
            var thisData = thisFilterData['searchResultFlat'];
            var thisPropertyValue = '';
            var thisPropertyName = '';
            var filterMatchCount = 0;
            // iterate the list of search results to filter
            for (var sourceDataIndex = 0; sourceDataIndex < thisData.length; sourceDataIndex++) {
                var thisDataObject = thisData[sourceDataIndex];
                //if (Store.debug) { console.log(indent() + 'filterTable: thisDataObject: ', thisDataObject) };
                
                // iterate the filter columns 
                for (var propertyIndex = 0; propertyIndex < filterKeyValues.length ; propertyIndex++ ) {
                    thisPropertyName = filterKeyValues[propertyIndex];
                    //if (Store.debug) { console.log(indent() + 'filterTable: thisPropertyName: ', thisPropertyName) };
                    //if (Store.debug) { console.log(indent() + 'filterTable: thisDataObject[thisPropertyName] : ', thisDataObject[thisPropertyName]) };
                    //if (Store.debug) { console.log(indent() + 'filterTable: typeof thisDataObject[thisPropertyName] : ', typeof thisDataObject[thisPropertyName]) };
                    
                    //set the row to not match
                    thisDataObject.filterMatch = false; 

                    // if the search value entered is found in a property, update it a matching and move tho the next result. 
                    if ( typeof thisDataObject[thisPropertyName] == 'string' ) {
                        thisPropertyValue = thisDataObject[thisPropertyName].toLowerCase();
                        if (thisPropertyValue.indexOf(searchValue) != -1) {
                            if (Store.debug) { console.log(indent() + 'filterTable: string match in: ', thisDataObject[thisPropertyName]) };
                            propertyIndex = filterKeyValues.length; // this stops searching through more properties if the property was found. 
                            thisDataObject.filterMatch = true;  
                            filterMatchCount++;
                        }
                    } else if ( typeof thisDataObject[thisPropertyName] == 'number' ) {
                        thisPropertyValue = thisDataObject[thisPropertyName];
                        if ( thisPropertyValue == searchValue ) {
                            if (Store.debug) { console.log(indent() + 'filterTable: number match to: ', thisDataObject[thisPropertyName]) };
                            propertyIndex = filterKeyValues.length; // this stops the process from searching through more properties if the value was found.
                            thisDataObject.filterMatch = true;  
                            filterMatchCount++;
                        }
                    }
                }
            }
        } else {
            // if there was no filter input, show all the flat data
            for (var flatDataObjectIndex = 0 ; flatDataObjectIndex < thisFilterData['searchResultFlat'].length ; flatDataObjectIndex++ ) { 
                delete thisFilterData['searchResultFlat'][flatDataObjectIndex].filterMatch;
            }
        }
        
        // update the row visibility 
        updateSearchResultVisibility(thisFilterData);
        thisFilterData.lastFilterInput = searchValue;

        // update the UI
        updateUI();
    }

    if (Store.debug) { console.log(indent() + 'filterTable: returning. ') };
    callStackDepth--;
}

function sortTable() {
    // This function sets/toggles the sort direction on column labels (if the column is sortable), sorts, and recalls the UI. 
    // TODO: add multi-level sorting (each sorts adds or updates itself in the sortArray)
    // TODO: add Table-level sort action (e.g. the default behavior)
    // TODO: persist the table's sort in the workflow step.  e.g. Store.workflowSteps.sampleStep.sections[tableSection].sort = [ {columnName4,asc}, {columnName2, desc} ]
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'sortTable: called.') };

    if (Store.debug) { console.log(indent() + 'sortTable: clickedTableName, clickedName:', Store.current.clickedTableName, Store.current.clickedName, JSON.parse(JSON.stringify(Store.current.clickedSection)) ) };
    updateSectionSort();

    // set the sort order...
    var sortDirection = '';
    for (var thisElementIndex in Store.current.clickedSection.elements) { //(var thisElementIndex in theseElements[thisClickedSectionIndex].elements) {
        var thisElement = Store.current.clickedSection.elements[thisElementIndex];
        if (thisElement.name === Store.current.clickedName) {
            if (!thisElement.sortDirection) {
                thisElement.sortDirection = '';
                if (Store.debug) { console.log(indent() + 'sortTable: set to ""') };
            }
            if (thisElement.sortDirection == 'asc') { //|| thisElement.sortDirection == '') {
                thisElement.sortDirection = 'desc';
                sortDirection = 'desc';
                if (Store.debug) { console.log(indent() + 'sortTable: asc set to thisElement.sortDirection', thisElement.sortDirection) };
            } else { //if (thisElement.sortDirection == 'desc') {
                thisElement.sortDirection = 'asc';
                sortDirection = 'asc';
                if (Store.debug) { console.log(indent() + 'sortTable: desc set to thisElement.sortDirection', thisElement.sortDirection) };
            }
        }
        else {
            thisElement.sortDirection = '';
        }
    }

    var sortArray = [{ 'propertyName': Store.current.clickedName, 'sortDirection': sortDirection }];
    if (Store.debug) { console.log(indent() + 'sortTable: Store.current.clickedSection.sortArray', JSON.parse(JSON.stringify(Store.current.clickedSection.sortArray))) };
    if (Store.debug) { console.log(indent() + 'sortTable: sortArray', JSON.parse(JSON.stringify(sortArray))) };

    //Store.currentWorkflowStep.searchRequest['searchResultFilter'].sort(sortCompare(sortArray));
    Store.currentWorkflowStep.searchRequest['searchResultFlat'].sort(sortCompare(sortArray));
    //TODO @SRP verify that we are not already sorting in another function 
    //if (Store.debug) { console.log(indent() + 'sortTable: sorted:', JSON.parse(JSON.stringify(Store.workflowSteps[Store.current.workflowStep].searchRequest['searchResultFilter']))) };

    updateUI();

    //if (Store.debug) { console.log(indent() + 'sortTable: sorted:', JSON.parse(JSON.stringify(Store.workflowSteps[Store.current.workflowStep].searchRequest['searchResultFilter']))) };

    if (Store.debug) { console.log(indent() + 'sortTable: returning.') };
    callStackDepth--;
}


function updateSectionSort() {
    // This function sets/toggles the sort direction on column labels (if the column is sortable), sorts, and recalls the UI. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'updateSectionSort: called.') };
    if (Store.debug) { console.log(indent() + 'updateSectionSort: clickedTableName, clickedName, Store.current.clickedSection:', Store.current.clickedTableName,  Store.current.clickedName, JSON.parse(JSON.stringify(Store.current.clickedSection))) };

    //Set the current section sort array if there isn't one.
    if (!Store.current.clickedSection.sortArray) {
        if (Store.debug) { console.log(indent() + 'updateSectionSort: Store.current.clickedSection:', JSON.parse(JSON.stringify(Store.current.clickedSection))) };
        Store.current.clickedSection.sortArray = [];
        for (var thisElement in Store.current.clickedSection.elements) {
            var thisElementSort = {};
            //if (thisElement.sortDirection) {
            if (thisElement.sortDirection) {
                thisElementSort.propertyName = thisElement.name;
                thisElementSort.sortDirection = thisElement.sortDirection;
                Store.current.clickedSection.sortArray.push(thisElementSort);
            }
        }
    }

    var thisSortArray = Store.current.clickedSection.sortArray;
    if (Store.debug) { console.log(indent() + 'updateSectionSort: Store.current.clickedSection, thisSortArray:', Store.current.clickedSection, thisSortArray) };

    // Add or toggle the clicked property in the section's sortArray object
    if (Store.current.clickedName) {
        var sortObjectIndex = -1;
        var toggledSortObject = { propertyName: Store.current.clickedName, sortDirection: 'asc' };
        for (var thisSortObjectIndex = 0; thisSortObjectIndex < thisSortArray.length; thisSortObjectIndex++) {
            var thisSortObject = thisSortArray[thisSortObjectIndex];
            if (thisSortObject.propertyName === Store.current.clickedName) {
                sortObjectIndex = thisSortObjectIndex;
                toggledSortObject.propertyName = thisSortObject.propertyName;
                // toggle the sor direction if column clicked is in the 0 index
                if (thisSortObjectIndex == 0 && thisSortObject.sortDirection === 'asc') {
                    toggledSortObject.sortDirection = 'desc';
                } else if (thisSortObjectIndex == 0 && thisSortObject.sortDirection === 'desc') {
                    toggledSortObject.sortDirection = 'asc';
                }
                // remove the sortObject so it can be added in the 0 position
                thisSortArray.splice(thisSortObjectIndex, 1);
            }
        }
    }
    thisSortArray.unshift(toggledSortObject);

    if (Store.debug) { console.log(indent() + 'updateSectionSort: sortArray:', thisSortArray) };
    // TODO: separate flat, sorted, and filtered arrays. 
    // write the sorted/filtered... display array to the section?
    //if (!Store.current.clickedSection.data) {
    //    Store.current.clickedSection.data = [];
    //} else {
    //    Store.current.clickedSection.data.length = 0;
    //}
    if (Store.current.clickedSection.searchRequestToUse) {
        var workflowStepSourceData =  Store.currentWorkflowStep[Store.current.clickedSection.searchRequestToUse]['searchResultFlat']; //['searchResultFilter'];
    } else {
        var workflowStepSourceData =  Store.currentWorkflowStep.searchRequest['searchResultFlat']; //['searchResultFilter'];
    }

    //addToArray(Store.current.clickedSection.data, workflowStepSourceData, 'addValueToEnd');

    // TODO @SRP can/should we sort "flat"??
    //workflowStepSourceData.searchResultFlat.sort(sortCompare(thisSortArray));
    workflowStepSourceData.sort(sortCompare(thisSortArray));

    //Store.current.clickedSection.data.sort(sortCompare(thisSortArray));
    //if (Store.debug) { console.log(indent() + 'updateSectionSort: sorted:', JSON.parse(JSON.stringify(Store.current.clickedSection.data))) };

    if (Store.debug) { console.log(indent() + 'updateSectionSort: returning.') };
    callStackDepth--;
}






// UI Functions 
function goBackToCaller() {
    // this function is used to navigate back to the page that called the SuiteSPA
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'goBackToCaller: called.') };
    
    window.history.back();
    callStackDepth--;
    return false;

    if (Store.debug) { console.log(indent() + 'goBackToCaller: returning.') };
    callStackDepth--;
}

function closeTab(){
    callStackDepth++;
    // this function closes the current tab
    if (Store.debug) { console.log(indent() + 'closeTab: called.') };

    var conf=confirm("Are you sure, you want to close this tab?");
    if(conf==true){
        close();
    }

    if (Store.debug) { console.log(indent() + ': returning.') };
    callStackDepth--;
}

/*function setDefaultValue(targetInput, sourceValue) {
    // this function sets the default values on input elements. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setDefaultValue: called.') };

    targetInput.value = sourceValue;

    if (Store.debug) { console.log(indent() + 'setDefaultValue: returning.') };
    callStackDepth--;
}*/

function setBody() {
    callStackDepth++;
    // This function renders the correct body content
    if (Store.debug) { console.log(indent() + 'setBody: called.') };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'setBody: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    var bodyContent = document.getElementById(workingObject.name);

    // if the element is not in the DOM, try to build it.
    if (!bodyContent) {
        //if (Store.debug) { console.log(indent() + 'setBody: no body content: workingObject.inputs.length', workingObject.inputs.length || 'NA' ) };
        workingObject.inputs = [];
        if (Store.debug) { console.log(indent() + 'setBody: called.') };
        makePresentation(workingObject);
        bodyContent = document.getElementById(workingObject.name);
    } else {
        // NOTE: this condition will eventually be used to reuse the existing form if performance of recreating the UI with makePresentation ever becomes noticeable.
        bodyContent.innerHTML = '';
        workingObject.inputs = [];
        makePresentation(workingObject);
        bodyContent = document.getElementById(workingObject.name);
    }
    //if (Store.debug) { console.log(indent() + 'setBody: bodyContent', bodyContent) };

    // AB 20190815 Added validation on bodyContent -> fixing error where there is no input field on screen
    if(bodyContent){ 
        // Now show the body
        // Note: deferring the display of the body in the DOM until after all the DOM manipulation removes jank and significantly improves performance.
        bodyContent.setAttribute('style', 'display: block;'); //SRP 20190614 - this is setting all to block... move to CSS?
    }
    
    //now set focus 
    if(document.querySelector('input.inputField:enabled')) { //bodyContent){ //SRP 20201231
        //Now set the focus on the first input
        if (document.querySelector('input.inputField[autofocus]')) {
            document.querySelector('input.inputField[autofocus]').focus();
            //if (Store.debug) { console.log(indent() + 'setBody: auto-focusing on:',document.querySelector('input.inputField[autofocus]')) };
        } else if (document.querySelector('input.inputField:enabled')) {
            document.querySelector('input.inputField:enabled').focus();
            //if (Store.debug) { console.log(indent() + 'setBody: focusing on:',document.querySelector('input.inputField:enabled')) };
        } 
    }


    if (Store.debug) { console.log(indent() + 'setBody: returning.') };
    callStackDepth--;
}

function prepareInputObject( workflowStep ) {
    callStackDepth++;
    // This function adds the input object if it does not already exist
    if (Store.debug) { console.log(indent() + 'prepareInputObject: called.') };

    // get the thisWorkflowStep Object
    if (!workflowStep) {
        console.log(indent() + 'prepareInputObject: using currentWorkflowStep.');
        var thisWorkflowStep = Store.currentWorkflowStep;
    } else if ( typeof workflowStep === 'object' ) {
        console.log(indent() + 'prepareInputObject: using workflowStep:', workflowStep.name );
        var thisWorkflowStep = workflowStep;
    } else {
        console.log(indent() + 'prepareInputObject: could not find workflowStep:', workflowStep );
        Store.current.errorMessage = 'Sorry, I could not find the workflowStep.'

        if (Store.debug) { console.log(indent() + 'prepareInputObject: returning.') };
        callStackDepth--;
        return;
    }

    // add the inputObject if it does not exist.
    if ( !thisWorkflowStep.inputObject ) {
        thisWorkflowStep.inputObject = {};
        
        // find all inputs and in the workflowStep
        for ( var elementsIndex in thisWorkflowStep.elements) {
            var thisSection = thisWorkflowStep.elements[elementsIndex];

            if ( thisSection.type == 'section' && thisSection.elements && thisSection.elements.length > 0 ) {
                for ( var elementsIndex in thisSection.elements) {
                    var thisInput = thisSection.elements[elementsIndex];

                    if ( thisInput.type == 'input' ) {
                        thisWorkflowStep.inputObject[thisInput.name] = thisInput;
                    }
                }
            }
        }
    }
    //if (Store.debug) { console.log(indent() + 'prepareInputObject: thisWorkflowStep.inputObject:', JSON.parse( JSON.stringify( thisWorkflowStep.inputObject ) ) ) };

    if (Store.debug) { console.log(indent() + 'prepareInputObject: returning.') };
    callStackDepth--;
}

function makePresentation(workingObject, presentationObject, targetElementID) {
    //this function builds the UI from a presentation object in the Store... 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'makePresentation: called.') };

    // get the working Object and return if not valid
    if (!workingObject) {
        console.log(indent() + 'makePresentation: no workingObject, returning.');
        callStackDepth--;
        return;
    }
    var thisWorkflowStepName = workingObject.name
    if (workingObject.type) {
        console.log(indent() + 'makePresentation: the working object is of type:',workingObject.type);
    }

    if (Store.current.clickedSearchResult) {
        var thisClickedSearchResult = Store.current.clickedSearchResult;
        //if (Store.debug) { console.log(indent() + 'makePresentation: thisClickedSearchResult', JSON.parse(JSON.stringify(thisClickedSearchResult))) };
    }

    if (!presentationObject) { var presentationObject = workingObject; }
    // first verify there are elements to process.
    if (presentationObject['elements']) {

        //prepare the array of elements to process
        var presentationObjectElements = presentationObject['elements'];

        //get a reference to the DOM element that we will add the elements to.
        var targetElement = document.getElementById(targetElementID || 'workflowBodyArea');

        // Now iterate over the array of elements, doing something with each element
        for (var elementIndex = 0; elementIndex < presentationObjectElements.length; elementIndex++) {
            var presentationObjectElement = presentationObjectElements[elementIndex];

            //if (Store.debug) { console.log(indent() + 'makePresentation: presentationObjectElement:',presentationObjectElement ) };

            // Process Sections
            if (presentationObjectElement.type == 'section') {

                if (presentationObjectElement.typeAs == 'orderedList') {
                    // If section typeAs is ordered list, build the OL container
                    var newOLDiv = document.createElement('div');
                    newOLDiv.setAttribute('id', presentationObjectElement.id || presentationObjectElement.name);
                    newOLDiv.setAttribute('class', presentationObjectElement.class || '');
                    newOLDiv.setAttribute('actionElementSectionName', presentationObjectElement.id || presentationObjectElement.name);

                    var newElementOL = document.createElement('ol');
                    newElementOL.setAttribute('id', (presentationObjectElement.id || presentationObjectElement.name) + 'OrderedList');
                    newElementOL.setAttribute('class', presentationObjectElement.classOrderedList || '');
                    newOLDiv.appendChild(newElementOL);
                    targetElement.appendChild(newOLDiv);
                } else { // Build a div
                    //if (Store.debug) { console.log(indent() + 'makePresentation: Not an ordered List...', JSON.stringify(presentationObjectElement) ) };
                    var newElementDiv = document.createElement('div');
                    newElementDiv.setAttribute('id', presentationObjectElement.id || presentationObjectElement.name);
                    newElementDiv.setAttribute('class', presentationObjectElement.class || '');
                    targetElement.appendChild(newElementDiv);
                }

                // Print Section Label 
                if (presentationObjectElement.typeAs != 'hidden' && presentationObjectElement.label) {
                    //if (Store.debug) { console.log(indent() + 'makePresentation: In Section Label...', JSON.stringify(presentationObjectElement) ) };
                    var newElementLabel = document.createElement('label');
                    newElementLabel.setAttribute('for', presentationObjectElement.id || presentationObjectElement.name);
                    newElementLabel.setAttribute('class', 'sectionLabel ' + (presentationObjectElement.labelClass || ''));
                    newElementLabel.innerHTML = getLanguageText(presentationObjectElement.label);
                    newElementDiv.appendChild(newElementLabel);
                }

                // Process List Items
            } else if (presentationObjectElement.type == 'listItem') {
                // get the list 
                targetOL = document.getElementById(targetElementID + 'OrderedList');
                // build a list item object to append to the list
                var newListItem = document.createElement('li');
                // determine if the list item has actions 
                if (presentationObjectElement.action || presentationObjectElement.actions) {
                    // set the action
                    var thisAction = presentationObjectElement.action || 'processActionArray';
                    newListItem.setAttribute('actionElementAction', thisAction);
                    newListItem.setAttribute('actionElementWorkflowStepName', thisWorkflowStepName);
                    //newListItem.setAttribute('actionElementSearchRequestName', thisAction);
                    newListItem.setAttribute('actionElementSectionName', presentationObjectElement.name);
                    newListItem.setAttribute('actionElementWorkflowStepName', thisWorkflowStepName);
                }

                if (thisAction == 'processActionArray') {
                    if (presentationObjectElement.actions) {
                        if (!workingObject.actionsArrays) {
                            workingObject.actionsArrays = {};
                        }
                        workingObject.actionsArrays[presentationObjectElement.name] = presentationObjectElement.actions;
                        targetOL.setAttribute('actionsArray', presentationObjectElement.name);
                    }
                    newListItem.setAttribute('actionsArray', presentationObjectElement.name);
                }

                newListItem.setAttribute('class', 'menuItem');
                newListItem.innerHTML = getLanguageText(presentationObjectElement.label);

                targetOL.appendChild(newListItem);

                // Process Inputs 
            } else if (presentationObjectElement.type == 'input') {
                // SRP 20190505 Temp
                //if (Store.debug) { console.log(indent() + 'makePresentation: this input', JSON.stringify(presentationObjectElement) ) };
                //if (Store.debug) { console.log(indent() + 'makePresentation: presentationObjectElement:',presentationObjectElement) };

                //build the input group div
                var newElementDiv = document.createElement('div');
                newElementDiv.setAttribute('class', presentationObjectElement.inputGroupClass || 'inputGroup');
                targetElement.appendChild(newElementDiv);

                //build the input label
                if (presentationObjectElement.typeAs != 'hidden' || presentationObjectElement.label) {
                    var newElementLabel = document.createElement('label');
                    newElementLabel.setAttribute('for', presentationObjectElement.id || presentationObjectElement.name);
                    //newElementLabel.setAttribute('class', 'inputLabel');
                    newElementLabel.setAttribute('class', 'inputLabel ' + (presentationObjectElement.labelClass || ''));
                    newElementLabel.innerHTML = getLanguageText(presentationObjectElement.label);
                    newElementDiv.appendChild(newElementLabel);
                }

                //build the input
                if (presentationObjectElement.visibility == 'readonly') {
                    var newElementInput = document.createElement('div');
                } else if ( presentationObjectElement.typeAs != 'textarea' ) {
                    var newElementInput = document.createElement('input');
                } else if ( presentationObjectElement.typeAs === 'textarea' ) {
                    var newElementInput = document.createElement('textarea');
                } 

                if (presentationObjectElement.typeAs === 'hiddenInput') {
                    newElementInput.setAttribute('type', 'hidden');
                } else if (presentationObjectElement.typeAs) {
                    newElementInput.setAttribute('type', presentationObjectElement.typeAs);
                } else if (presentationObjectElement.type != 'input') { // note, this should never be a valid in this input section.
                    newElementInput.setAttribute('type', presentationObjectElement.type);
                } else {
                    newElementInput.setAttribute('type', 'text');
                }

                newElementInput.setAttribute('id', presentationObjectElement.id || presentationObjectElement.name);

                if (presentationObjectElement.visibility == 'readonly') {
                    newElementInput.setAttribute('class', 'inputReadOnly ' + (presentationObjectElement.class || ''));
                } else if (presentationObjectElement.typeAs == 'image') {
                    newElementInput.setAttribute('class', 'formImage ' + (presentationObjectElement.class || ''));
                } else {
                    newElementInput.setAttribute('class', 'inputField ' + (presentationObjectElement.class || ''));
                }

                if (presentationObjectElement.visibility) {
                    if (presentationObjectElement.visibility == 'readonly') {
                        newElementInput.setAttribute('readonly', 'readonly');
                    } else if (presentationObjectElement.visibility == 'disabled') {
                        newElementInput.setAttribute('disabled', 'disabled');
                    }
                }

                if (presentationObjectElement.datalistSource) {
                    newElementInput.setAttribute('list', presentationObjectElement.datalistSource);
                } else if (presentationObjectElement.datalistValues) {
                    newElementInput.setAttribute('list', presentationObjectElement.name + 'Datalist');
                    var newDatalist = document.createElement('datalist');
                    newDatalist.setAttribute('id', presentationObjectElement.name + 'Datalist');
                    for (var datalistValueIndex = 0; datalistValueIndex < presentationObjectElement.datalistValues.length; datalistValueIndex++) {
                        var newDatalistValue = document.createElement('option');
                        newDatalistValue.innerHTML = presentationObjectElement.datalistValues[datalistValueIndex];
                        newDatalist.appendChild(newDatalistValue);
                    }
                    newElementInput.appendChild(newDatalist);
                }

                if ( presentationObjectElement.valueDefault ) {
                    if ( presentationObjectElement.visibility == 'readonly' ) {
                        newElementInput.setAttribute('value', presentationObjectElement.valueDefault);
                        newElementInput.innerHTML = presentationObjectElement.valueDefault || '&nbsp;';
                    } else if ( presentationObjectElement.typeAs == 'textarea' ) {
                        newElementInput.setAttribute('value', presentationObjectElement.valueDefault);
                        newElementInput.innerHTML = presentationObjectElement.valueDefault || '&nbsp;';
                        if (Store.debug) { console.log(indent() + 'makePresentation: textarea: ', newElementInput ) };
                    } else if (presentationObjectElement.typeAs == 'image') {
                        if (presentationObjectElement.valueDefault) {
                            newElementInput.setAttribute('src', presentationObjectElement.valueDefault);
                            newElementInput.innerHTML = presentationObjectElement.valueDefault || 'not defined';
                        }
                    } else {
                        newElementInput.setAttribute('value', presentationObjectElement.valueDefault);
                    }
                }

                // if the input is being rendered for a selected search result, get the value from the search result.
                if (presentationObjectElement.valueDefaultProperty && thisClickedSearchResult) {
                    if (presentationObjectElement.visibility == 'readonly') {
                        newElementInput.setAttribute('value', thisClickedSearchResult[presentationObjectElement.valueDefaultProperty]);
                        newElementInput.innerHTML = thisClickedSearchResult[presentationObjectElement.valueDefaultProperty] || '&nbsp;';
                    } else if (presentationObjectElement.typeAs == 'image') {
                        if (thisClickedSearchResult[presentationObjectElement.valueDefaultProperty]) {
                            newElementInput.setAttribute('src', thisClickedSearchResult[presentationObjectElement.valueDefaultProperty]); //  || 'not set'
                        } else {
                            newElementInput.setAttribute('src', Store.defaults.defaultImage); //  || 'not set'
                            newElementInput.innerHTML = '&nbsp;';
                        }
                        //newElementInput.innerHTML = thisClickedSearchResult[presentationObjectElement.valueDefaultProperty] || '&nbsp;';
                    } else {
                        newElementInput.value = thisClickedSearchResult[presentationObjectElement.valueDefaultProperty];
                    }
                }

                //if (Store.debug) { console.log(indent() + 'makePresentation: I have a valueDefault: ',presentationObjectElement ) };

                if (presentationObjectElement.valueDefaultProperty && presentationObjectElement.valueDefaultObject) {
                    //if (Store.debug) { console.log(indent() + 'makePresentation: I am: presentationObjectElement.valueDefaultProperty && presentationObjectElement.valueDefaultObject', presentationObjectElement.valueDefaultProperty, presentationObjectElement.valueDefaultObject) };
                    
                    // if the valueDefaultObject is a string, get the object (late bound) or just use the object reference. 
                    var valueDefaultObjectReference = getReferenceFromPath(presentationObjectElement.valueDefaultObject);

                    if (presentationObjectElement.visibility == 'readonly') {
                        newElementInput.setAttribute('value', valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty]);
                        if (valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty]) {
                            var presentationObjectElementValue = valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty];
                            if (presentationObjectElement.displayTransformation) {
                                presentationObjectElementValue = displayTransformation(presentationObjectElementValue, presentationObjectElement.displayTransformation)
                            }
                            newElementInput.innerHTML = presentationObjectElementValue || '&nbsp;';
                        } else if (valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty] == 0) {
                            newElementInput.innerHTML = '0';
                        } else {
                            newElementInput.innerHTML = '&nbsp;';
                        }
                    } else if (presentationObjectElement.typeAs == 'image') {
                        newElementInput.setAttribute('value', valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty]);
                        if (valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty]) {
                            var presentationObjectElementValue = valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty];
                            if (presentationObjectElement.displayTransformation) {
                                presentationObjectElementValue = displayTransformation(presentationObjectElementValue, presentationObjectElement.displayTransformation)
                            }
                            newElementInput.src = presentationObjectElementValue || '&nbsp;';
                        } else {
                            newElementInput.innerHTML = '&nbsp;';
                        }
                    } else {
                        newElementInput.value = valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty];
                    }
                }

                if ( presentationObjectElement.recallLastValue === true ) {
                    if (presentationObjectElement.visibility == 'readonly') {
                        newElementInput.setAttribute('value', presentationObjectElement.inputValue || '');
                        newElementInput.innerHTML = presentationObjectElement.inputValue || '&nbsp;';
                    } else {
                        //if (Store.debug) { console.log(indent() + 'makePresentation: presentationObjectElement', JSON.parse(JSON.stringify(presentationObjectElement || {}))) };
                        if (workingObject.inputValuesHistory && workingObject.inputValuesHistory[elementIndex]) {
                            //if (Store.debug) { console.log(indent() + 'makePresentation: workingObject.inputValuesHistory[elementIndex]', JSON.parse(JSON.stringify(workingObject.inputValuesHistory || {}))) };
                            newElementInput.value = getArrayValueByPropertyValue(workingObject.inputValuesHistory,'name',presentationObjectElement.name,'inputValue'); //workingObject.inputValuesHistory[elementIndex]['inputValue'];
                        } else {
                            newElementInput.value = presentationObjectElement.inputValue || '';
                        }
                    }
                }
                /////////////////////////////////////////
                //                if (presentationObjectElement.actionFocusOut) {
                //                    newElementInput.setAttribute('onfocusout', presentationObjectElement.actionFocusOut+"(this, event)");
                //                }
                ////////////////////////////////////////

                if (presentationObjectElement.min) {
                    newElementInput.setAttribute('min', presentationObjectElement.min);
                }

                if (presentationObjectElement.max) {
                    newElementInput.setAttribute('max', presentationObjectElement.max);
                }

                if (presentationObjectElement.required) {
                    newElementInput.setAttribute('required', '');
                }

                if ( presentationObjectElement.initialFocus ) {
                    newElementInput.setAttribute('autofocus', '');
                }

                newElementDiv.appendChild(newElementInput);

                //build the current inputs in the Store 
                // change to call setWorkingInputs?

                if (!workingObject.inputs) {
                    workingObject.inputs = [];
                }
                // SRP 20190505: changing the following to make the new inputs object have the value and not a reference to the elements
                //workingObject.inputs.push(presentationObjectElement);
                var thisPresentationObjectElement = JSON.parse(JSON.stringify(presentationObjectElement));
                workingObject.inputs.push( thisPresentationObjectElement );

                // now build the inputObject // 20210504 SRP 
                if (!workingObject.inputObject) {
                    workingObject.inputObject = {};
                }
                workingObject.inputObject[thisPresentationObjectElement.name] = thisPresentationObjectElement;

                // Process Search Results 
            } else if (presentationObjectElement.type == 'searchResultsTable') {

                var thisSearchRequest = {}; //Store.currentWorkflowStep.searchRequest;
                var thisSection = presentationObjectElement;
                var thisData = [];
                var thisTableId = '';

                // Select the Data Source for the Table
                //if (Store.debug) { console.log(indent() + 'makePresentation: thisSearchRequest', JSON.parse(JSON.stringify(thisSearchRequest))) };
                if (typeof (presentationObjectElement.searchRequestToUse) !== 'undefined') {
                    thisSearchRequest = Store.currentWorkflowStep[presentationObjectElement.searchRequestToUse];
                    //if (Store.debug) { console.log(indent() + 'makePresentation: thisSearchRequest', JSON.parse(JSON.stringify(thisSearchRequest))) };
                    thisTableId = presentationObjectElement.searchRequestToUse + '_table_' + elementIndex;
                    var searchRequestToUse = presentationObjectElement.searchRequestToUse;
                } else {
                    thisSearchRequest = Store.currentWorkflowStep.searchRequest;
                    thisTableId = (thisSearchRequest.name || Store.currentWorkflowStep.name) + '_table';
                }
                //if (Store.debug) { console.log(indent() + 'makePresentation: thisSearchRequest', JSON.parse(JSON.stringify(thisSearchRequest))) };

                // Define the data to use within the Selected search request
                if (thisSearchRequest['searchResultFlat']) {
                    //if (Store.debug) { console.log(indent() + 'makePresentation: using thisSearchRequest[searchResultFlat]', thisSearchRequest['searchResultFlat']) };
                    thisData = thisSearchRequest['searchResultFlat'];
                }
                //if (Store.debug) { console.log(indent() + 'makePresentation: thisData', JSON.parse(JSON.stringify(thisData))) };

                // determine if table should be rendered. 
                var renderTable = true;
                if (presentationObjectElement.typeAs === 'hidden') {
                    renderTable = false;
                } else if (thisData.length == 0) {
                    if (thisSearchRequest.hideIfEmpty === true) {
                        renderTable = false;
                    } else if (thisSearchRequest.renderIfEmpty === false) { //TODO: I want to flip this to default to showing tables unless specific se to hide if empty... property:hideIfEmpty
                        renderTable = false;
                    }
                }
                
                //&& presentationObjectElement.label

                // prepare and render table
                if (renderTable === true) {
                    // Build a table div
                    var newElementDiv = document.createElement('div');
                    newElementDiv.setAttribute('id', presentationObjectElement.id || presentationObjectElement.name);
                    newElementDiv.setAttribute('class', 'searchResultsArea ' + presentationObjectElement.class || '');

                    // add a table pre-header if the table has a label or a search filter (or in the future, other table tools)
                    if (presentationObjectElement['filterAction'] || 
                        presentationObjectElement.label || 
                        (typeof presentationObjectElement.hideRowCounts === 'undefined' && Store.defaults.hideRowCounts === false) || 
                        presentationObjectElement.hideRowCounts === false ) {

                        var tablePreHeaderArea = document.createElement('span');
                        tablePreHeaderArea.setAttribute('class','tablePreHeaderArea ' + (presentationObjectElement.tablePreHeaderAreaClass || '') );

                        // show the table caption label if defined
                        if (presentationObjectElement.label) {
                            var newTableLabel = document.createElement('label');
                            newTableLabel.setAttribute('for', presentationObjectElement.id || presentationObjectElement.name);
                            newTableLabel.setAttribute('class', 'tableLabel ' + (presentationObjectElement.labelClass || ''));
                            newTableLabel.innerHTML = getLanguageText(presentationObjectElement.label);
                            tablePreHeaderArea.appendChild(newTableLabel);
                        }

                        // show record counts here
                        if (presentationObjectElement.hideRowCounts === false) {
                            
                            // make sure the totals are current ... in a perfect world, this would be called when each process changed the searchResultFlat
                            updateSearchResultVisibility(thisSearchRequest);

                            // build the count summary
                            var newRowCountArea = document.createElement('span');
                            newRowCountArea.setAttribute('class', 'tableRowCountArea tableRowCountTipArea' + (presentationObjectElement.tableRowCountAreaClass || ''));
                            var countTotal = thisSearchRequest.countTotal;
                            var countVisible = thisSearchRequest.countVisible;
                            var tableRowCountString = ' Showing ' + countVisible + ' of ' + countTotal;
                            newRowCountArea.innerHTML = getLanguageText(tableRowCountString);
                            tablePreHeaderArea.appendChild(newRowCountArea);

                            // build the tool tip with all the stats...
                            var newRowCountTip = document.createElement('span');
                            newRowCountTip.setAttribute('class', 'tableRowCountTipText ' + (presentationObjectElement.tableRowCountAreaClass || ''));
                            var countFilterMatch = thisSearchRequest.countFilterMatch;
                            var countProcessed = thisSearchRequest.countProcessed;
                            var tableRowCountTipHTML =  'Showing: ' + countVisible + '<br>' +
                                ' of Total Results: ' + countTotal + '<br>' +
                                ' Including Filter Matches: ' + countFilterMatch + '<br>' +
                                ' Excluding Processed Entries: ' + countProcessed;
                            newRowCountTip.innerHTML = getLanguageText(tableRowCountTipHTML);
                            newRowCountArea.appendChild(newRowCountTip);

                        }

                        // show the table filter
                        if (presentationObjectElement['filterAction']) { // From MT
                            //TODO this needs to be refactored into a form defined as section object, not hard coded here. 
                            
                            // Build the filter area
                            var searchElementArea = document.createElement('span');
                            searchElementArea.setAttribute('class','tableFilterArea ' + (presentationObjectElement.tableFilterAreaClass || '') );

                            //add the filter input
                            var tableFilterInput = document.createElement("input");
                            tableFilterInput.setAttribute("type", "search");
                            tableFilterInput.setAttribute("class", "tableFilterInput " + (presentationObjectElement.tableFilterInputClass || '') );
                            tableFilterInput.setAttribute('id', 'globalSearchInput');
                            if (countTotal !== countVisible && thisSearchRequest.lastFilterInput)  {
                                var lastFilterInput = thisSearchRequest.lastFilterInput;
                                tableFilterInput.setAttribute('value', lastFilterInput);
                            } 
                            searchElementArea.appendChild(tableFilterInput);

                            //add the filter button
                            tableFilterButton = document.createElement("span");
                            tableFilterButton.setAttribute("id", "actionElement");
                            tableFilterButton.setAttribute("name", "actionElement");
                            tableFilterButton.setAttribute('tableName', presentationObjectElement.name); // thisTableId ); //
                            tableFilterButton.setAttribute("class", "tableFilterButton " + (presentationObjectElement.tableFilterInputClass || '') );
                            tableFilterButton.setAttribute('actionElementAction', presentationObjectElement['filterAction']);
                            tableFilterButton.setAttribute('actionElementWorkflowStepName', thisWorkflowStepName);
                            globalSearchFilterBtnLabel = document.createTextNode("Filter");
                            tableFilterButton.appendChild(globalSearchFilterBtnLabel);
                            searchElementArea.appendChild(tableFilterButton);

                            //TODO add a clear filter button

                            tablePreHeaderArea.appendChild(searchElementArea);
                        }

                        newElementDiv.appendChild(tablePreHeaderArea);
                    }

                    targetElement.appendChild(newElementDiv);

                    //build the table
                    var newElementTable = document.createElement('table');
                    newElementTable.setAttribute('class', 'resultsTable ' + (presentationObjectElement.resultsTableClass || '') );
                    newElementTable.setAttribute('id', thisTableId);
                    newElementDiv.appendChild(newElementTable);

                    //build the table header
                    var newElementTableHeader = document.createElement('thead');
                    newElementTableHeader.setAttribute('class', 'resultsTableHeader ' + ( presentationObjectElement.resultsTableHeaderClass || '' ) );
                    newElementTable.appendChild(newElementTableHeader);

                    //build the table header row
                    var newElementTableHeaderRow = document.createElement('tr');

                    newElementTableHeaderRow.setAttribute('id', 'resultsTableHeaderRow');
                    newElementTableHeaderRow.setAttribute('class', 'resultsTableHeaderRow ' + ( presentationObjectElement.resultsTableRowClass || '' ) );
                    newElementTableHeader.appendChild(newElementTableHeaderRow);

                    //build the table header column labels
                    //get the child elements
                    var childElements = presentationObjectElement.elements;

                    //for each child element add the label
                    for (var childElementIndex = 0; childElementIndex < childElements.length; childElementIndex++) {

                        var thisChildElement = childElements[childElementIndex];

                        var newColumnHeaderLabel = document.createElement('th');
                        newColumnHeaderLabel.setAttribute('class', 'resultsTableHeaderLabel ' + 
                            ( presentationObjectElement.labelClass || ' ' ) + //resultsTableHeaderLabelClass
                            ( thisChildElement.labelClass || '' ) ); //resultsTableHeaderLabelClass
                        newColumnHeaderLabel.setAttribute('name', thisChildElement.name);
                        newColumnHeaderLabel.setAttribute('id', thisChildElement.name);
                        //newColumnHeaderLabel.setAttribute('resultsDataIndex', 'all');

                        // If the table column is sorted, show the sort direction. 
                        if (thisChildElement['labelAction'] === 'sortTable') {
                            newColumnHeaderLabel.setAttribute('tableName', presentationObjectElement.name); // thisTableId ); //
                            if (thisChildElement['sortDirection'] === 'asc') {
                                newColumnHeaderLabel.classList.add('arrowUp');
                            } else if (thisChildElement['sortDirection'] === 'desc') {
                                newColumnHeaderLabel.classList.add('arrowDown');
                            }
                        }

                        
                        newColumnHeaderLabel.innerHTML = getLanguageText(thisChildElement['label']);

                        // If the column is an action, add the action to the column label. //MT
                        if (thisChildElement['labelAction']) {
                            newColumnHeaderLabel.setAttribute('actionElementAction', thisChildElement['labelAction']);
                            newColumnHeaderLabel.setAttribute('actionElementWorkflowStepName', thisWorkflowStepName);
                            newColumnHeaderLabel.setAttribute('actionElementSearchRequestName',thisSearchRequest.name);
                        }

                        newElementTableHeaderRow.appendChild(newColumnHeaderLabel);
                    }

                    // build the table body
                    var newElementTableBody = document.createElement('tbody');
                    newElementTableBody.setAttribute('id', 'searchResultsTableBody');
                    newElementTableBody.setAttribute('class', 'resultsTableBody');
                    newElementTable.appendChild(newElementTableBody);

                    //build the table body content
                    //AB 20190523: moved this line//var thisSearchRequest = Store.workflowSteps[Store.current.workflowStep].searchRequest;

                    //console.log(Store.workflowSteps[Store.current.workflowStep]);

                    //edited by MT 
                    //for (var rowIndex = 0; rowIndex < thisSearchRequest['searchResultFlat'].length; rowIndex++) { // edited by MT
                    //for (var rowIndex = 0; rowIndex < thisSearchRequest['searchResultFilter'].length; rowIndex++) {
                    for (var rowIndex = 0; rowIndex < thisData.length; rowIndex++) {

                        //if ( (thisData[rowIndex]['filterMatch'] || typeof thisData[rowIndex]['filterMatch'] == 'undefined') && (!thisData[rowIndex]['resultPosted']) ) { //!thisData[rowIndex]['filterNoMatch']) {
                        if ( thisData[rowIndex]['searchResultVisible'] || typeof thisData[rowIndex]['searchResultVisible'] == 'undefined' ) {

                            var thisResultRow = thisData[rowIndex]; // SRP 20190527
                            //build a new row
                            var newElementBodyRow = document.createElement('tr');
                            newElementBodyRow.setAttribute('class', 'resultsTableBodyRow');
                            newElementTableBody.appendChild(newElementBodyRow);

                            //build the table data based on the columns defined in the workflow elements. 
                            for (var childElementIndex = 0; childElementIndex < childElements.length; childElementIndex++) {

                                var workingChildElement = childElements[childElementIndex];

                                var newTableData = document.createElement('td');
                                newTableData.setAttribute('class', 'resultsTableData ' + (childElements[childElementIndex]['class'] || '') );

                                // AB 20190705: Support for editable fields on tables (v1.0)
                                if ( workingChildElement.typeAs && workingChildElement.typeAs == 'editable' ) {
                                    newTableData.setAttribute('id', rowIndex);
                                    newTableData.setAttribute('contenteditable', 'true');
                                    newTableData.setAttribute('style', 'border: 2px solid black;');
                                    //if(!thisSearchRequest['searchResultFilter'][rowIndex][childElements[childElementIndex]['name']+'_original']){
                                    if ( !thisSearchRequest['searchResultFlat'][rowIndex][childElements[childElementIndex]['name'] + '_original'] ) {
                                        // Added a copy of the field _original
                                        //thisSearchRequest['searchResultFilter'][rowIndex][childElements[childElementIndex]['name']+'_original'] = thisSearchRequest['searchResultFilter'][rowIndex][childElements[childElementIndex]['name']];
                                        thisSearchRequest['searchResultFlat'][rowIndex][childElements[childElementIndex]['name'] + '_original'] = thisSearchRequest['searchResultFlat'][rowIndex][childElements[childElementIndex]['name']];
                                    }
                                    if ( workingChildElement.actionFocusIn ) {
                                        newTableData.setAttribute('onfocusin', workingChildElement.actionFocusIn + "(this, event)");
                                    }
                                    if ( workingChildElement.actionFocusOut ) {
                                        newTableData.setAttribute('onfocusout', workingChildElement.actionFocusOut + "(this, event)");
                                    }
                                    if ( workingChildElement.actionOnChange ) {
                                        newTableData.setAttribute('onchange', workingChildElement.actionOnChange + "(this, event)");
                                    }
                                }
                                newTableData.innerHTML = thisSearchRequest['searchResultFlat'][rowIndex][childElements[childElementIndex]['name']] || "";
                                
                                if (workingChildElement.action || workingChildElement.actions) {
                                    newTableData.setAttribute('class', 'tdLink actionElement');
                                    newTableData.setAttribute('actionElementAction', workingChildElement.action);
                                    newTableData.setAttribute('actionElementWorkflowStepName', thisWorkflowStepName);
                                    newTableData.setAttribute('actionElementSearchRequestName',thisSearchRequest.name);
                                    if (searchRequestToUse) {newTableData.setAttribute('searchRequestToUse',searchRequestToUse);}
                                    newTableData.setAttribute('resultsDataIndex', rowIndex);
                                }

                                if (workingChildElement.actions) {
                                    if (!workingObject.actionsArrays) {
                                        workingObject.actionsArrays = {};
                                    }
                                    workingObject.actionsArrays[workingChildElement.name] = workingChildElement.actions;
                                    newTableData.setAttribute('actionsArray', workingChildElement.name);
                                }

                                if ([childElements[childElementIndex]['type']] == 'rowSelector') { //SRP 20190527]
                                    //if (Store.debug) { console.log(indent() + 'makePresentation: thisResultRow', thisResultRow) };

                                    newTableData.id = 'rowSelector_' + rowIndex;
                                    newTableData.name = [childElements[childElementIndex]['name']];
                                    if (typeof thisResultRow.rowSelected === 'undefined' || thisResultRow.rowSelected === false ) {
                                        newTableData.innerHTML = '☐'; //☑☒ 
                                        newTableData.class = 'rowUnselected';
                                        thisResultRow.rowSelected = false;
                                    } else if (thisResultRow.rowSelected == true ) {
                                        newTableData.innerHTML = '☑'; //☐☒ 
                                        newTableData.class = 'rowSelected';
                                        thisResultRow.rowSelected = true; 
                                    }
                                } else if ([childElements[childElementIndex]['type']] == 'rowFixedText'){ // AB 20191024 Added this to support cells in rows with 'fixed text'
                                    newTableData.innerHTML = [childElements[childElementIndex]['label']];  // SRP 20190527
                                } else if ([childElements[childElementIndex]['type']] == 'image') { 
                                    newTableData.innerHTML = '';

                                    if (thisResultRow[childElements[childElementIndex]['name']]) {
                                        var newTableImage = document.createElement('img');
                                        newTableImage.setAttribute('class', 'resultsTableImage ' + (childElements[childElementIndex]['class'] || '') ); // + thisResultRow[childElements[childElementIndex]['class']] );
                                        newTableImage.src = thisResultRow[childElements[childElementIndex]['name']];
                                        newTableData.appendChild(newTableImage);
                                    } else {
                                        newTableData.innerHTML = '&nbsp;';
                                    }
                                } else if ([childElements[childElementIndex]['type']] == 'input'){ 

                                    // SRP 20210424 pushing the input onto the inputs array 
                                    
                                    //var thisTableInputObject = updateObjectProperties( {}, childElements[childElementIndex] );
                                    var thisTableInputObject = {
                                       // add the function here that updates the new input object from the element object
                                       label                   : childElements[childElementIndex]['label'],
                                       name                    : childElements[childElementIndex]['name'] + '_' + rowIndex,
                                       class                   : 'resultsTableInput ' + (childElements[childElementIndex]['class'] || ''),
                                       inputGroupClass         : [childElements[childElementIndex]['inputGroupTopLabel']] || '',
                                       labelClass              : childElements[childElementIndex]['labelClass'] || '',
                                       type                    : "input",
                                       valueDefaultProperty    : childElements[childElementIndex]['valueDefaultProperty'] || '',
                                       visibility              : childElements[childElementIndex]['visibility'] ||'',
                                       //validations             : childElements[childElementIndex]['validations'] ||''
                                    }
                                    workingObject.inputs.push(thisTableInputObject);

                                    if (Store.debug) { console.log(indent() + 'makePresentation: Table Input.') };
                                    newTableData.innerHTML = childElements[childElementIndex].valueDefault || '';
                                    var newTableInput = document.createElement('input');
                                    newTableInput.setAttribute('id',  childElements[childElementIndex]['name'] + '_' + rowIndex );
                                    newTableInput.setAttribute('property',  childElements[childElementIndex]['name'] );
                                    newTableInput.setAttribute('resultId', rowIndex );
                                    newTableInput.setAttribute('searchRequestName', rowIndex );
                                    newTableInput.setAttribute('class', 'resultsTableInput ' + (childElements[childElementIndex]['class'] || '') ); // thisResultRow[childElements[childElementIndex]['class']] );
                                    newTableInput.value = thisResultRow[childElements[childElementIndex]['name']] || childElements[childElementIndex].valueDefault;
                                    newTableData.appendChild(newTableInput);
                                } else {
                                    //newTableData.innerHTML = thisSearchRequest['searchResultFlat'][rowIndex][childElements[childElementIndex]['name']]; // edited by MT
                                    newTableData.innerHTML = thisResultRow[childElements[childElementIndex]['name']];  // SRP 20190527
                                    // TODO SRP 20210101 added displayTransformation to the inner html if specified
                                    if ( childElements[childElementIndex].displayTransformation ) {
                                        //if (Store.debug) { console.log(indent() + 'makePresentation: table, displayTransformation: ', 
                                        //    childElements[childElementIndex]['name'], thisResultRow[childElements[childElementIndex]['name']], childElements[childElementIndex]['displayTransformation']) };
                                        newTableData.innerHTML = displayTransformation(thisResultRow[childElements[childElementIndex]['name']] || '',childElements[childElementIndex]['displayTransformation']);
                                    }
                                }

                                // 20210101 SRP - add tool tips
                                //TODO get tool tip data data from table data
                                if (childElements[childElementIndex].tooltip) {
                                    if (Store.debug) { console.log(indent() + 'makePresentation: tooltip:',childElements[childElementIndex].tooltip) };
                                    if ( typeof childElements[childElementIndex].tooltip == 'string' ) {
                                        newTableData.setAttribute('data-tooltip',childElements[childElementIndex].tooltip);
                                        newTableData.classList.add('tooltipPopup');
                                    } else if ( typeof childElements[childElementIndex].tooltip == 'object' && childElements[childElementIndex].tooltip.lateBind ) {
                                        newTableData.setAttribute('data-tooltip',lateBind(childElements[childElementIndex].tooltip.lateBind));
                                        newTableData.classList.add('tooltipPopup');
                                    }
                                }

                                newElementBodyRow.appendChild(newTableData);
                            }
                            Store.current['searchResultFlat'] = false; 

                        }
                    }
                }
                var tableCreated = true; // SRP 20200603: to stop the makePresentation iteration on inputs and other object types in tables. 
            }
            // If this element has child elements, call this function to process its elements.
            if (presentationObjectElement.elements && !tableCreated) {
                makePresentation(workingObject, presentationObjectElement, presentationObjectElement.name);
            }
        }
    }

    if (Store.debug) { console.log(indent() + 'makePresentation: returning.') };
    callStackDepth--;
}

// 20200716 SRP commented out function.
/* function makeInputs() {
    // this function makes the inputs in the UI and Store

    if (presentationObjectElement.visibility == 'readonly') {
        var newElementInput = document.createElement('div');
    } else {
        var newElementInput = document.createElement('input');
    }
    if (presentationObjectElement.typeAs) {
        newElementInput.setAttribute('type', presentationObjectElement.typeAs);
    } else if (presentationObjectElement.type != 'input') {
        newElementInput.setAttribute('type', presentationObjectElement.type);
    } else {
        newElementInput.setAttribute('type', 'text')
    }

    newElementInput.setAttribute('id', presentationObjectElement.id || presentationObjectElement.name);

    if (presentationObjectElement.visibility == 'readonly') {
        newElementInput.setAttribute('class', 'inputReadOnly ' + (presentationObjectElement.class || ''));
    } else {
        newElementInput.setAttribute('class', 'inputField ' + (presentationObjectElement.class || ''));
    }

    if (presentationObjectElement.visibility) {
        if (presentationObjectElement.visibility == 'readonly') {
            newElementInput.setAttribute('readonly', 'readonly');
        } else if (presentationObjectElement.visibility == 'disabled') {
            newElementInput.setAttribute('disabled', 'disabled');
        }
    }

    if (presentationObjectElement.datalistSource) {
        newElementInput.setAttribute('list', presentationObjectElement.datalistSource);
    } else if (presentationObjectElement.datalistValues) {
        newElementInput.setAttribute('list', presentationObjectElement.name + 'Datalist');
        var newDatalist = document.createElement('datalist');
        newDatalist.setAttribute('id', presentationObjectElement.name + 'Datalist');
        for (var datalistValueIndex = 0; datalistValueIndex < presentationObjectElement.datalistValues.length; datalistValueIndex++) {
            var newDatalistValue = document.createElement('option');
            newDatalistValue.innerHTML = presentationObjectElement.datalistValues[datalistValueIndex];
            newDatalist.appendChild(newDatalistValue);
        }
        newElementInput.appendChild(newDatalist);
    }

    if (presentationObjectElement.valueDefault) {
        if (clickedSearchResult) {
            if (Store.debug) { console.log(indent() + 'makePresentation: valueDefault clickedSearchResult', JSON.parse(JSON.stringify(clickedSearchResult || {}))) };
        }

        if (presentationObjectElement.visibility == 'readonly') {
            newElementInput.setAttribute('value', presentationObjectElement.valueDefault);
            newElementInput.innerHTML = presentationObjectElement.valueDefault || '&nbsp;';
        } else {
            newElementInput.setAttribute('value', presentationObjectElement.valueDefault);
        }
    }

    if (presentationObjectElement.valueDefaultProperty && clickedSearchResult) {
        //if (Store.debug) { console.log(indent() + 'makePresentation: I am: presentationObjectElement.valueDefaultProperty && clickedSearchResult') };
        if (presentationObjectElement.visibility == 'readonly') {
            newElementInput.setAttribute('value', clickedSearchResult[presentationObjectElement.valueDefaultProperty]);
            newElementInput.innerHTML = clickedSearchResult[presentationObjectElement.valueDefaultProperty] || '&nbsp;';
        } else {
            newElementInput.value = clickedSearchResult[presentationObjectElement.valueDefaultProperty];
        }
    }

    //if (Store.debug) { console.log(indent() + 'makePresentation: I have a valueDefault: ',presentationObjectElement.valueDefaultObject ) };

    if (presentationObjectElement.valueDefaultProperty && presentationObjectElement.valueDefaultObject) {
        // if the valueDefaultObject is a string, it should be late bound. 
        var valueDefaultObjectReference = getReferenceFromPath(presentationObjectElement.valueDefaultObject);

        if (Store.debug) { console.log(indent() + 'makePresentation: I am: presentationObjectElement.valueDefaultProperty && presentationObjectElement.valueDefaultObject') };
        if (presentationObjectElement.visibility == 'readonly') {
            newElementInput.setAttribute('value', valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty]);
            if (valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty]) {
                newElementInput.innerHTML = valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty] || '&nbsp;';
            } else if (valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty] == 0) {
                newElementInput.innerHTML = '0';
            } else {
                newElementInput.innerHTML = '&nbsp;';
            }

        } else {
            newElementInput.value = valueDefaultObjectReference[presentationObjectElement.valueDefaultProperty];
        }
    }

    if (presentationObjectElement.recallLastValue) {
        if (presentationObjectElement.visibility == 'readonly') {
            newElementInput.setAttribute('value', presentationObjectElement.inputValue || '');
            newElementInput.innerHTML = presentationObjectElement.inputValue || '&nbsp;';
        } else {
            newElementInput.value = presentationObjectElement.inputValue || '';
        }
    }

    if (presentationObjectElement.min) {
        newElementInput.setAttribute('min', presentationObjectElement.min);
    }

    if (presentationObjectElement.max) {
        newElementInput.setAttribute('max', presentationObjectElement.max);
    }

    if (presentationObjectElement.required) {
        newElementInput.setAttribute('required', '');
    }

    newElementDiv.appendChild(newElementInput);

    //build the current inputs in the Store 
    // change to call setWorkingInputs?

    if (!workingObject.inputs) {
        workingObject.inputs = [];
    }

    // SRP 20190505: changing the following to make the new inputs object have the value and not a reference to the elements
    //workingObject.inputs.push(presentationObjectElement);
    workingObject.inputs.push(JSON.parse(JSON.stringify(presentationObjectElement)));
} */

function displayTransformation_Old(sourceValue, transformationArray) {
    // this function transforms a value into another value.
    //TODO convert from array to object 
    if (Store.debug) { console.log(indent() + 'displayTransformation: called.', sourceValue, transformationArray ) };
    if (transformationArray && typeof transformationArray === 'object') {
        if (transformationArray[0] === 'replace') {
            var transformedValue = sourceValue.replace(transformationArray[1], transformationArray[2]);
            return transformedValue;
            //console.log(transformedValue);
        } else if (transformationArray[0] === 'arrayToString') {
            var transformedValue = '';
            if (typeof sourceValue === 'object') {
                for (var sourceValueIndex = 0; sourceValueIndex < sourceValue.length; sourceValueIndex++) {
                    if (sourceValueIndex > 0) {
                        transformedValue = transformedValue + transformationArray[1];
                    }
                    transformedValue = transformedValue + sourceValue[sourceValueIndex]
                }
            }
            //console.log(transformedValue);
            return transformedValue;
        } else if (transformationArray[0] === 'JSONArrayToString') {
            var transformedValue = '';
            if (typeof sourceValue === 'string') {
                try {
                    var sourceArray = JSON.parse(sourceValue);
                    if (Array.isArray(sourceArray)) {
                        transformedValue = sourceArray.join(', ');
                    } else {
                        transformedValue = sourceValue;
                    }
                } catch (error) {
                    transformedValue = sourceValue;
                }
            }
            //console.log(transformedValue);
            return transformedValue;
        } else if (transformationArray[0] === 'JSONArrayToList') {
            var transformedValue = '';
            var startingString = '';
            var separatorString = ' ';
            var endingString = '';
            if (typeof sourceValue === 'string') {
                try {
                    switch (transformationArray[1]) {
                        case 'ordered':
                            startingString = '<ol> <li>';
                            separatorString = '</li> <li>';
                            endingString = '</li> </ol>';
                            break;
                        case 'unordered':
                            startingString = '<ul> <li>';
                            separatorString = '</li> <li>';
                            endingString = '</li> </ul>';
                            break;
                        default:
                            startingString = '';
                            separatorString = '<br> ';
                            endingString = '';
                    }
                    var sourceArray = JSON.parse(sourceValue);
                    if (Array.isArray(sourceArray)) {
                        transformedValue = startingString;
                        transformedValue = transformedValue + sourceArray.join(separatorString);
                        transformedValue = transformedValue + endingString;
                    } else {
                        transformedValue = sourceValue;
                    }
                } catch (error) {
                    transformedValue = sourceValue;
                }
            }
            //console.log(transformedValue);
            return transformedValue;
        } else {
            // if the transformationArray is empty or missing, return the original value.
            return sourceValue;
        }
    } else {
        // if the transformationArray is empty or missing, return the original value.
        return sourceValue;
    }
}

function displayTransformation(sourceValue, transformationObject) {
    // this function transforms a value into another value.
    //TODO convert from array to object 

    /* e.g. - this property/object is set on an element in a form or table.
        displayTransformation: { 
            transformationType: 'arrayToList', // Options: replace, arrayToString, JSONArrayToString, arrayToList, 
            startingDataType: 'arrayJSON', // Options: array (default), arrayJSON
            listType: 'textList', // Options: 'orderedList', 'unorderedList', 'textList', 'csv', default
            startingString: '', // Optional, Allows override of / custom treatment.
            separatorString: '', // Optional, Allows override of / custom treatment.
            endingString: '' // Optional, Allows override of / custom treatment.
        } */
    
    //if (Store.debug) { console.log(indent() + 'displayTransformation: called.', sourceValue, transformationObject ) };
    if (transformationObject && typeof transformationObject === 'object') {
        if (transformationObject.transformationType === 'replace') {
            var transformedValue = sourceValue.replace(transformationObject.find, transformationObject.replaceWith);
            return transformedValue;
            //console.log(transformedValue);
        } else if (transformationObject.transformationType === 'arrayToString') {
            var transformedValue = '';
            if (typeof sourceValue === 'object') {
                for (var sourceValueIndex = 0; sourceValueIndex < sourceValue.length; sourceValueIndex++) {
                    if (sourceValueIndex > 0) {
                        transformedValue = transformedValue + transformationArray[1];
                    }
                    transformedValue = transformedValue + sourceValue[sourceValueIndex]
                }
            }
            //console.log(transformedValue);
            return transformedValue;
        } else if (transformationObject.transformationType === 'JSONArrayToString') {
            var transformedValue = '';
            if (typeof sourceValue === 'string') {
                try {
                    var sourceArray = JSON.parse(sourceValue);
                    if (Array.isArray(sourceArray)) {
                        transformedValue = sourceArray.join(', ');
                    } else {
                        transformedValue = sourceValue;
                    }
                } catch (error) {
                    transformedValue = sourceValue;
                }
            }
            //console.log(transformedValue);
            return transformedValue;
        } else if (transformationObject.transformationType === 'arrayToList') {
            var transformedValue = '';
            var startingString = '';
            var separatorString = ' ';
            var endingString = '';
            var startingDataType = transformationObject.startingDataType || 'array';
            var sourceArray = [];
            var errorMessage = '';
            if (startingDataType == 'array') {
                if (Array.isArray( sourceValue ) ) {
                    sourceArray = sourceValue;
                } else {
                    errorMessage = 'displayTransformation: convertArray: source value is not an array.'
                }
            } else if ( startingDataType == 'arrayJSON') { 
                if ( typeof sourceValue == 'string' ) {
                    try {
                        sourceArray = JSON.parse(sourceValue);
                    } catch (error) {
                        errorMessage = 'displayTransformation: convertArray: source value could not be parsed to an array from JSON.'
                    } 
                } else {
                    errorMessage = 'displayTransformation: convertArray: source value is not JSON.'
                }
            } 
            if ( errorMessage == '' ) {
                try {
                    switch (transformationObject.listType) {
                        case 'orderedList':
                            startingString = transformationObject.startingString || '<ol> <li>';
                            separatorString = transformationObject.separatorString || '</li> <li>';
                            endingString = transformationObject.endingString || '</li> </ol>';
                            break;
                        case 'unorderedList':
                            startingString = transformationObject.startingString || '<ul> <li>';
                            separatorString = transformationObject.separatorString || '</li> <li>';
                            endingString = transformationObject.endingString || '</li> </ul>';
                            break;
                        case 'textList':
                            startingString = transformationObject.startingString || '';
                            separatorString = transformationObject.separatorString || '<br> ';
                            endingString = transformationObject.endingString || '';
                            break;
                        case 'csv':
                            startingString = transformationObject.startingString || '';
                            separatorString = transformationObject.separatorString || ', ';
                            endingString = transformationObject.endingString || '';
                            break;
                        default:
                            startingString = transformationObject.startingString || '';
                            separatorString = transformationObject.separatorString || '';
                            endingString = transformationObject.endingString || '';
                    }

                    transformedValue = startingString;
                    transformedValue = transformedValue + sourceArray.join(separatorString);
                    transformedValue = transformedValue + endingString;
                } catch (error) {
                    errorMessage = 'displayTransformation: arrayToList: Sorry, I cold not convert that. '
                    transformedValue = sourceValue;
                }
            }
            return transformedValue;
        } else {
            // if the transformationArray is empty or missing, return the original value.
            return sourceValue;
        }
    } else {
        // if the transformationArray is empty or missing, return the original value.
        return sourceValue;
    }
}

function toggleResultSelection(sourceArrayIndex) {
    // SRP 20190527 - this function toggles a value between selected and unselected in the Store and in the DOM
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'toggleResultSelection: called.') };

    // Get the clicked UI and data objects
    var thisElement = Store.current.clickedElement;
    var thisResult = Store.current.clickedSearchResult;
    var thisSearchRequest = Store.current.clickedSearchRequest;
    if (typeof thisSearchRequest.selectedResults == 'undefined' ) {
        thisSearchRequest.selectedResults = [];
    }

    // Toggle the UI and Data 
    if (typeof thisResult.rowSelected !== 'undefined' && thisResult.rowSelected === true) { 
        //From True to False
        if (Store.debug) { console.log(indent() + 'toggleResultSelection: unselected.') };
        thisResult.rowSelected = false;
        thisElement.innerText = '☐';
        thisElement.class = 'rowUnselected';
        // reset the selected rows ... in the future, we might be able to pop out the one unselected
        thisSearchRequest.selectedResults.length = 0;
        for (var searchResultIndex = 0; searchResultIndex < thisSearchRequest.searchResultFlat.length ; searchResultIndex++ ) {
            var thisSearchResult = thisSearchRequest.searchResultFlat[searchResultIndex];
            if (thisSearchResult.rowSelected) {
                thisSearchRequest.selectedResults.push(thisSearchResult);
            } else {
                //if (Store.debug) { console.log(indent() + 'toggleResultSelection: Not pushing', thisSearchResult) };
            }
        }
    } else {
        //From False to True
        //if (Store.debug) { console.log(indent() + 'toggleResultSelection: selected.') };
        thisResult.rowSelected = true;
        thisElement.innerText = '☑';
        thisElement.class = 'rowSelected';
        thisSearchRequest.selectedResults.push(thisResult);
    }

    if (Store.debug) { console.log(indent() + 'toggleResultSelection: returning.') };
    callStackDepth--;
}

function toggleResultSelectionSimilar(selectWithSimilarProperty, selectedIndex) {
    // SRP 20190527 - this function toggles all rows with a similar property value between selected and unselected 
    // For example, selecting a transaction detail in a list of multiple transactions could select or deselect all the results for the transaction
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'toggleResultSelectionSimilar: called.') };

    if (!selectedIndex) {
        var selectedIndex = [Store.current.clickedDataIndex];
    }

    var sourceArray = Store.currentWorkflowStep['searchRequest']['searchResultFlat'];
    var selectedRow = sourceArray[selectedIndex];

    if (selectWithSimilarProperty) {
        var selectWithSimilarValue = selectedRow[selectWithSimilarProperty];
    }

    var thisResult = {};

    for (var sourceIndex = 0; sourceIndex < sourceArray.length; sourceIndex++) {
        thisResult = sourceArray[sourceIndex];

        if (thisResult[selectWithSimilarProperty] == selectWithSimilarValue) {
            toggleResultSelection(sourceIndex);
        }
    }

    if (Store.debug) { console.log(indent() + 'toggleResultSelectionSimilar: returning.') };
    callStackDepth--;
}

function toggleResultSelectionAll() {
    // SRP 20190527 - this function toggles all values between selected and unselected in the Store and in the DOM
    // NOTE: for this release, this looks to the first row to determine the toggle.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'toggleResultSelectionAll: called.') };

    var thisSearchRequest = Store.current.clickedSearchRequest;
    var theseResults = thisSearchRequest.searchResultFlat; //Store.currentWorkflowStep.searchRequest.searchResultFlat
    var firstRowSelected = theseResults[0].rowSelected;

    if (typeof thisSearchRequest.selectedResults == 'undefined' ) {
        thisSearchRequest.selectedResults = [];
    }

    if (typeof firstRowSelected !== 'undefined' && firstRowSelected === true) {
            thisSearchRequest.selectedResults.length = 0;
    }

    for (var rowIndex = 0; rowIndex < theseResults.length; rowIndex++) {
        var thisResult = theseResults[rowIndex];

        if (typeof thisResult.searchResultVisible == 'undefined' || thisResult.searchResultVisible == true) {
            var thisElement = document.getElementById('rowSelector_' + rowIndex);
            //if (Store.debug) { console.log(indent() + 'toggleResultSelectionAll: rowIndex, thisResult, thisElement: ', rowIndex, thisResult, thisElement) };

            if (typeof firstRowSelected !== 'undefined' && firstRowSelected === true) {
                thisResult.rowSelected = false;
                thisElement.innerText = '☐';
                thisElement.class = 'rowUnselected';
            } else {
                thisResult.rowSelected = true;
                thisElement.innerText = '☑';
                thisElement.class = 'rowSelected';
                thisSearchRequest.selectedResults.push(thisResult);
            }
        }
    }

    if (Store.debug) { console.log(indent() + 'toggleResultSelectionAll: returning.') };
    callStackDepth--;
}

function selectAllResults() {
    // SRP 20190527 - this function toggles all values between selected and unselected in the Store Only
    // NOTE: for this release, this looks to the first row to determine the toggle.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'selectAllResults: called.') };

    var thisSearchRequest = Store.current.clickedSearchRequest;
    var theseResults = thisSearchRequest.searchResultFlat; //Store.currentWorkflowStep.searchRequest.searchResultFlat
    //var firstRowSelected = theseResults[0].rowSelected;

    if (typeof thisSearchRequest.selectedResults == 'undefined' ) {
        thisSearchRequest.selectedResults = [];
    } else {
        thisSearchRequest.selectedResults.length = 0;
    }

    for (var rowIndex = 0; rowIndex < theseResults.length; rowIndex++) {
        var thisResult = theseResults[rowIndex];

        if (typeof thisResult.searchResultVisible == 'undefined' || thisResult.searchResultVisible == true) {
            thisResult.rowSelected = true;
            thisSearchRequest.selectedResults.push(thisResult);
        }
    }

    if (Store.debug) { console.log(indent() + 'selectAllResults: returning.') };
    callStackDepth--;
}

function mainMenu() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'mainMenu: called.') };

    updateUI('mainMenu');

    if (Store.debug) { console.log(indent() + 'mainMenu: returning.') };
    callStackDepth--;
}

function updateUI(newWorkflowStep) {
    callStackDepth++;
    // this is the function that causes the UI to change.
    if (Store.debug) { console.log(indent() + 'updateUI: called with: ', newWorkflowStep) };

    if (!newWorkflowStep) { 
        if (typeof Store.current.workflowStep == 'object') { // SRP 20191124 - Somehow Store.current.workflowStep is getting the object and not the name
            newWorkflowStep = Store.current.workflowStep.name;
        } else {
            newWorkflowStep = Store.current.workflowStep;
        }
    }

    if (typeof newWorkflowStep == 'object') {
        newWorkflowStep = newWorkflowStep.name;
    }

    if (newWorkflowStep) {
        Store.current.previousWorkflowStep = Store.current.workflowStep;
        Store.current.workflowStep = newWorkflowStep;
        Store.currentWorkflowStep = Store.workflowSteps[Store.current.workflowStep];
        initializationActions(); // TODO: add ability to handle asynchronous process before processing the rest of the steps.
        noVisibleResultActions();
        setTitle();
        clearErrorTip();
        setErrorTip();
        setSuccessTip();
        setTip();
        clearBody();
        setBody();
        clearActions();
        setActions();
        setMoreData();
        onReadyActions();
        //renderUI();

        if (Store.debug) { console.log(indent() + 'updateUI: returning.') };
        callStackDepth--;
        return
    }

    if (Store.debug) { console.log(indent() + 'updateUI: returning without a workflow step.') };
    callStackDepth--;
}

function initializationActions() {
    // this function calls the processActionsArray with the workflow step's initializationActions if they exist.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'initializationActions: called.') };

    // SRP if (Store.workflowSteps[Store.current.workflowStep]) {
    if (Store.currentWorkflowStep) {

        // SRP var workingObject = Store.workflowSteps[Store.current.workflowStep];
        var workingObject = Store.currentWorkflowStep;
        if (Store.debug) { console.log(indent() + 'initializationActions: working on: ', workingObject.name) };

        if (workingObject.initializationActions && workingObject.initializationActions.length > 0) {
            //if (Store.debug) { console.log(indent() + 'initializationActions: there are initializationActions: ', workingObject.name) };
            processActionArray(workingObject, workingObject.initializationActions);
        } else {
            //if (Store.debug) { console.log(indent() + 'initializationActions: there are no initializationActions. ', workingObject.name) };
        }
    } else {
        if (Store.debug) { console.log(indent() + 'initializationActions: the workingObject is not a workflowStep. ') };
    }

    if (Store.debug) { console.log(indent() + 'initializationActions: returning.') };
    callStackDepth--;
}

function onReadyActions() {
    // this function calls the processActionsArray with the workflow step's onReadyActions if they exist.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'onReadyActions: called.') };

    // SRP if (Store.workflowSteps[Store.current.workflowStep]) {
    if (Store.currentWorkflowStep) {

        // SRP var workingObject = Store.workflowSteps[Store.current.workflowStep];
        var workingObject = Store.currentWorkflowStep;
        if (Store.debug) { console.log(indent() + 'onReadyActions: working on: ', workingObject.name) };

        if (workingObject.onReadyActions && workingObject.onReadyActions.length > 0) {
            if (Store.debug) { console.log(indent() + 'onReadyActions: there are onReadyActions: ', workingObject.name, workingObject.onReadyActions) };
            processActionArray(workingObject, workingObject.onReadyActions);
        } else {
            if (Store.debug) { console.log(indent() + 'onReadyActions: there are no onReadyActions. ', workingObject.name) };
        }
    } else {
        if (Store.debug) { console.log(indent() + 'onReadyActions: the workingObject is not a workflowStep. ') };
    }


    if (Store.debug) { console.log(indent() + 'onReadyActions: returning.') };
    callStackDepth--;
}

function setTitle() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setTitle: called.') };

    var currentTitle = document.getElementById('workflowTitleArea');
    // SRP currentTitle.innerHTML = getLanguageText(Store.workflowSteps[Store.current.workflowStep]['title']);
    currentTitle.innerHTML = getLanguageText(Store.currentWorkflowStep['title']);

    if (Store.debug) { console.log(indent() + 'setTitle: returning.') };
    callStackDepth--;
}

function clearTitle() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearTitle: called.') };

    var currentTitle = document.getElementById('workflowTitleArea');
    currentTitle.innerHTML = '';

    if (Store.debug) { console.log(indent() + 'clearTitle: returning.') };
    callStackDepth--;
}

function setErrorTip() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setErrorTip: called.') };
    var currentErrorTip = document.getElementById("workflowErrorTipArea");

    currentErrorTip.innerHTML = getLanguageText(Store.current.errorMessage);
    if (Store.current.errorMessage) {
        currentErrorTip.setAttribute('style', 'display:block;');
    } else {
        currentErrorTip.setAttribute('style', 'display:none;');
    }
    Store.current.errorMessage = '';

    if (Store.debug) { console.log(indent() + 'setErrorTip: returning.') };
    callStackDepth--;
}

function clearErrorTip() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearErrorTip: called.') };

    var currentErrorTip = document.getElementById("workflowErrorTipArea");
    currentErrorTip.innerHTML = '';
    currentErrorTip.setAttribute('style', 'display:none;');

    if (Store.debug) { console.log(indent() + 'clearErrorTip: returning.') };
    callStackDepth--;
}

function setSuccessTip() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setSuccessTip: called.') };

    var currentSuccessTip = document.getElementById("workflowSuccessTipArea");

    currentSuccessTip.innerHTML = getLanguageText(Store.current.successMessage);
    if (Store.current.successMessage) {
        currentSuccessTip.setAttribute('style', 'display:block;');
    } else {
        currentSuccessTip.setAttribute('style', 'display:none;');
    }
    Store.current.successMessage = '';

    if (Store.debug) { console.log(indent() + 'setSuccessTip: returning.') };
    callStackDepth--;
}

function clearSuccessTip() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearSuccessTip: called.') };

    var currentSuccessTip = document.getElementById("workflowSuccessTipArea");

    currentSuccessTip.innerHTML = '';
    currentSuccessTip.setAttribute('style', 'display:none;');

    if (Store.debug) { console.log(indent() + 'clearSuccessTip: returning.') };
    callStackDepth--;
}

function setTip() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setTip: called.') };

    // SRP if (Store.workflowSteps[Store.current.workflowStep]['tip']) {
    if (Store.currentWorkflowStep['tip']) {
        var currentTip = document.getElementById("workflowStandardTipArea");
        // SRP currentTip.innerHTML = getLanguageText(Store.workflowSteps[Store.current.workflowStep]['tip']);
        currentTip.innerHTML = getLanguageText(Store.currentWorkflowStep['tip']);
    } else {
        clearTip();
    }

    if (Store.debug) { console.log(indent() + 'setTip: returning.') };
    callStackDepth--;
}

function clearTip() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearTip: called.') };

    var currentTip = document.getElementById("workflowStandardTipArea");

    currentTip.innerHTML = '';

    if (Store.debug) { console.log(indent() + 'clearTip: returning.') };
    callStackDepth--;
}

function clearBody() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearBody: called.') };

    var workflowBodyArea = document.getElementById('workflowBodyArea');
    //if (Store.debug) { console.log(indent() + 'clearBody: workflowBodyArea.children.length: ', JSON.parse(JSON.stringify(workflowBodyArea.children.length))) };
    //if (Store.debug) { console.log(indent() + 'clearBody: workflowBodyArea.children: ', JSON.parse(JSON.stringify(workflowBodyArea.children))) };
    //if (Store.debug) { console.log(indent() + 'clearBody: workflowBodyArea: ', JSON.parse(JSON.stringify(workflowBodyArea))) };
    for (var workflowBodyElementIndex = workflowBodyArea.children.length - 1; workflowBodyElementIndex >= 0; workflowBodyElementIndex--) {
        var hideThisElement = workflowBodyArea.children[workflowBodyElementIndex];
        workflowBodyArea.removeChild(hideThisElement);
    }

    if (Store.debug) { console.log(indent() + 'clearBody: returning.') };
    callStackDepth--;
}

function setActions() {
    // look at the current workflow step and set/clear the action items and their actions. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setActions: called.') };

    // SRP var workingObject = Store.workflowSteps[Store.current.workflowStep];
    var workingObject = Store.currentWorkflowStep;

    // add an actionsArrays if it does not exist
    if (!workingObject.actionsArrays) {
        workingObject.actionsArrays = {};
    }

    // find all the action items for the current workflow step
    for (var workflowStepIndex = 0; workflowStepIndex < workingObject['userActions'].length; workflowStepIndex++) {
        var actionItemObject = workingObject['userActions'][workflowStepIndex];
        //if (Store.debug) { console.log(indent() + 'setActions: adding the following action item: ', actionItemObject) };

        // add the actions to the current workflow step's actionsArray actions exist
        if (actionItemObject.actions) {
            workingObject.actionsArrays[actionItemObject.name] = actionItemObject.actions;
        }

        // TODO: Add conditional inclusion of action items here
        // this only includes action items with no condition or true condition
        //if (Store.debug) { console.log(indent() + 'setActions: actionItemObject:', actionItemObject) };
        //if (Store.debug) { console.log(indent() + 'setActions: actionItemObject.condition:', typeof actionItemObject.condition) };
        var includeActionItem = true;
        if (typeof actionItemObject.condition != 'undefined' ) {
            if (typeof actionItemObject.condition == 'boolean' ) {
                includeActionItem = actionItemObject.condition;
            } else if (typeof actionItemObject.condition == 'string') {
                if (typeof window[actionItemObject.condition.split('(')[0]] === 'function') {
                    includeActionItem = window[actionItemObject.condition.split('(')[0]](actionItemObject.condition.split('(')[1].split(')')[0] );
                }
            } else if (typeof actionItemObject.condition == 'array') {
                // this will be used for an array that evaluates the store in NS search filter notation. 
            } else if (typeof actionItemObject.condition == 'object') {
                if ( actionItemObject.condition.type && actionItemObject.condition.type == 'function' && actionItemObject.condition.name ) {
                    var functionName = actionItemObject.condition.name;
                    if ( actionItemObject.condition.parameters ) {
                        includeActionItem = window[functionName](actionItemObject.condition.parameters);
                    } else {
                        includeActionItem = window[functionName]();
                    }
                }
            }
        }

        //if (Store.debug) { console.log(indent() + 'setActions: includeActionItem:', includeActionItem) };
        // look for a condition property on the action item
        // if the condition evaluates to true, process the action item
        // no else condition

        if (includeActionItem) {
            // Build the action Item and add it to the current Action Items.
            var newActionItem = document.createElement('input');
            newActionItem.setAttribute('type', actionItemObject.type || 'button')
            newActionItem.setAttribute('id', actionItemObject.name);
            newActionItem.setAttribute('class', actionItemObject.class || 'actionElement');
            newActionItem.setAttribute('actionElementAction', actionItemObject.action || 'processActionArray');
            newActionItem.setAttribute('actionElementWorkflowStepName', workingObject.name);
            if (actionItemObject.searchRequestToUse) {newActionItem.setAttribute('searchRequestToUse',searchRequestToUse);} // this allows an action item's action to target the data in a section.
            if (actionItemObject.name == 'nextAction') {
                newActionItem.classList.add('nextAction');
            } else if (actionItemObject.name == 'backAction') {
                newActionItem.classList.add('backAction');
            }
            if (actionItemObject.actions) {
                newActionItem.setAttribute('actionsArray', actionItemObject.name);
            }
            newActionItem.setAttribute('value', getLanguageText(actionItemObject.label));

            //now render the action area
            var currentActions = document.getElementById("workflowActionsArea");
            currentActions.appendChild(newActionItem);
        }
    }

    if (Store.debug) { console.log(indent() + 'setActions: returning.') };
    callStackDepth--;
}

/*function setActionsOld() {
    // look at the current workflow step and set/clear the action items and their actions. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setActions: called.') };

    var workingObject = Store.workflowSteps[Store.current.workflowStep];

    // add an actionsArrays if it does not exist
    if (!workingObject.actionsArrays) {
        workingObject.actionsArrays = {};
    }

    // find all the action items for the current workflow step
    for (var workflowStepIndex = 0; workflowStepIndex < workingObject['actions'].length; workflowStepIndex++) {
        var actionItemObject = workingObject['actions'][workflowStepIndex];
        //if (Store.debug) { console.log(indent() + 'setActions: adding the following action item: ', actionItemObject) };

        // add the actions to the current workflow step's actionsArray actions exist
        if (actionItemObject.actions) {
            workingObject.actionsArrays[actionItemObject.name] = actionItemObject.actions;
        }

        // Build the action Item and add it to the current Action Items.
        var newActionItem = document.createElement('input');
        newActionItem.setAttribute('type', actionItemObject.type || 'button')
        newActionItem.setAttribute('id', actionItemObject.name);
        newActionItem.setAttribute('class', 'actionElement');
        newActionItem.setAttribute('actionElement', actionItemObject.action);
        if (actionItemObject.actions) { newActionItem.setAttribute('actionsArray', actionItemObject.name); }
        newActionItem.setAttribute('value', getLanguageText(actionItemObject.label));

        //now render the action area
        var currentActions = document.getElementById("workflowActionsArea");
        currentActions.appendChild(newActionItem);
    }

    if (Store.debug) { console.log(indent() + 'setActions: returning.') };
    callStackDepth--;
}*/

function clearActions() {
    // this function remove the current actions from the DOM. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearActions: called.') };

    var currentActions = document.getElementById("workflowActionsArea");
    while (currentActions.firstChild) {
        currentActions.removeChild(currentActions.firstChild);
    }

    if (Store.debug) { console.log(indent() + 'clearActions: returning.') };
    callStackDepth--;
}

function setMoreData() {
    // this function adds the more data contents to the DOM.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setMoreData: called.') };

    var currentMoreData = document.getElementById("workflowMoreDataArea");

    if (Store.debug) { console.log(indent() + 'setMoreData: returning.') };
    callStackDepth--;
}

function clearMoreData() {
    // this function removes the more data contents for the DOM
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearMoreData: called.') };

    var currentMoreData = document.getElementById("workflowMoreDataArea");
    while (currentMoreData.firstChild) {
        currentMoreData.removeChild(currentMoreData.firstChild);
    }

    if (Store.debug) { console.log(indent() + 'clearMoreData: returning.') };
    callStackDepth--;
}

function renderUI() {
    // for performance, it is better to prepare the UI out of the visible DOM than set it into the visible DOM... this function will do that.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'renderUI: called.') };


    if (Store.debug) { console.log(indent() + 'renderUI: returning.') };
    callStackDepth--;
}

function showLoader() {
    // this adds a loader div over the UI
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'showLoader: called.') };

    // if the loader is not already loaded
    if (!document.getElementById('loaderDiv')) {
        // build the div
        var loaderDiv = document.createElement('div');
        loaderDiv.setAttribute('id', 'loaderDiv');
        loaderDiv.setAttribute('class', 'loaderDiv');
        // build the spinner
        var loaderImage = document.createElement('div');
        loaderImage.setAttribute('class', 'loader');
        loaderDiv.appendChild(loaderImage);
        // show loader
        //var currentBody = document.getElementById("workflowBodyArea");
        var currentBody = document.getElementById("mainContainer");
        currentBody.appendChild(loaderDiv);
    } else {
        if (Store.debug) { console.log(indent() + 'showLoader: already loaded') };
    }

    if (Store.debug) { console.log(indent() + 'showLoader: returning.') };
    callStackDepth--;
}

function clearLoader() {
    // this adds a loader div over the UI
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'clearLoader: called.') };

    if (document.getElementById('loaderDiv')) {
        var loaderDiv = document.getElementById('loaderDiv');
        //var currentBody = document.getElementById("workflowBodyArea");
        var currentBody = document.getElementById("mainContainer");
        //currentBody.removeChild(loaderDiv);
        loaderDiv.parentNode.removeChild(loaderDiv);
    }

    if (Store.debug) { console.log(indent() + 'clearLoader: returning.') };
    callStackDepth--;
}




// Posted Processes functions...
    // these functions deal with handling records that were sent to NS for processing... 
    // -- sometimes the record should continue to show in the current and new search results
    // -- sometimes the record should not show in the current and new search results... ever again.
    // -- sometimes the record should not show in the current and new search results... until it is done being processed in NS
    // need way to see what was submitted and is still pending confirmation 

function updateSearchResultVisibility(searchRequest) {
    // this function evaluates search results, sets it's visibility, and updates the counts for a given searchRequest
    // Covers Total, Filtered, Processed 
    // for performance, it is better to prepare the UI out of the visible DOM than set it into the visible DOM... this function will do that.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'updateSearchResultVisibility: called.') };

    var thisSearchRequest = searchRequest || Store.currentWorkflowStep.searchRequest;
    if ( typeof thisSearchRequest.searchResultFlat === 'undefined' ) { thisSearchRequest.searchResultFlat = []; }

    var countTotal = thisSearchRequest.searchResultFlat.length || 0; // Set Total Count
    var countVisible = 0; // Set Visible Count
    var countVisibleNot = 0; // Set Filter Visible Count 
    var countFilterMatch = 0; // Set Filter Visible Count 
    var countFilterMatchNot = 0; // Set Filter Hidden Count
    var countProcessed = 0; // Set Processed Visible Count 
    var countProcessedNot = 0; // Set Processed Hidden Count 

    for ( var searchResultsIndex = 0; searchResultsIndex < thisSearchRequest.searchResultFlat.length ; searchResultsIndex++ ) {
        
        var thisSearchResult =  thisSearchRequest.searchResultFlat[searchResultsIndex]; 
        var thisSearchResultIsVisible = true;

        // Set Filter Counts
        if (thisSearchResult['filterMatch'] ) { 
            countFilterMatch++; 
        } else {
            countFilterMatchNot++; 
            if (typeof thisSearchResult['filterMatch'] != 'undefined') {
                thisSearchResultIsVisible = false;
            }
        }
        
        // Set Processed Counts
        if (thisSearchResult['resultPosted'] ) { 
            countProcessed++; 
            thisSearchResultIsVisible = false;
        } else {
            countProcessedNot++; 
        }

        // Set Visible Count
        if (thisSearchResultIsVisible) {
            countVisible++;
            thisSearchResult.searchResultVisible = true;
        } else {
            countVisibleNot++
            thisSearchResult.searchResultVisible = false;
        }
    }

    thisSearchRequest.countTotal = countTotal; // Set Total Count
    thisSearchRequest.countVisible = countVisible; // Set Visible Count
    thisSearchRequest.countVisibleNot = countVisibleNot; // Set Filter Visible Count 
    thisSearchRequest.countFilterMatch = countFilterMatch; // Set Filter Visible Count 
    thisSearchRequest.countFilterMatchNot = countFilterMatchNot; // Set Filter Hidden Count
    thisSearchRequest.countProcessed = countProcessed; // Set Processed Visible Count 
    thisSearchRequest.countProcessedNot = countProcessedNot; // Set Processed Hidden Count 
    
    if (Store.debug) { console.log(indent() + 'updateSearchResultVisibility: returning.') };
    callStackDepth--;
}

function postProcessedRecords() {
    // this function is called following a custom process successfully completing to update all selected records as processed
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'postProcessedRecords: called.') };

    //assuming the process is processing records from selected items on the search request.
    var thisSearchRequest = Store.current.clickedSearchRequest || Store.currentWorkflowStep.searchRequest;
    if (Store.debug) { console.log(indent() + 'postProcessedRecords: thisSearchRequest:', thisSearchRequest.name) };

    if ( thisSearchRequest && thisSearchRequest.selectedResults && thisSearchRequest.selectedResults.length ) {
        for (var selectedResultIndex = 0 ; selectedResultIndex < thisSearchRequest.selectedResults.length ; selectedResultIndex++ ) {
            thisSearchRequest.selectedResults[selectedResultIndex].resultPosted = true;
            thisSearchRequest.selectedResults[selectedResultIndex].rowSelected = false;
        }

        // clear the selected results
        thisSearchRequest.selectedResults.length = 0;
    }

    updateSearchResultVisibility(thisSearchRequest);

    if (Store.debug) { console.log(indent() + 'postProcessedRecords: returning.') };
    callStackDepth--;
}

function postWMSTSQueueAction (workingObject, actionsArray) {
    // This function post the selected data to NetSuite
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: called with workingObject, actionsArray:', workingObject.name, actionsArray) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'postWMSTSQueueAction: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    if (!workingObject.WMSTSQ) {
        console.log(indent() + 'postWMSTSQueueAction: no WMSTSQ object, returning.');
        callStackDepth--;
        return;
    } else {
        var thisQueueRequest = workingObject.WMSTSQ;
    }

    thisQueueRequest.log.push({ 
        dateTimeMS: Date.now(), 
        durationMS: Date.now() - thisQueueRequest.log[thisQueueRequest.log.length - 1].dateTimeMS, 
        action: Store.currentWorkflowStep.name + ': postWMSTSQueueAction: process called.' });

    // validate and prepare log
    if (!workingObject.WMSTSQ.log) {
        workingObject.WMSTSQ.log = [];
        workingObject.WMSTSQ.log.push({ dateTimeMS: Date.now(), action: 'postWMSTSQueueAction: Log built.' })
    } else if ( Object.keys(workingObject.WMSTSQ.payload).length <= 0 ) { 
        console.log(indent() + 'postWMSTSQueueAction: the WMSTSQ payload object is empty, returning.');
        callStackDepth--;
        return;
    } else {
        var thisPayload = workingObject.WMSTSQ.payload;
    }

    // validate and prepare payload
    if (!workingObject.WMSTSQ.payload) {
        console.log(indent() + 'postWMSTSQueueAction: no WMSTSQ payload object, returning.');
        callStackDepth--;
        return;
    } else if ( Object.keys(workingObject.WMSTSQ.payload).length <= 0 ) { 
        console.log(indent() + 'postWMSTSQueueAction: the WMSTSQ payload object is empty, returning.');
        callStackDepth--;
        return;
    } else {
        var thisPayload = workingObject.WMSTSQ.payload;
    }

    // validate and prepare processingOptions
    if (!workingObject.WMSTSQ.processingOptions) {
        console.log(indent() + 'postWMSTSQueueAction: no WMSTSQ processingOptions object, returning.');
        callStackDepth--;
        return;
    } else if ( Object.keys(workingObject.WMSTSQ.processingOptions).length <= 0 ) { 
        console.log(indent() + 'postWMSTSQueueAction: the WMSTSQ processingOptions object is empty, returning.');
        callStackDepth--;
        return;
    } else {
        var thisProcessingOptions = workingObject.WMSTSQ.processingOptions;
    }

    // validate and prepare the searchRequest
    if (typeof workingObject.WMSTSQ.searchRequest != 'undefined' ) {
        if (Object.keys(workingObject.WMSTSQ.searchRequest).length >= 0) {
            var thisSearchRequest = workingObject.WMSTSQ.searchRequest;
        } else if (Object.keys(workingObject.searchRequest).length >= 0) {
            var thisSearchRequest = workingObject.searchRequest;
        } else {
            var thisSearchRequest = workingObject.WMSTSQ.searchRequest;
        } 
    } else {
        console.log(indent() + 'postWMSTSQueueAction: no WMSTSQ searchRequest object, returning.');
        callStackDepth--;
        return;
    }

    // validate and prepare the response object
    workingObject.WMSTSQ.response = {};
    var thisResponse = workingObject.WMSTSQ.response = {};

    // create the data object
    var objToSend = {
        payload: thisPayload,
        processingOptions: thisProcessingOptions
    };

    if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: objToSend:', objToSend ) };

    var xhr = new XMLHttpRequest();
    var RESTletFullURL = Store.defaults.url + '?script=' + 
        Store.defaults.postWMSTSQueue.scriptID + '&deploy=' + 
        Store.defaults.postWMSTSQueue.deploymentID;

    xhr.open("POST", RESTletFullURL, true);

    //Set the proper header information to send along with the request
    xhr.setRequestHeader("Content-Type", "application/json");
    setAuthHeader(xhr);
    //Store.postWMSTSQueueAction = { postResultRaw: null };
    xhr.onreadystatechange = function () {//Call a function when the state changes.
        // Because the request is Asynchronous, this code will not run util the response is returned.
        // - Watch for each Response
        // - Load Raw Response into 
        callStackDepth++;
        if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async called with: workingObject, actionsArray:', workingObject.name ) };
        if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async called with: workingObject, status, status text:', workingObject.name, xhr.status, xhr.statusText ) }; //, xhr.responseText) };

        //thisResponse.timeProcessInitiated = Date.now();
        thisResponse.readyState = this.readyState;
        thisResponse.status = this.status;
        thisResponse.responseFull = xhr.response;
        thisResponse.responseText = xhr.responseText;
        if (xhr.response.length >= 1 && typeof JSON.parse(xhr.response) == 'object') { 
            thisResponse.responseIsObject = true;
            thisResponse.responseObject = JSON.parse(xhr.response); 
        } else {
            thisResponse.responseIsObject = false;
        }
        thisResponse.this = this;
       
        if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: thisResponse:', JSON.parse(JSON.stringify(thisResponse)) ) };

        thisQueueRequest.log.push({ 
            dateTimeMS: Date.now(), 
            durationMS: Date.now() - thisQueueRequest.log[thisQueueRequest.log.length - 1].dateTimeMS, 
            action: Store.currentWorkflowStep.name + ': postWMSTSQueueAction: Async response Received.', 
            response: JSON.parse(JSON.stringify(thisResponse))
        });
    
        if (xhr.status === 404) {
            // if any response is 404
            if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned 404:') }; 
            Store.current.successMessage = '';
            Store.current.errorMessage = 'Sorry, There was an issue talking with the server.  Please check the logs... (404).';
            processActionArray(workingObject, actionsArray);

        } else if (this.readyState == XMLHttpRequest.DONE && this.status === 200) {

            if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned 200 postResultRaw:', workingObject.name) }

            // if no results were returned set the error message
            if (thisResponse.responseObject) {
                if (thisResponse.responseObject.status.success === true) {
                    if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned 200 true: workingObject:', workingObject.name) }
                    
                    Store.current.successMessage = thisQueueRequest.successMessage || thisResponse.responseObject.status.message;
                    Store.current.errorMessage = '';
                    if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned 200 true: SuccessMessage:', Store.current.successMessage); }

                    setSuccessTip();
                    processActionArray(workingObject, actionsArray);
                    if ( Store.current.errorMessage == '' ) {
                        Store.current.successMessage = thisQueueRequest.successMessage || thisResponse.responseObject.status.message;
                        setSuccessTip();
                    }

                } else {
                    if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned 200 false:', workingObject.name) }
                    Store.current.successMessage = '';
                    Store.current.errorMessage = Store.current.errorMessage + 'Sorry, ' + thisResponse.responseObject.status.message + '. (200)</br>';
                    processActionArray(workingObject, actionsArray);
                }
            } else {
                // Now, if any additional actions were passed in, execute the actions 
                if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned 200 workingObject, actionsArray:', workingObject.name) }
                Store.current.successMessage = thisResponse.responseObject.status.message;
                Store.current.errorMessage = '';
                processActionArray(workingObject, actionsArray);
            }
            
            if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned 200: thisRequest | successMessage | errorMessage', 
                JSON.parse(JSON.stringify(thisQueueRequest)), '|', Store.current.successMessage, '|', Store.current.errorMessage ); }

        } else if (this.readyState == XMLHttpRequest.DONE) {
            if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returned other than 200: thisResponse:', JSON.parse(JSON.stringify(thisResponse)) ) };
            Store.current.successMessage = '';
            Store.current.errorMessage = 'Sorry, There was an issue talking with the server.  Please check the logs. (Other: ' + this.status + ')';
            processActionArray(workingObject, actionsArray);
        }

        thisQueueRequest.log.push({ 
            dateTimeMS: Date.now(), 
            durationMS: Date.now() - thisQueueRequest.log[thisQueueRequest.log.length - 1].dateTimeMS, 
            action: Store.currentWorkflowStep.name + ': postWMSTSQueueAction: response done.', 
            response: JSON.parse(JSON.stringify(thisResponse))
        });

        if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: Async returning from: workingObject: ', workingObject.name) };
        callStackDepth--;
    }

    // Start the request timer 
    // send the request
    if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: objToSend.', JSON.parse(JSON.stringify(objToSend))) };
    xhr.send(JSON.stringify(objToSend));

    thisQueueRequest.log.push({ 
        dateTimeMS: Date.now(), 
        durationMS: Date.now() - thisQueueRequest.log[thisQueueRequest.log.length - 1].dateTimeMS, 
        action: Store.currentWorkflowStep.name + ': postWMSTSQueueAction: request sent.' });

    if (Store.debug) { console.log(indent() + 'postWMSTSQueueAction: returning.') };
    callStackDepth--;
}




// Language Functions 
function setLanguage() {
    // this function sets the language to the value from the Change Language form
    Store.current.language = document.getElementById('languageCode').value;
    Store.current.successMessage = 'The Language has been changed to ' + Store.current.language
    updateUI(Store.current.workflowStep);
}

function setLanguageEnglish() {
    // this function sets the language to spanish
    Store.current.language = 'en';
    Store.current.successMessage = 'The Language has been changed to English.'
    updateUI(Store.current.workflowStep);
}

function setLanguageSpanish() {
    // this function sets the language to spanish
    Store.current.language = 'es';
    Store.current.successMessage = 'The Language has been changed to Español.'
    updateUI(Store.current.workflowStep);
}

function setLanguageHindi() {
    // this function sets the language to spanish
    Store.current.language = 'in';
    Store.current.successMessage = 'The Language has been changed to Hindi.'
    updateUI(Store.current.workflowStep);
}

function clearLanguage() {
    //this function clears the language setting 
    Store.current.language = '';
    Store.current.successMessage = 'The Language has been set back to the application default.'
    updateUI(Store.current.workflowStep);
}

function getLanguageText(text) {
    // this function returns the human readable text in the Store.current.language IF there is language set and alternate text defined.
    //if (Store.debug) { console.log(indent() + 'getLanguageText: called with text: ', text) } ;
    if ([Store.current.language] && Store.language && Store.language[text] && Store.language[text][Store.current.language]) {
        return Store.language[text][Store.current.language];
    }
    return text;
}

function getAllLanguageableProperties(objectToInspect, name) {
    // this utility function is used for pulling all strings that can be translated via the language object. 
    if (!Store.current.languageStringsCount) {
        Store.current.languageStringsCount = 0;
    }
    var languageStringsCount = Store.current.languageStringsCount;

    if (!Store.current.languageStrings) {
        Store.current.languageStrings = [];
    }
    var languageStrings = Store.current.languageStrings;

    //console.log('getAllLanguageableProperties: called with objectToInspect:',name, JSON.parse(JSON.stringify(objectToInspect)));
    if (languageStringsCount < 600) {
        languageStringsCount++
        //console.log(languageStringsCount);
        if (Object.prototype.toString.call(objectToInspect) === '[object Array]') {
            //console.log('I am an array')
            // process each object in the array
            for (var arrayIndex = 0; arrayIndex < objectToInspect.length; arrayIndex++) {
                if (typeof objectToInspect === 'object') {
                    getAllLanguageableProperties(objectToInspect[arrayIndex], name + [arrayIndex]);
                }
            }
        }
        if (objectToInspect !== null && Object.prototype.toString.call(objectToInspect) !== '[object Array]') {
            var workingKeys = Object.keys(objectToInspect);
            //console.log('workingKeys', workingKeys);
            if (typeof objectToInspect === 'object') {
                for (var objectKesIndex = 0; objectKesIndex < workingKeys.length; objectKesIndex++) {
                    var workingKey = workingKeys[objectKesIndex];
                    var workingValue = objectToInspect[workingKey];
                    var workingValueType = typeof workingValue;
                    //console.log('working on:', workingKey, workingValueType, workingValue);
                    if (workingValueType === 'string') {
                        if (workingValue && languageStrings.indexOf(workingValue) == -1) {
                            //console.log('text:', workingKey, workingValue);
                            if (workingKey == 'title' || workingKey == 'label' || workingKey == 'tip' || workingKey == 'errorMessage' || workingKey == 'successMessage') {
                                languageStrings.push(workingValue);
                            }
                        }
                    } else if (Object.prototype.toString.call(workingValue) === '[object Array]') {
                        //console.log('this child is an array')
                        getAllLanguageableProperties(workingValue, workingKey);
                    } else if (workingValue === null) {
                        //console.log('this child is null')
                    } else if (workingValue === 'undefined') {
                        //console.log('this child is an undefined')
                    } else if (workingValueType === 'object') {
                        if (Object.prototype.toString.call(workingValue != '[object Array]')) {
                            //console.log('processing next object: ', workingKey, workingValue);
                            getAllLanguageableProperties(workingValue, workingKey);
                        }
                    }
                }
            }
        }
    }
}

/*function missingLanguageKeys(languageCode) {
    // this function compares the languageStrings array generated by the getAllLanguageableProperties function to the languages entries in the Store
    getAllLanguageableProperties(Store,'Store');
    var languageStringsComparison = {};
    for (var languageStringsIndex = 0;languageStringsIndex < languageStrings.length; languageStringsIndex++) {
        var workingLanguageString = {};//{ foundInStore: languageStrings[languageStringsIndex] };
        if (languageCode && Store.language[languageStrings[languageStringsIndex]] && Store.language[languageStrings[languageStringsIndex]][languageCode]) {
            workingLanguageString[languageCode] = Store.language[languageStrings[languageStringsIndex]][languageCode];
        } else if (Store.language[languageStrings[languageStringsIndex]]) {
            var languageKeys = Object.keys(Store.language[languageStrings[languageStringsIndex]])
            for (var languageIndex = 0; languageIndex < languageKeys.length; languageIndex++)
            if (Store.language[languageStrings[languageStringsIndex]][languageKeys[languageIndex]]) {
                workingLanguageString[languageKeys[languageIndex]] = Store.language[languageStrings[languageStringsIndex]][languageKeys[languageIndex]];
            }
        }
        languageStringsComparison[languageStrings[languageStringsIndex]] = workingLanguageString;
    }
    console.log(languageStringsComparison);
}*/

function missingLanguageKeys(languageCode) {
    // this function compares the languageStrings array generated by the getAllLanguageableProperties function to the languages entries in the Store

    if (!Store.current.languageStrings) {
        Store.current.languageStrings = [];
    }
    var languageStrings = Store.current.languageStrings;

    getAllLanguageableProperties(Store, 'Store');
    var languageStringsComparison = [];
    for (var languageStringsIndex = 0; languageStringsIndex < languageStrings.length; languageStringsIndex++) {
        var workingLanguageString = { foundInStore: languageStrings[languageStringsIndex] };
        if (languageCode &&
            Store.language[languageStrings[languageStringsIndex]] &&
            Store.language[languageStrings[languageStringsIndex]][languageCode]) {
            workingLanguageString[languageCode] = Store.language[languageStrings[languageStringsIndex]][languageCode];
        } else if (Store.language[languageStrings[languageStringsIndex]]) {
            var languageKeys = Object.keys(Store.language[languageStrings[languageStringsIndex]])
            for (var languageIndex = 0; languageIndex < languageKeys.length; languageIndex++)
                if (Store.language[languageStrings[languageStringsIndex]][languageKeys[languageIndex]]) {
                    workingLanguageString[languageKeys[languageIndex]] = Store.language[languageStrings[languageStringsIndex]][languageKeys[languageIndex]];
                }
        }
        languageStringsComparison.push(workingLanguageString);
    }

    var sortArray = [{ propertyName: 'foundInStore', sortDirection: 'asc' }]
    //console.log (languageStringsComparison.sort(sortCompare('foundInStore')));
    Store.workflowSteps.languageEntries.searchRequest.searchResultFlat = languageStringsComparison.sort(sortCompare(sortArray));
}





// Search Functions
function getSearchObject(workingObject) {
    // this helper function returns the reference to the search object
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'getSearchObject: called with workingObject name: ', workingObject.name) };

    // validate that we can get to the searchRequest
    if (workingObject.searchRequest) {
        //if (Store.debug) { console.log(indent() + 'getSearchObject: searchRequest exists, returning with searchRequest: ', workingObject.searchRequest.name || 'no name', JSON.parse(JSON.stringify(workingObject.searchRequest)) ) };
        if (Store.debug) { console.log(indent() + 'getSearchObject: searchRequest exists, returning with searchRequest: ', workingObject.searchRequest.name || 'no name' ) };
        callStackDepth--;
        return workingObject.searchRequest;
    } else {
        if (Store.debug) { console.log(indent() + 'getSearchObject: retuning, searchRequest does exist.') };
        callStackDepth--;
        return;
    }
}

function prepareSearchRequest_old(workingObject, actionsArray) {
    // this function builds the searchRequest full URL and full Post
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'prepareSearchRequest: called with:', workingObject.name ) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'prepareSearchRequest: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        console.log(indent() + 'prepareSearchRequest: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    // re-initialize search properties 
    if (!searchRequest.searchResultColumns) {
        searchRequest.searchResultColumns = []
    } else {
        searchRequest.searchResultColumns.length = 0;
    }

    if (!searchRequest.searchResultData) {
        searchRequest.searchResultData = [];
    } else {
        searchRequest.searchResultData.length = 0;
    }

    searchRequest.searchResultRaw = '';
    
    if (!searchRequest.searchResultFlat) {
        searchRequest.searchResultFlat = [];
    } else {
        searchRequest.searchResultFlat.length = 0;
    }

    searchRequest.searchRESTletFullPOST = '';
    searchRequest.searchRESTletFullURL = '';

    // now calculate the full URL and POST

    // Build the Full URL for the request
    searchRequest.searchRESTletFullURL = Store.defaults.url +
        '?script=' + Store.defaults.getSearchResults.scriptID +
        '&deploy=' + Store.defaults.getSearchResults.deploymentID

    // Build the full body string for the POST request if it does not already exist

    var buildingSearchRESTletFullPOST = {};

    // Add the source (one source is required)
    if ( searchRequest.searchRecordType && searchRequest.searchID ) {
        buildingSearchRESTletFullPOST.SearchId = searchRequest.searchID;
        buildingSearchRESTletFullPOST.RecordType = searchRequest.searchRecordType;
    } else if ( searchRequest.searchID ) {
        buildingSearchRESTletFullPOST.SearchId = searchRequest.searchID;
    } else if ( searchRequest.searchName ) {
        buildingSearchRESTletFullPOST.SearchName = searchRequest.searchName;
    } else if ( searchRequest.searchRecordType ) {
        buildingSearchRESTletFullPOST.RecordType = searchRequest.searchRecordType;
    } else if ( searchRequest.SQLQuery ) {
        buildingSearchRESTletFullPOST.SQLQuery = searchRequest.SQLQuery;
    } else {
        Store.current.errorMessage = 'prepareSearchRequest: a SearchId, searchName, or searchRecordType is required.'
        setErrorTip();
        callStackDepth--;
        return;
    }

    // Add the columns (optional)
    if (searchRequest.searchRequestColumns) {
        buildingSearchRESTletFullPOST.Columns = searchRequest.searchRequestColumns;
    }

    // Add the filters (optional) 
    // TODO: the inputs array is being referenced and not "copied" to the inputValues array SRP 20191113

    if ( searchRequest.SQLQuery  ) {
        // no filters yet
    } else if (searchRequest.searchRequestFilters == 'none' ) {
        buildingSearchRESTletFullPOST.Filters = ''; //searchRequest.searchRequestFilters;
    } else if (buildingSearchRESTletFullPOST && buildingSearchRESTletFullPOST.Filters && searchRequest.searchRequestFilters.length > 0) {
        buildingSearchRESTletFullPOST.Filters.push.apply(buildingSearchRESTletFullPOST.Filters, searchRequest.searchRequestFilters);
    } else {
        // if prepareSearchRequest was called from a form with inputs, build a searchRequestUserInputs object 

        // if there are required filters, push them into the filters array
        if ( searchRequest.searchRequestFilters_required && searchRequest.searchRequestFilters_required.length > 0 ) {
            // push the required filters onto the filters array

        }

        //if (Store.debug) { console.log(indent() + 'prepareSearchRequest: workingObject.inputs:', workingObject.inputs) };
        if ( workingObject.inputs && workingObject.inputs.length > 0 ) {

            //clear pre-existing searchRequestUserInputs
            if (searchRequest.searchRequestUserInputs) {
                searchRequest.searchRequestUserInputs.length = 0;
            } else {
                searchRequest.searchRequestUserInputs = [];
            }

            for ( var inputIndex = 0; inputIndex < workingObject.inputs.length; inputIndex++ ) {

                var thisInputObject = workingObject.inputs[inputIndex];

                // Build the User Inputs array
                if (!thisInputObject.value) {  // AB 20190523: Added this extra validation, when we call this function without a workflowStep, was throwing an error
                    // TODO should this be looking at Store not DOM?
                    thisInputObject.value = document.getElementById(thisInputObject.name).value;
                }
                //thisInputObject.value = document.getElementById(thisInputObject.name).value;

                // 20210103 SRP - ignore inputs with a filterFieldTreatment[0] of 'ignore'
                if ( !(thisInputObject.filterFieldTreatment && thisInputObject.filterFieldTreatment[0].toLowerCase() == 'ignore' ) ) {
                    //if (Store.debug) { console.log(indent() + 'prepareSearchRequest: thisInputObject:', thisInputObject) }; 
                    // TODO should we be lookng at workflow step inputsObject and not searchRequestUserInputs?
                    searchRequest.searchRequestUserInputs.push(thisInputObject);
                }
            }
        }

        if (searchRequest.searchRequestUserInputs && searchRequest.searchRequestUserInputs.length > 0) {
            var buildingSearchRequestFilters = [];
            var countOfFilters = 0;
            //If there are filters...
            for (var searchRequestUserInputIndex = 0; searchRequestUserInputIndex < searchRequest.searchRequestUserInputs.length; searchRequestUserInputIndex++) {

                var thisInput = searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]; 
                var thisInputDataType = thisInput.dataType || Store.defaults.dataType || 'string';
                try {
                    // try to do this if the string before the first space is found in the Store.operators object
                    var thisOverrideFilterOperator = Store.operators[thisInput.value.split(' ',1)[0]][thisInputDataType]; 
                    var thisInputCount = Store.operators[thisInput.value.split(' ',1)[0]]['inputCount'] || 1;
                    var thisFilterOperator = thisOverrideFilterOperator || thisInput.filterOperator || Store.defaults.filterOperator || 'contains';
                    var thisInputValue = thisInput.value || thisInput.valueDefault || thisInput[thisInput.valueDefaultProperty]; // SRP: the following is an attempt to get the value default without forcing it to be put in the input value || [thisInput.valueDefaultObject][thisInput.valueDefaultProperty];
                    var thisValue = thisInputValue.substr(thisInputValue.indexOf(' ')+1) ;
                    if (thisInputCount == 1) {
                        var thisValues = [thisValue];
                    } else if (thisInputCount != 0) {
                        var thisValues = thisValue.split(' ');//.shift();
                    } else {
                        var thisValues = [];
                    }
                    //console.log('thisOverrideFilterOperator: ', thisOverrideFilterOperator, thisFilterOperator); 
                    //console.log('Im in the try:', 'thisOverrideFilterOperator', thisOverrideFilterOperator, 'thisInputCount', thisInputCount, 'thisFilterOperator', thisFilterOperator, 'thisInputValue', thisInputValue, 'thisValue', thisValue, 'thisValues', thisValues );
                } 
                catch {
                    var thisFilterOperator = thisInput.filterOperator || Store.defaults.filterOperator || 'contains';
                    var thisInputCount = 1;
                    var thisInputValue = thisInput.value || thisInput.valueDefault || thisInput[thisInput.valueDefaultProperty]; 
                    var thisValue = thisInputValue; // SRP: this is an attempt to get the value default without forcing it to be put in the input value || [thisInput.valueDefaultObject][thisInput.valueDefaultProperty];
                    var thisValues = [thisValue];
                    //console.log('thisOverrideFilterOperator: ', thisFilterOperator); 
                    //console.log('Im in the catch:', 'thisOverrideFilterOperator', thisOverrideFilterOperator, 'thisInputCount', thisInputCount, 'thisFilterOperator', thisFilterOperator, 'thisInputValue', thisInputValue, 'thisValue', thisValue, 'thisValues', thisValues );
                }
                var thisSearchFiled = thisInput.searchField || thisInput.name;
                var thisFilterFieldTreatment = thisInput.filterFieldTreatment || Store.defaults.filterFieldTreatment;
                var thisFilterValueTreatment = workingObject.inputs[searchRequestUserInputIndex]['filterValueTreatment'] || Store.defaults.filterValueTreatment;
                var thisFilterAllowNull = thisInput.filterAllowNull || Store.defaults.filterAllowNull ;

                
                var buildingSearchRequestFilter = [];
                // and If there are inputs in the filters... 
                if (thisInput['value'] && thisSearchFiled.indexOf(' ') === -1 ) { // SRP 20200813: do not build the filter for this input element if thisSearchField contains a space. 

                    // add the operator if this is the 2nd or more user input
                    var operatorString = 'and';
                    if (countOfFilters != 0) {
                        buildingSearchRequestFilters.push(operatorString);
                    }

                    // Build the Filters array

                    // get the filter value if is is needed. 
                    //var thisFilterFieldTreatment = workingObject.inputs[searchRequestUserInputIndex]['filterFieldTreatment'] || Store.defaults.filterFieldTreatment;

                    // prepare the filter field name 
                    thisInput.filterField = thisFilterFieldTreatment[0] +
                        thisSearchFiled +
                        thisFilterFieldTreatment[1];
                    buildingSearchRequestFilter.push(thisInput.filterField);

                    // Now add the filter operator to the filters array
                    // first check for an in-line override

                    //var thisFilterOperator = workingObject.inputs[searchRequestUserInputIndex]['filterOperator'] || Store.defaults.filterOperator;
                    buildingSearchRequestFilter.push(thisFilterOperator);

                    // Now transform and add the filter value 
                    //var thisFilterValue = '';
                    var thisFilterValues = [];
                    if (thisFilterValueTreatment) {
                        // execute the filterValueTreatment on the value
                        //thisFilterValue = window[thisFilterValueTreatment](thisValue);
                        thisFilterValues = window[thisFilterValueTreatment](thisValues); 
                    } else {
                        //thisFilterValue = thisValue;
                        thisFilterValues = thisValues; 
                    }
                    //buildingSearchRequestFilter.push(thisFilterValue);
                    buildingSearchRequestFilter.push.apply(buildingSearchRequestFilter, thisFilterValues);

                    // If the filter needs to support null, add or is empty
                    if (thisFilterAllowNull && !thisOverrideFilterOperator) {
                        // if the filter needs to allow a value OR null, add a filter container
                        var thisFilterWrapper = [];
                        thisFilterWrapper.push(buildingSearchRequestFilter);
                        thisFilterWrapper.push('or');
                        var thisOrArray = [];
                        //thisOrArray.push(thisFilterField);
                        thisOrArray.push(thisInput.filterField);
                        thisOrArray.push('isempty');
                        thisOrArray.push('');
                        thisFilterWrapper.push(thisOrArray);

                        // now add the field, operator, and value to the buildingSearchRequestFilters array.
                        buildingSearchRequestFilters.push(thisFilterWrapper);
                    } else {
                        // now add the field, operator, and value to the buildingSearchRequestFilters array.
                        buildingSearchRequestFilters.push(buildingSearchRequestFilter);
                    }

                    countOfFilters++;
                }
            }

            // SRP 20190505: commenting out the condition so the filters will be emptied
            //if (buildingSearchRequestFilters.length > 0) {
            searchRequest.searchRequestFilters = buildingSearchRequestFilters;
            //}
        }

        if (searchRequest.searchRequestFilters) {
            buildingSearchRESTletFullPOST.Filters = searchRequest.searchRequestFilters;
        } else if (searchRequest.searchRequestUserInputs) {
            // user inputs were provided, build the string.
            delete buildingSearchRESTletFullPOST.Filters;
        }
    }

    // TODO: SRP 20191124: add late binding to filter value here
    // something like finding all filter array values that are objects with a lateBind property and replacing it with the property value
    buildingSearchRESTletFullPOST.Filters = deepArrayLateBind(buildingSearchRESTletFullPOST.Filters);

    // Select the begin or end of the results AB 20191113
    if(!searchRequest.BeginRecord){
        buildingSearchRESTletFullPOST.BeginRecord = Store.defaults.BeginRecord;
    } else if (searchRequest.BeginRecord) {
        buildingSearchRESTletFullPOST.BeginRecord = searchRequest.BeginRecord;
    }
    if(!searchRequest.EndRecord){
        buildingSearchRESTletFullPOST.EndRecord = Store.defaults.EndRecord;
    } else if (searchRequest.EndRecord) {
        buildingSearchRESTletFullPOST.EndRecord = searchRequest.EndRecord;
    }

    searchRequest.searchRESTletFullPOST = JSON.stringify(buildingSearchRESTletFullPOST);

    // Now, if any additional actions were passed in, execute the actions 

    if (Store.debug) { console.log(indent() + 'prepareSearchRequest: returning to processActionArray with: ', workingObject.name, actionsArray) };
    processActionArray(workingObject, actionsArray);

    if (Store.debug) { console.log(indent() + 'prepareSearchRequest: returning.') };
    callStackDepth--;
}

function prepareSearchRequest(workingObject, actionsArray) {
    // this function builds the searchRequest full URL and full Post
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'prepareSearchRequest3: called with:', workingObject.name, actionsArray) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'prepareSearchRequest3: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        console.log(indent() + 'prepareSearchRequest3: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    // re-initialize search properties 
    if (!searchRequest.searchResultColumns) { searchRequest.searchResultColumns = [];  } else { searchRequest.searchResultColumns.length = 0; }
    if (!searchRequest.searchResultData) { searchRequest.searchResultData = []; } else { searchRequest.searchResultData.length = 0; }
    searchRequest.searchResultRaw = '';
    if (!searchRequest.searchResultFlat) { searchRequest.searchResultFlat = []; } else { searchRequest.searchResultFlat.length = 0; }
    searchRequest.searchRESTletFullPOST = '';
    searchRequest.searchRESTletFullURL = '';

    // now calculate the full URL and POST

    // Build the Full URL for the request
    searchRequest.searchRESTletFullURL = Store.defaults.url +
        '?script=' + Store.defaults.getSearchResults.scriptID +
        '&deploy=' + Store.defaults.getSearchResults.deploymentID

    // Build the full body string for the POST request if it does not already exist
    var buildingSearchRESTletFullPOST = {};

    // Add the source (one source is required)
    if ( searchRequest.searchRecordType && searchRequest.searchID ) {
        buildingSearchRESTletFullPOST.SearchId = searchRequest.searchID;
        buildingSearchRESTletFullPOST.RecordType = searchRequest.searchRecordType;
    } else if ( searchRequest.searchID ) {
        buildingSearchRESTletFullPOST.SearchId = searchRequest.searchID;
    } else if ( searchRequest.searchName ) {
        buildingSearchRESTletFullPOST.SearchName = searchRequest.searchName;
    } else if ( searchRequest.searchRecordType ) {
        buildingSearchRESTletFullPOST.RecordType = searchRequest.searchRecordType;
    } else if ( searchRequest.SQLQuery ) {
        buildingSearchRESTletFullPOST.SQLQuery = searchRequest.SQLQuery;
    } else {
        Store.current.errorMessage = 'prepareSearchRequest3: a SearchId, searchName, or searchRecordType is required.'
        setErrorTip();
        callStackDepth--;
        return;
    }

    // Add the columns (optional)
    if (searchRequest.searchRequestColumns) {
        buildingSearchRESTletFullPOST.Columns = searchRequest.searchRequestColumns;
    }

    // Add the filters (optional) 
    // TODO: the inputs array is being referenced and not "copied" to the inputValues array SRP 20191113

    if ( searchRequest.SQLQuery  ) {
        // no filters yet
    } else if (searchRequest.searchRequestFilters == 'none' ) {
        buildingSearchRESTletFullPOST.Filters = ''; //searchRequest.searchRequestFilters;  // TODO should hte be [];
    } else if (buildingSearchRESTletFullPOST && buildingSearchRESTletFullPOST.Filters && searchRequest.searchRequestFilters.length > 0) {
        // this if condition is preventing searchRequestFilters from being combined with input filters
        // perhaps this should move below the inputs processing
        buildingSearchRESTletFullPOST.Filters.push.apply(buildingSearchRESTletFullPOST.Filters, searchRequest.searchRequestFilters);
    } else {
        // if prepareSearchRequest3 was called from a form with inputs, build a searchRequestUserInputs object 

        // add inputs to searchRequestUserInputs
        //if (Store.debug) { console.log(indent() + 'prepareSearchRequest3: workingObject.inputs:', workingObject.inputs) };
        if ( workingObject.inputs && workingObject.inputs.length > 0 ) {

            //clear pre-existing searchRequestUserInputs
            if (searchRequest.searchRequestUserInputs) {
                searchRequest.searchRequestUserInputs.length = 0;
            } else {
                searchRequest.searchRequestUserInputs = [];
            }

            for ( var inputIndex = 0; inputIndex < workingObject.inputs.length; inputIndex++ ) {
                var thisInputObject = workingObject.inputs[inputIndex];

                // Build the User Inputs array
                if (!thisInputObject.value) {  // AB 20190523: Added this extra validation, when we call this function without a workflowStep, was throwing an error
                    // TODO should this be looking at Store not DOM?
                    thisInputObject.value = document.getElementById(thisInputObject.name).value;
                }
                //thisInputObject.value = document.getElementById(thisInputObject.name).value;

                // 20210103 SRP - ignore inputs with a filterFieldTreatment[0] of 'ignore'
                if ( !(thisInputObject.filterFieldTreatment && thisInputObject.filterFieldTreatment[0].toLowerCase() == 'ignore' ) ) {
                    //if (Store.debug) { console.log(indent() + 'prepareSearchRequest3: thisInputObject:', thisInputObject) }; 
                    // TODO should we be lookng at workflow step inputsObject and not searchRequestUserInputs?
                    searchRequest.searchRequestUserInputs.push(thisInputObject);
                }
            }
        }

        if ( searchRequest.searchRequestUserInputs && searchRequest.searchRequestUserInputs.length > 0 ) {
            var buildingSearchRequestFilters = [];
            var countOfFilters = 0;
            //If there are filters...
            for (var searchRequestUserInputIndex = 0; searchRequestUserInputIndex < searchRequest.searchRequestUserInputs.length; searchRequestUserInputIndex++) {
                var thisInput = searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]; 
                var thisInputDataType = thisInput.dataType || Store.defaults.dataType || 'string';

                try {
                    // process input filters if the user entered one
                    // try to do this if the string before the first space is found in the Store.operators object
                    var thisOverrideFilterOperator = Store.operators[thisInput.value.split(' ',1)[0]][thisInputDataType]; 
                    var thisInputCount = Store.operators[thisInput.value.split(' ',1)[0]]['inputCount'] || 1;
                    var thisFilterOperator = thisOverrideFilterOperator || thisInput.filterOperator || Store.defaults.filterOperator || 'contains';
                    var thisInputValue = thisInput.value || thisInput.valueDefault || thisInput[thisInput.valueDefaultProperty]; // SRP: the following is an attempt to get the value default without forcing it to be put in the input value || [thisInput.valueDefaultObject][thisInput.valueDefaultProperty];
                    var thisValue = thisInputValue.substr(thisInputValue.indexOf(' ')+1) ;
                    if (thisInputCount == 1) {
                        var thisValues = [thisValue];
                    } else if (thisInputCount != 0) {
                        var thisValues = thisValue.split(' ');//.shift();
                    } else {
                        var thisValues = [];
                    }
                    //console.log('thisOverrideFilterOperator: ', thisOverrideFilterOperator, thisFilterOperator); 
                    //console.log('Im in the try:', 'thisOverrideFilterOperator', thisOverrideFilterOperator, 'thisInputCount', thisInputCount, 'thisFilterOperator', thisFilterOperator, 'thisInputValue', thisInputValue, 'thisValue', thisValue, 'thisValues', thisValues );
                } 
                catch {
                    var thisFilterOperator = thisInput.filterOperator || Store.defaults.filterOperator || 'contains';
                    var thisInputCount = 1;
                    var thisInputValue = thisInput.value || thisInput.valueDefault || thisInput[thisInput.valueDefaultProperty]; 
                    var thisValue = thisInputValue; // SRP: this is an attempt to get the value default without forcing it to be put in the input value || [thisInput.valueDefaultObject][thisInput.valueDefaultProperty];
                    var thisValues = [thisValue];
                    //console.log('thisOverrideFilterOperator: ', thisFilterOperator); 
                    //console.log('Im in the catch:', 'thisOverrideFilterOperator', thisOverrideFilterOperator, 'thisInputCount', thisInputCount, 'thisFilterOperator', thisFilterOperator, 'thisInputValue', thisInputValue, 'thisValue', thisValue, 'thisValues', thisValues );
                }
                var thisSearchFiled = thisInput.searchField || thisInput.name;
                var thisFilterFieldTreatment = thisInput.filterFieldTreatment || Store.defaults.filterFieldTreatment;
                var thisFilterValueTreatment = workingObject.inputs[searchRequestUserInputIndex]['filterValueTreatment'] || Store.defaults.filterValueTreatment;
                var thisFilterAllowNull = thisInput.filterAllowNull || Store.defaults.filterAllowNull ;

                
                var buildingSearchRequestFilter = [];
                // and If there are inputs in the filters... 
                if (thisInput['value'] && thisSearchFiled.indexOf(' ') === -1 ) { // SRP 20200813: do not build the filter for this input element if thisSearchField contains a space. 

                    // add the operator if this is the 2nd or more user input
                    var operatorString = 'and';
                    if (countOfFilters != 0) {
                        buildingSearchRequestFilters.push(operatorString);
                    }

                    // Build the Filters array

                    // get the filter value if is is needed. 
                    //var thisFilterFieldTreatment = workingObject.inputs[searchRequestUserInputIndex]['filterFieldTreatment'] || Store.defaults.filterFieldTreatment;

                    // prepare the filter field name 
                    thisInput.filterField = thisFilterFieldTreatment[0] +
                        thisSearchFiled +
                        thisFilterFieldTreatment[1];
                    buildingSearchRequestFilter.push(thisInput.filterField);

                    // Now add the filter operator to the filters array
                    // first check for an in-line override

                    //var thisFilterOperator = workingObject.inputs[searchRequestUserInputIndex]['filterOperator'] || Store.defaults.filterOperator;
                    buildingSearchRequestFilter.push(thisFilterOperator);

                    // Now transform and add the filter value 
                    //var thisFilterValue = '';
                    var thisFilterValues = [];
                    if (thisFilterValueTreatment) {
                        // execute the filterValueTreatment on the value
                        //thisFilterValue = window[thisFilterValueTreatment](thisValue);
                        thisFilterValues = window[thisFilterValueTreatment](thisValues); 
                    } else {
                        //thisFilterValue = thisValue;
                        thisFilterValues = thisValues; 
                    }
                    //buildingSearchRequestFilter.push(thisFilterValue);
                    buildingSearchRequestFilter.push.apply(buildingSearchRequestFilter, thisFilterValues);

                    // If the filter needs to support null, add or is empty
                    if (thisFilterAllowNull && !thisOverrideFilterOperator) {
                        // if the filter needs to allow a value OR null, add a filter container
                        var thisFilterWrapper = [];
                        thisFilterWrapper.push(buildingSearchRequestFilter);
                        thisFilterWrapper.push('or');
                        var thisOrArray = [];
                        //thisOrArray.push(thisFilterField);
                        thisOrArray.push(thisInput.filterField);
                        thisOrArray.push('isempty');
                        thisOrArray.push('');
                        thisFilterWrapper.push(thisOrArray);

                        // now add the field, operator, and value to the buildingSearchRequestFilters array.
                        buildingSearchRequestFilters.push(thisFilterWrapper);
                    } else {
                        // now add the field, operator, and value to the buildingSearchRequestFilters array.
                        buildingSearchRequestFilters.push(buildingSearchRequestFilter);
                    }

                    countOfFilters++;
                }
            }

            // SRP 20190505: commenting out the condition so the filters will be emptied
            //if (buildingSearchRequestFilters.length > 0) {
            searchRequest.searchRequestFilters = buildingSearchRequestFilters;
            //}
        }

        if (searchRequest.searchRequestFilters) {
            buildingSearchRESTletFullPOST.Filters = searchRequest.searchRequestFilters;
        } else if (searchRequest.searchRequestUserInputs) {
            // user inputs were provided, build the string.
            delete buildingSearchRESTletFullPOST.Filters;
        }
    }

    // now append any searchRequestFilters_Additional filters, if they exist
    if ( searchRequest.searchRequestFilters_Additional && searchRequest.searchRequestFilters_Additional.length > 0 ) {
        if ( searchRequest.searchRequestFilters && searchRequest.searchRequestFilters.length > 0 ) {
            searchRequest.searchRequestFilters.push('and');
            searchRequest.searchRequestFilters.push( searchRequest.searchRequestFilters_Additional );
        } else {
            searchRequest.searchRequestFilters.push( searchRequest.searchRequestFilters_Additional );
        }
    }

    // TODO: SRP 20191124: add late binding to filter value here
    // something like finding all filter array values that are objects with a lateBind property and replacing it with the property value
    buildingSearchRESTletFullPOST.Filters = deepArrayLateBind(buildingSearchRESTletFullPOST.Filters);

    // Select the begin or end of the results AB 20191113
    if(!searchRequest.BeginRecord){
        buildingSearchRESTletFullPOST.BeginRecord = Store.defaults.BeginRecord;
    } else if (searchRequest.BeginRecord) {
        buildingSearchRESTletFullPOST.BeginRecord = searchRequest.BeginRecord;
    }
    if(!searchRequest.EndRecord){
        buildingSearchRESTletFullPOST.EndRecord = Store.defaults.EndRecord;
    } else if (searchRequest.EndRecord) {
        buildingSearchRESTletFullPOST.EndRecord = searchRequest.EndRecord;
    }

    searchRequest.searchRESTletFullPOST = JSON.stringify(buildingSearchRESTletFullPOST);

    // Now, if any additional actions were passed in, execute the actions 

    if (Store.debug) { console.log(indent() + 'prepareSearchRequest3: returning to processActionArray with: ', workingObject.name, actionsArray) };
    processActionArray(workingObject, actionsArray);

    if (Store.debug) { console.log(indent() + 'prepareSearchRequest3: returning.') };
    callStackDepth--;
}

function deepArrayLateBind(inputArray) {
    // this function looks through an array and lateBind any node that is an object with a property of lateBind (e.g. { lateBind: 'Store.current.location'})
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'deepArrayLateBind: called.') };

    var returnArray = [];

    if ( Array.isArray(inputArray) ) {
        for (var inputArrayIndex = 0; inputArrayIndex < inputArray.length; inputArrayIndex++) {
            // if any of the array values are child arrays, call this function on the child array and get back the resolved child array
            if ( Array.isArray(inputArray[inputArrayIndex]) ) {
                returnArray.push(deepArrayLateBind (inputArray[inputArrayIndex]));
            } else if ( typeof inputArray[inputArrayIndex] == 'object' && inputArray[inputArrayIndex]['lateBind'] ) {
                returnArray.push(lateBind (inputArray[inputArrayIndex]['lateBind'])); 
            } else {
                returnArray.push(inputArray[inputArrayIndex])
            }
        }

        if (Store.debug) { console.log(indent() + 'deepArrayLateBind: returning with returnArray.' ) };
        callStackDepth--;
        return returnArray;

    }

    if (Store.debug) { console.log(indent() + 'deepArrayLateBind: returning, input is not an Array.') };
    callStackDepth--;

}


function prepareSearchRequest2(workingObject, actionsArray) {
    // this function builds the searchRequest full URL and full Post
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: called with:', workingObject.name, actionsArray) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'prepareSearchRequest2: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject); //workingObject);
    if (!searchRequest) {
        console.log(indent() + 'prepareSearchRequest2: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    // re-initialize search properties 
    if (!searchRequest.searchResultColumns) {
        searchRequest.searchResultColumns = []
    } else {
        searchRequest.searchResultColumns.length = 0;
    }

    if (!searchRequest.searchResultData) {
        searchRequest.searchResultData = [];
    } else {
        searchRequest.searchResultData.length = 0;
    }

    searchRequest.searchResultRaw = '';
    
    if (!searchRequest.searchResultFlat) {
        searchRequest.searchResultFlat = [];
    } else {
        searchRequest.searchResultFlat.length = 0;
    }

    searchRequest.searchRESTletFullPOST = '';
    searchRequest.searchRESTletFullURL = '';

    // now calculate the full URL and POST

    // Build the Full URL for the request
    searchRequest.searchRESTletFullURL = Store.defaults.url +
        '?script=' + Store.defaults.getSearchResults.scriptID +
        '&deploy=' + Store.defaults.getSearchResults.deploymentID

    // Build the full body string for the POST request if it does not already exist

    var buildingSearchRESTletFullPOST = {};

    // Add the source (one source is required)
    if (searchRequest.searchID) {
        buildingSearchRESTletFullPOST.SearchId = searchRequest.searchID;
    } else if (searchRequest.searchName) {
        buildingSearchRESTletFullPOST.SearchName = searchRequest.searchName;
    } else if (searchRequest.searchRecordType) {
        buildingSearchRESTletFullPOST.RecordType = searchRequest.searchRecordType;
    } else {
        Store.current.errorMessage = 'prepareSearchRequest2: a SearchId, searchName, or searchRecordType is required.'
        setErrorTip();
        callStackDepth--;
        return;
    }

    // Add the columns (optional)
    if (searchRequest.searchRequestColumns) {
        buildingSearchRESTletFullPOST.Columns = searchRequest.searchRequestColumns;
    }

    // Add the filters (optional) 
    // TODO: the inputs array is being referenced and not "copied" to the inputValues array SRP 20191113
    buildingSearchRESTletFullPOST.Filters = []
    if (searchRequest.searchRequestFilters == 'none' ) {
        buildingSearchRESTletFullPOST.Filters = []; //searchRequest.searchRequestFilters;
    } else if (buildingSearchRESTletFullPOST && buildingSearchRESTletFullPOST.Filters && searchRequest.searchRequestFilters && searchRequest.searchRequestFilters.length > 0) {
        buildingSearchRESTletFullPOST.Filters.push.apply( buildingSearchRESTletFullPOST.Filters, searchRequest.searchRequestFilters);
    } // SRP 20210327 else {
        // if prepareSearchRequest2 was called from a form with inputs, build a searchRequestUserInputs object 

        //if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: workingObject.inputs:', workingObject.inputs) };
        if (workingObject.inputs && workingObject.inputs.length > 0) {

            //clear pre-existing searchRequestUserInputs
            if (searchRequest.searchRequestUserInputs) {
                searchRequest.searchRequestUserInputs.length = 0;
            } else {
                searchRequest.searchRequestUserInputs = [];
            }

            for (var inputIndex = 0; inputIndex < workingObject.inputs.length; inputIndex++) {

                var thisInputObject = workingObject.inputs[inputIndex];

                // Build the User Inputs array
                if (!thisInputObject.value) {  // AB 20190523: Added this extra validation, when we call this function without a workflowStep, was throwing an error
                    thisInputObject.value = document.getElementById(thisInputObject.name).value;
                }
                //thisInputObject.value = document.getElementById(thisInputObject.name).value;

                // 20210103 SRP - ignore inputs with a filterFieldTreatment[0] of 'ignore'
                if ( !(thisInputObject.filterFieldTreatment && thisInputObject.filterFieldTreatment[0].toLowerCase() == 'ignore' ) ) {
                    //if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: thisInputObject:', thisInputObject) }; 
                    searchRequest.searchRequestUserInputs.push(thisInputObject);
                }
            }
        }

        if (searchRequest.searchRequestUserInputs && searchRequest.searchRequestUserInputs.length > 0) {
            if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: Has Inputs:', searchRequest.searchRequestUserInputs) }; 
            var buildingSearchRequestFilters = [];
            var countOfFilters = 0;
            //If there are filters...
            for (var searchRequestUserInputIndex = 0; searchRequestUserInputIndex < searchRequest.searchRequestUserInputs.length; searchRequestUserInputIndex++) {

                var thisInput = searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]; 
                var thisInputDataType = thisInput.dataType || Store.defaults.dataType || 'string';
                try {
                    // try to do this if the string before the first space is found in the Store.operators object
                    var thisOverrideFilterOperator = Store.operators[thisInput.value.split(' ',1)[0]][thisInputDataType]; 
                    var thisInputCount = Store.operators[thisInput.value.split(' ',1)[0]]['inputCount'] || 1;
                    var thisFilterOperator = thisOverrideFilterOperator || thisInput.filterOperator || Store.defaults.filterOperator || 'contains';
                    var thisInputValue = thisInput.value || thisInput.valueDefault || thisInput[thisInput.valueDefaultProperty]; // SRP: the following is an attempt to get the value default without forcing it to be put in the input value || [thisInput.valueDefaultObject][thisInput.valueDefaultProperty];
                    var thisValue = thisInputValue.substr(thisInputValue.indexOf(' ')+1) ;
                    if (thisInputCount == 1) {
                        var thisValues = [thisValue];
                    } else if (thisInputCount != 0) {
                        var thisValues = thisValue.split(' ');//.shift();
                    } else {
                        var thisValues = [];
                    }
                    //console.log('thisOverrideFilterOperator: ', thisOverrideFilterOperator, thisFilterOperator); 
                    //console.log('Im in the try:', 'thisOverrideFilterOperator', thisOverrideFilterOperator, 'thisInputCount', thisInputCount, 'thisFilterOperator', thisFilterOperator, 'thisInputValue', thisInputValue, 'thisValue', thisValue, 'thisValues', thisValues );
                } 
                catch {
                    var thisFilterOperator = thisInput.filterOperator || Store.defaults.filterOperator || 'contains';
                    var thisInputCount = 1;
                    var thisInputValue = thisInput.value || thisInput.valueDefault || thisInput[thisInput.valueDefaultProperty]; 
                    var thisValue = thisInputValue; // SRP: this is an attempt to get the value default without forcing it to be put in the input value || [thisInput.valueDefaultObject][thisInput.valueDefaultProperty];
                    var thisValues = [thisValue];
                    //console.log('thisOverrideFilterOperator: ', thisFilterOperator); 
                    if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: Im in the catch:', 'thisOverrideFilterOperator', thisOverrideFilterOperator, 'thisInputCount', thisInputCount, 'thisFilterOperator', thisFilterOperator, 'thisInputValue', thisInputValue, 'thisValue', thisValue, 'thisValues', thisValues ) };
                }
                var thisSearchFiled = thisInput.searchField || thisInput.name;
                var thisFilterFieldTreatment = thisInput.filterFieldTreatment || Store.defaults.filterFieldTreatment;
                var thisFilterValueTreatment = workingObject.inputs[searchRequestUserInputIndex]['filterValueTreatment'] || Store.defaults.filterValueTreatment;
                var thisFilterAllowNull = thisInput.filterAllowNull || Store.defaults.filterAllowNull ;

                
                var buildingSearchRequestFilter = [];
                // and If there are inputs in the filters... 
                if (thisInput['value'] && thisSearchFiled.indexOf(' ') === -1 ) { // SRP 20200813: do not build the filter for this input element if thisSearchField contains a space. 

                    // add the operator if this is the 2nd or more user input
                    var operatorString = 'and';
                    if (countOfFilters != 0) {
                        buildingSearchRequestFilters.push(operatorString);
                    }

                    // Build the Filters array

                    // get the filter value if is is needed. 
                    //var thisFilterFieldTreatment = workingObject.inputs[searchRequestUserInputIndex]['filterFieldTreatment'] || Store.defaults.filterFieldTreatment;

                    // prepare the filter field name 
                    thisInput.filterField = thisFilterFieldTreatment[0] +
                        thisSearchFiled +
                        thisFilterFieldTreatment[1];
                    buildingSearchRequestFilter.push(thisInput.filterField);

                    // Now add the filter operator to the filters array
                    // first check for an in-line override

                    //var thisFilterOperator = workingObject.inputs[searchRequestUserInputIndex]['filterOperator'] || Store.defaults.filterOperator;
                    buildingSearchRequestFilter.push(thisFilterOperator);

                    // Now transform and add the filter value 
                    //var thisFilterValue = '';
                    var thisFilterValues = [];
                    if (thisFilterValueTreatment) {
                        // execute the filterValueTreatment on the value
                        //thisFilterValue = window[thisFilterValueTreatment](thisValue);
                        thisFilterValues = window[thisFilterValueTreatment](thisValues); 
                    } else {
                        //thisFilterValue = thisValue;
                        thisFilterValues = thisValues; 
                    }
                    //buildingSearchRequestFilter.push(thisFilterValue);
                    buildingSearchRequestFilter.push.apply(buildingSearchRequestFilter, thisFilterValues);

                    if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: buildingSearchRequestFilter:', buildingSearchRequestFilter) };

                    // If the filter needs to support null, add or is empty
                    if (thisFilterAllowNull && !thisOverrideFilterOperator) {
                        // if the filter needs to allow a value OR null, add a filter container
                        var thisFilterWrapper = [];
                        thisFilterWrapper.push(buildingSearchRequestFilter);
                        thisFilterWrapper.push('or');
                        var thisOrArray = [];
                        //thisOrArray.push(thisFilterField);
                        thisOrArray.push(thisInput.filterField);
                        thisOrArray.push('isempty');
                        thisOrArray.push('');
                        thisFilterWrapper.push(thisOrArray);

                        // now add the field, operator, and value to the buildingSearchRequestFilters array.
                        buildingSearchRequestFilters.push(thisFilterWrapper);
                    } else {
                        // now add the field, operator, and value to the buildingSearchRequestFilters array.
                        buildingSearchRequestFilters.push(buildingSearchRequestFilter);
                    }

                    countOfFilters++;
                }
            }

            // SRP 20190505: commenting out the condition so the filters will be emptied
            //if (buildingSearchRequestFilters.length > 0) {
            // SRP 20210327 searchRequest.searchRequestFilters = buildingSearchRequestFilters;
            //}
        }

        if (searchRequest.searchRequestFilters && searchRequest.searchRequestFilters.length > 0) {
            buildingSearchRESTletFullPOST.Filters.push(searchRequest.searchRequestFilters);
        } 
        if (buildingSearchRequestFilters && buildingSearchRequestFilters.length > 0) {
            // user inputs were provided, add them to the filters.
            buildingSearchRESTletFullPOST.Filters.push(operatorString);
            buildingSearchRESTletFullPOST.Filters.push(buildingSearchRequestFilters);
        }
    // }

    // TODO: SRP 20191124: add late binding to filter value here
    // something like finding all filter array values that are objects with a lateBind property and replacing it with the property value
    buildingSearchRESTletFullPOST.Filters = deepArrayLateBind(buildingSearchRESTletFullPOST.Filters);
    if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: buildingSearchRESTletFullPOST.Filters:', buildingSearchRESTletFullPOST.Filters) };

    // Select the begin or end of the results AB 20191113
    if(!searchRequest.BeginRecord){
        buildingSearchRESTletFullPOST.BeginRecord = Store.defaults.BeginRecord;
    } else if (searchRequest.BeginRecord) {
        buildingSearchRESTletFullPOST.BeginRecord = searchRequest.BeginRecord;
    }
    if(!searchRequest.EndRecord){
        buildingSearchRESTletFullPOST.EndRecord = Store.defaults.EndRecord;
    } else if (searchRequest.EndRecord) {
        buildingSearchRESTletFullPOST.EndRecord = searchRequest.EndRecord;
    }

    searchRequest.searchRESTletFullPOST = JSON.stringify(buildingSearchRESTletFullPOST);

    // Now, if any additional actions were passed in, execute the actions 

    if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: returning to processActionArray with: ', workingObject.name, actionsArray) };
    processActionArray(workingObject, actionsArray);

    if (Store.debug) { console.log(indent() + 'prepareSearchRequest2: returning.') };
    callStackDepth--;
}

function lateBind(referenceString) {
    // this function gets the value of a property.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'lateBind: called with:', referenceString) };

    // validate is string or object is passed in
    if (typeof referenceString == 'object') {
        // if it is already an object reference, just return it 
        var referenceValue = referenceString;
    } else {
        // if is anything but an object reference, get the value and return it.
        var referenceValue = window;
        var referenceArray = [];

        // SRP 20210327 - added the replaces so that the sting can reference an array entry (e.g. somObject.someChileArray[0]), 
        //    property name with special characters (e.g. somObject.someChileArray["0fish"]).
        //    property/object/array names with a . inside [] (e.g. somObject.someChileArray["fish.bones"])... the ~ is replaced in the for loop.
        var dotInSquareBrackets = /(\[[",']\w*[^\.])(\.)([^\.]\w*[",']\])/;
        var workingPath = referenceString.replace(dotInSquareBrackets, '$1' + '~' + '$3').replaceAll('[','.').replaceAll('"','').replaceAll("'","").replaceAll(']','');

        referenceArray = workingPath.split(".");
        for (var referenceIndex = 0; referenceIndex < referenceArray.length; referenceIndex++) {
            var thisPropertyName = referenceArray[referenceIndex].replaceAll('~','.');
            referenceValue = referenceValue[thisPropertyName];
            //if (Store.debug) { console.log(indent() + 'lateBind: thisPropertyName, referenceValue:', thisPropertyName, referenceValue) };
        }
    }

    if (Store.debug) { console.log(indent() + 'lateBind: returning with:', referenceValue) };
    callStackDepth--;

    return referenceValue;
}

/*function setFiltersFromInput(workingObject, actionsArray) {
    //this function builds search filters from the current search user inputs 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setFiltersFromInput: called with workingObject, actionsArray:', workingObject.name, actionsArray) };

    // verify actionsArray and return if not valid
    if (!actionsArray) {
        if (Store.debug) { console.log(indent() + 'setFiltersFromInput: called with no actions, returning.') };
        callStackDepth--;
        return;
    }

    // this is a test to determine is this is processing
    if (Store.debug) { console.log(indent() + 'setFiltersFromInput: !!!! called with actions !!!') };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        if (Store.debug) { console.log(indent() + 'setFiltersFromInput: no workingObject, returning.') };
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        if (Store.debug) { console.log(indent() + 'setFiltersFromInput: no searchRequest, returning.') };
        callStackDepth--;
        return;
    }

    // get the input values
    searchRequest.searchRequestUserInputs = Store.current.inputs;

    if (searchRequest.searchRequestUserInputs.length > 0) {
        var buildingSearchRequestFilters = [];
        var countOfFilters = 0;
        for (var searchRequestUserInputIndex = 0; searchRequestUserInputIndex < searchRequest.searchRequestUserInputs.length; searchRequestUserInputIndex++) {

            //if (Store.debug) { console.log(indent() + 'setFiltersFromInput: searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]', searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]) };

            var buildingSearchRequestFilter = [];
            if (searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]['value']) {

                // add the operator if there is more than one user input
                var operatorString = 'and';
                if (countOfFilters != 0) {
                    buildingSearchRequestFilters.push(operatorString);
                }

                // Build the Filters array
                // The following is a hack to allow contains on all fields
                buildingSearchRequestFilter.push('formulatext: {' + searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]['name'] + '}');
                // buildingSearchRequestFilter.push(searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]['name']);
                // !!!! the operator needs to be derived from the workflow definition 
                buildingSearchRequestFilter.push('contains');
                buildingSearchRequestFilter.push(searchRequest.searchRequestUserInputs[searchRequestUserInputIndex]['value']);
                buildingSearchRequestFilters.push(buildingSearchRequestFilter);
                //if (Store.debug) { console.log(indent() + 'setFiltersFromInput: Building the User Inputs Object: searchRequest.searchRequestFilters: ', searchRequest.searchRequestFilters) };

                countOfFilters++;
            }
        }

        if (buildingSearchRequestFilters.length != 0) {
            //searchRequest.searchRequestFilters = [];
            searchRequest.searchRequestFilters = buildingSearchRequestFilters;
        }
    }

    if (Store.debug) { console.log(indent() + 'setFiltersFromInput: returning.') };
    callStackDepth--;
}*/

function getSearchResults(workingObject, actionsArray) {
    // This function will request search results from NetSuite 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'getSearchResults: called with workingObject:', workingObject.name ) };

    // verify actionsArray and return if not valid
    if (!actionsArray) {
        if (Store.debug) { console.log(indent() + 'getSearchResults: called with no actions, returning.') };
        callStackDepth--;
        return;
    }

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'getSearchResults: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        console.log(indent() + 'getSearchResults: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    // Set the starting time in the Search Status 
    if (!searchRequest.searchStatus) {
        searchRequest.searchStatus = {};
    }

    searchRequest.searchStatus.localBeginTime = Date.now();

    var xhr = new XMLHttpRequest();
    xhr.open("POST", searchRequest.searchRESTletFullURL, true);

    //Set the proper header information to send along with the request
    xhr.setRequestHeader("Content-Type", "application/json");
    setAuthHeader(xhr);

    xhr.onreadystatechange = function () {//Call a function when the state changes.
        // Because the request is Asynchronous, this code will not run util the response is returned.
        callStackDepth++;
        //if (Store.debug) { console.log(indent() + 'getSearchResults: Async called for: workingObject:', workingObject.name) };
        //if (Store.debug) { console.log(indent() + 'getSearchResults: Async called with: workingObject, actionsArray:', workingObject.name, actionsArray) };
        if (Store.debug) { console.log(indent() + 'getSearchResults: Async called with: workingObject, status:', workingObject.name, xhr.status, xhr.statusText) };

        if (xhr.status === 404) {
            // problem talking to the server
            if (Store.debug) { console.log(indent() + 'getSearchResults: Async returned 404:', xhr.statusText) };

            Store.current.successMessage = '';
            Store.current.errorMessage = 'Sorry, There was an issue talking with the server.  Please check the logs... 404.';

        } else if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {

            //if (Store.debug) { console.log(indent() + 'getSearchResults 200:', workingObject.name, actionsArray) };

            // record the actual response time and total the request to response total time. 
            searchRequest.searchStatus.localResponseTime = Date.now();
            searchRequest.searchStatus.localTotalRemoteTime = searchRequest.searchStatus.localResponseTime - searchRequest.searchStatus.localRequestTime;

            //save the raw results 
            searchRequest.searchResultRaw = xhr.responseText

            if (Store.debug) { console.log(indent() + 'getSearchResults: Async returned length:', JSON.parse(searchRequest.searchResultRaw).status.length) };
            // if no results were returned set the error message
            if (typeof JSON.parse(searchRequest.searchResultRaw).status.length == 'undefined') {
                if (Store.debug) { console.log(indent() + 'getSearchResults: Async returned no length:', xhr.responseText) };
                Store.current.successMessage = '';
                Store.current.errorMessage = Store.current.errorMessage + 'Sorry, there was an issue with that search. </br>';
                processActionArray(workingObject, actionsArray);
            } else if (JSON.parse(searchRequest.searchResultRaw).status.length == 0) {
                if (Store.debug) { console.log(indent() + 'getSearchResults: Async returned 0:', xhr.responseText) };
                Store.current.successMessage = '';
                // AB 20190815 added, to hide unwanted 'Sorry, No results for that' when loading a datalist
                if(searchRequest.noResultErrorMessage != false){
                    Store.current.errorMessage = 'Sorry, No Results for that.';
                }
                processActionArray(workingObject, actionsArray);
            } else {
                // Now, if any additional actions were passed in, execute the actions 
                if (Store.debug) { console.log(indent() + 'getSearchResults: Async 200 workingObject:', workingObject.name ) };
                processActionArray(workingObject, actionsArray);
            }
        } else if (this.readyState == XMLHttpRequest.DONE) {
            // if any response other than 200
            if (Store.debug) { console.log(indent() + 'getSearchResults: Async returned other than 200:', xhr.statusText) };

            //if ( JSON.parse(searchRequest.searchResultRaw) == 'object' && JSON.parse(searchRequest.searchResultRaw).status && JSON.parse(searchRequest.searchResultRaw).status.length && JSON.parse(searchRequest.searchResultRaw).status.length < 1) {
            Store.current.successMessage = '';
            Store.current.errorMessage = 'Sorry, There was an issue talking with the server.  Please check the logs.';
            processActionArray(workingObject, actionsArray);
            //}
        }
        if (Store.debug) { console.log(indent() + 'getSearchResults: Async returning from: workingObject: ', workingObject.name) };
        callStackDepth--;
    }

    // Start the search request timer 
    searchRequest.searchStatus.localRequestTime = Date.now();
    // send the request
    xhr.send(searchRequest.searchRESTletFullPOST);

    if (Store.debug) { console.log(indent() + 'getSearchResults: returning.') };
    callStackDepth--;
}

function persistSearchResults(workingObject, actionsArray) {
    //this function persists the search results
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'persistSearchResults: called with: workingObject, actionsArray ', workingObject.name, actionsArray) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'persistSearchResults: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        console.log(indent() + 'persistSearchResults: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    // convert the response into a workable object.
    var resultRaw = JSON.parse(searchRequest.searchResultRaw);

    // update the response status elements
    searchRequest.searchStatus.RESTletStatusMessage = resultRaw.status.message;
    searchRequest.searchStatus.RESTletBeginTime = resultRaw.status.processStartTime;
    searchRequest.searchStatus.RESTletEndTime = resultRaw.status.processEndTime;
    searchRequest.searchStatus.RESTletTotalTime = resultRaw.status.processingTime;
    searchRequest.searchStatus.RESTletSuccess = resultRaw.status.success;
    searchRequest.searchStatus.RESTletResultCount = resultRaw.status.length;

    // update columns and data 
    searchRequest.searchResultColumns = resultRaw.columns;
    searchRequest.searchResultData = resultRaw.results;
    resetSelectedResults(searchRequest);
    flattenSearchResults(workingObject, []);//actionsArray

    // set success or error messages
    if (searchRequest.searchResultData.length > 0) {
        Store.current.errorMessage = '';
        if (searchRequest.searchSuccessTip != 'none') {
            Store.current.successMessage = getLanguageText('I found ') + searchRequest.searchResultData.length + getLanguageText(' results.');
            // AB 20191113 - Added a 'user reminder' that the limit are 1000 results and they need to improve their filtering
            // @SRP set check to the search request EndRecord AND the Store.defaults.EndRecord
            if(searchRequest.searchResultData.length == 1000){
                Store.current.successMessage+=", there are more results, the search is limited to 1000 results, please enhance the filtering.";
            }
        }
    } else {
        Store.current.successMessage = '';
        // AB 20190815 added, to hide unwanted 'Sorry, No results for that' when loading a datalist
        if(searchRequest.noResultErrorMessage !== false){
            Store.current.errorMessage = getLanguageText('persistSearchResults: Sorry, No Results for that.');
        }
    }

    // call processActionArray with any child actions 
    processActionArray(workingObject, actionsArray);

}

function resetSelectedResults(searchRequest){
    // this function clears the selectedResults
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'resetSelectedResults: called.' ) };

    if ( searchRequest.selectedResults ) { 
        searchRequest.selectedResults.length = 0;
    } else {
        searchRequest.selectedResults = [];
    }

    if (Store.debug) { console.log(indent() + 'resetSelectedResults: returning.' ) };
    callStackDepth--;
}

function getSearchResultValueByPropertyValue(arrayToSearch, findPropertyName, findPropertyValue, returnPropertyName) {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'getSearchResultValueByPropertyValue: called.') };

    for (var arrayIndex = 0; arrayIndex < arrayToSearch.length; arrayIndex++) {
        if (arrayToSearch[arrayIndex]['values'][findPropertyName] === findPropertyValue) {
            callStackDepth--;
            return arrayToSearch[arrayIndex]['values'][returnPropertyName];
        }
    }

    if (Store.debug) { console.log(indent() + 'getSearchResultValueByPropertyValue: returning.') };
    callStackDepth--;
}

function flattenSearchResults(workingObject, actionsArray) {
    // This function produces a more consumable results array 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'flattenSearchResults: called with: workingObject:', workingObject.name ) };
    //if (Store.debug) { console.log(indent() + 'flattenSearchResults: called with: workingObject, actionsArray', workingObject, actionsArray) };

    // verify actionsArray and return if not valid
    if (!actionsArray) {
        console.log(indent() + 'flattenSearchResults: called with no actions, returning.');
        callStackDepth--;
        return;
    }

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'flattenSearchResults: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);
    if (!searchRequest) {
        console.log(indent() + 'flattenSearchResults: no searchRequest, returning.');
        callStackDepth--;
        return;
    }

    // set source and target 
    var searchResultData = searchRequest.searchResultData;
    var searchResultFlat = [];

    // for each result
    // !!! CHANGE: if there are no results raise an error and return. 
    for (var resultIndex = 0; resultIndex < searchResultData.length; resultIndex++) {

        // build a flat result object to put in the array.
        var flatResult = {};

        // this result
        var searchResult = searchResultData[resultIndex];
        //console.log(indent() + 'flattenSearchResults: searchResult: ', searchResult);

        // add properties to the object
        flatResult.id = searchResult['id'];
        flatResult.recordType = searchResult['recordType'];

        // get the names of each property in the values object
        var searchResultValues = searchResult.values;
        var searchResultValueKeys = Object.keys(searchResultValues);

        // for each value in the result
        for (var resultValueIndex = 0; resultValueIndex < searchResultValueKeys.length; resultValueIndex++) {

            var searchResultValue = searchResultValues[searchResultValueKeys[resultValueIndex]];
            var searchResultValueName = searchResultValueKeys[resultValueIndex];

            if (typeof searchResultValue == 'object') {
                if (searchResultValue.length > 0) {
                    flatResult[searchResultValueName] = searchResultValue[0]['text'];

                    // iterate over the childElements and add flat properties for each.
                    for (var searchResultObjectIndex = 0; searchResultObjectIndex < searchResultValue.length; searchResultObjectIndex++) {
                        var searchResultObjectKeys = Object.keys(searchResultValue[searchResultObjectIndex]);
                        for (var searchResultObjectKeysIndex = 0; searchResultObjectKeysIndex < searchResultObjectKeys.length; searchResultObjectKeysIndex++) {
                            // if there is only one object in the array, don't show the index
                            var childNameIndex = '.'
                            if (searchResultValue.length != 1) {
                                var childNameIndex = '.' + searchResultObjectIndex + '.';
                            }

                            flatResult[searchResultValueName + childNameIndex + searchResultObjectKeys[searchResultObjectKeysIndex]] = searchResultValue[searchResultObjectIndex][searchResultObjectKeys[searchResultObjectKeysIndex]];
                        }
                    }
                    // create a function that can be iterated over to get the names and values or be recalled for children. 
                } else {
                    //if (Store.debug) { console.log(indent() + 'flattenSearchResults: searchResultValueName: ', searchResultValueName) };
                    flatResult[searchResultValueName] = '';
                    flatResult[searchResultValueName + 'Object'] = searchResultValue;
                }
            } else {
                flatResult[searchResultValueName] = searchResultValue;
            }
        }
        searchResultFlat.push(flatResult);
        //console.log(indent() + 'flattenSearchResults: searchResultFlat, flatResult: ',  searchResultFlat, flatResult);

    }
    // now put the searchResultFlat in the search results object
    //searchRequest['searchResultFlat'] = searchResultFlat;
    //searchRequest['searchResultFilter'] = JSON.parse(JSON.stringify(searchResultFlat)); //Edited by MT - Changed SRP to not be a reference 20190520
    searchRequest.searchResultFlat.push.apply(searchRequest.searchResultFlat, searchResultFlat);
    //searchRequest.searchResultFilter.push.apply(searchRequest.searchResultFilter, JSON.parse(JSON.stringify(searchResultFlat))); //SRP Avoid replacing the array... just append to it

    updateSearchResultVisibility(searchRequest);

    if (Store.debug) { console.log(indent() + 'flattenSearchResults: returning.') };
    callStackDepth--;
}

function allResultsProcessed(conditionInput) {
    // this function is typically used on a detail workflow step and returns true if all results were processed.
    // note: for this iteration, this is if the list that called the detail form had only one result in searchResultFilter... future versions will need to look at how many records were being processed (if the detail is processing multi-select)
    callStackDepth++;
    if (Store.debug) {console.log(indent() + 'allResultsProcessed: called.')};

    var workingObject = getWorkingObject();
    //if (Store.debug) {console.log(indent() + 'allResultsProcessed: workingObject', JSON.parse(JSON.stringify(workingObject)))};

    // TODO: this should be changed to use the foundation summarized data.
    if (workingObject.searchRequest.searchResultFlat && workingObject.searchRequest.searchResultFlat.length ) {
        var originalResultsCount = workingObject.searchRequest.countProcessedNot; //.searchResultFlat.length;
    } else {
        var originalResultsCount = 0;
    }

    //if (Store.debug) {console.log(indent() + 'allResultsProcessed: workingObject, originalResultsCount', JSON.parse(JSON.stringify(workingObject)), originalResultsCount)};
    
    if (originalResultsCount <= 0 ) { 
        var conditionReturn = true;
    } else {
        var conditionReturn = false;
    }

    //if (Store.debug) {console.log(indent() + 'allResultsProcessed: conditionReturn', conditionReturn)};

    // this determines if the function returns true or false if all the records are processed. 
    //if (Store.debug) {console.log(indent() + 'allResultsProcessed: typeof conditionInput', typeof conditionInput)};

    if (typeof conditionInput == 'boolean') {
        var trueIfTrue = conditionInput;
    } else if (typeof conditionInput == 'unknown' || (typeof conditionInput == 'string' && conditionInput == 'true')) {
        //if (Store.debug) {console.log(indent() + 'allResultsProcessed: string conditionInput', true)};
        var trueIfTrue = true;
    } else if (typeof conditionInput == 'string' && conditionInput == 'false') {
        //if (Store.debug) {console.log(indent() + 'allResultsProcessed: string conditionInput', false)};
        var trueIfTrue = false;
    } else {
        //if (Store.debug) {console.log(indent() + 'allResultsProcessed: default conditionInput', true)};
        var trueIfTrue = true;
    }

    //if (Store.debug) {console.log(indent() + 'allResultsProcessed: trueIfTrue', trueIfTrue)};
    
    if (trueIfTrue === false) {
        conditionReturn = !conditionReturn;
    }

    if (Store.debug) {console.log(indent() + 'allResultsProcessed: returning.')};
    callStackDepth--;

    return conditionReturn;
}





// Form Functions 
function setWorkingInputs(workingObject) {
    callStackDepth++;
    //this function clears previous inputs and rebuilds it from the current form.
    if (Store.debug) { console.log(indent() + 'setWorkingInputs: called with: ', workingObject) };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'setWorkingInputs: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    var workingOn = workingObject;
    if (Store.debug) { console.log(indent() + 'setWorkingInputs: workingOn', workingOn) };

    // if the current workflow step has elements, iterate
    for (var elementIndex = 0; elementIndex < workingOn.length; elementIndex++) {
        var workingOnElement = workingOn[elementIndex]

        if (workingOnElement.type == 'input') {
            // add the element to inputs
            workingObject.inputs.push(workingOnElement.name);

        } else if (workingOnElement.elements) {
            // if the current element is elements, iterate
            setWorkingInputs(workingOnElement.elements);
        }
    }

    if (Store.debug) { console.log(indent() + 'setWorkingInputs: returning.') };
    callStackDepth--;
}

function setWorkingInputValues(workingObject) {
    //this function clears any previous inputs and persists the current form inputs.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setWorkingInputValues: called.') };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'setWorkingInputValues: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    //clear pre-existing inputValues
    //if ( workingObject.inputValues ) {
    //    workingObject.inputValues.length = 0;
    //} else {
        workingObject.inputValues = [];
    //}

    if (!workingObject.inputObject) {
        workingObject.inputObject = {};
    }

    for (var inputIndex = 0; inputIndex < workingObject.inputs.length; inputIndex++) {
        var thisInputObject = workingObject.inputs[inputIndex];
        //if (Store.debug) { console.log(indent() + 'setWorkingInputValues: thisInputObject:',thisInputObject) };
        var thisInputDOMObject = document.getElementById(thisInputObject.name);
        var thisInputValue = thisInputDOMObject.value  || thisInputDOMObject.getAttribute('value');
        //console.log(indent() + 'thisInputValue',thisInputValue);
        workingObject.inputObject[thisInputObject.name] = thisInputObject;
        // if the input object has a datalist, add the data list to the object.
        if (thisInputObject.datalistSource) {
            // now set the selected datalist option if the option entered is in the list.
            // TODO we may want to look at static "data" lists as well. 
            var thisDatalist = Store.datalists[thisInputObject.datalistSource]
            //if (Store.debug) { console.log(indent() + 'setWorkingInputValues: thisInputValue:',thisInputValue) };
            if ( thisDatalist.searchRequest && thisDatalist.searchRequest.searchResultFlat && thisDatalist.searchRequest.searchResultFlat.length ) {
                var thisDatalistData = thisDatalist.searchRequest.searchResultFlat;
            } else {
                var thisDatalistData = thisDatalist.data;
            }
            thisInputObject.datalist = thisDatalistData;
            //if (Store.debug) { console.log(indent() + 'setWorkingInputValues: thisDatalistData:',thisDatalistData) };
            var thisDOMDatalist = document.getElementById(thisDatalist.name);
            //if ( thisInputValue && document.querySelector('option[value="' + thisInputValue + '"]') /*&& thisDatalistData*/ ) {
            if ( thisInputValue && thisDOMDatalist.querySelector('option[value="' + thisInputValue + '"]') /*&& thisDatalistData*/ ) {
                var thisDatalistOption = thisDOMDatalist.querySelector('option[value="' + thisInputValue + '"]'); 
                //if (Store.debug) { console.log(indent() + 'setWorkingInputValues: thisDatalistOption:', thisDatalistOption ) };
                var thisOptionIndex = thisDatalistOption.getAttribute('optionindex');
                //if (Store.debug) { console.log(indent() + 'setWorkingInputValues: thisDatalistOption:', thisOptionIndex, thisDatalistOption ) };
                thisInputObject.datalistOption = thisDatalistData[thisOptionIndex]; // the datalist result that matches the value.
            }
        }
        thisInputObject.value = thisInputValue;
        thisInputObject.inputValue = thisInputValue; //TODO: I think this was intended to be different than value... 
        
    }

    if (workingObject.inputs.length > 0) {

        for (var inputIndex = 0; inputIndex < workingObject.inputs.length; inputIndex++) {
            var makeInputValueObject = {};

            // Build the User Inputs array
            makeInputValueObject = workingObject.inputs[inputIndex];
            var thisInputDOMObject = document.getElementById(workingObject.inputs[inputIndex]['name']);
            // add datalist name to input object       SRP     
            makeInputValueObject.value = thisInputDOMObject.value;

            workingObject.inputValues.push(makeInputValueObject);

            workingObject.inputs[inputIndex]['inputValue'] = thisInputDOMObject.value || thisInputDOMObject.getAttribute('value');
        }
    }
    workingObject.inputValues = workingObject.inputs;
    workingObject.inputValuesHistory = JSON.parse(JSON.stringify(workingObject.inputValues))

    if (Store.debug) { console.log(indent() + 'setWorkingInputValues: returning.') };
    callStackDepth--;
}

function validateInput(workingObject, actionsArray) {
    // this function evaluates the input values based on the definition in the workflow step.  
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'validateInput: called.') };

    // get the working Object and return if not valid
    var workingObject = getWorkingObject(workingObject);
    if (!workingObject) {
        console.log(indent() + 'validateInput: no workingObject, returning.');
        callStackDepth--;
        return;
    }

    // get the searchRequest Object and return if not valid
    var searchRequest = getSearchObject(workingObject);

    var workingInputs = workingObject.inputs

    // get all the elements that need validation
    for (var inputIndex = 0; inputIndex < workingInputs.length; inputIndex++) {

        var thisInput = workingInputs[inputIndex];

        if (thisInput.validations) {
            for (var validationIndex = 0; validationIndex < thisInput.validations.length; validationIndex++) {

                var thisValidation = thisInput.validations[validationIndex];
                var thisErrorMessage = '';

                if (thisValidation.name == 'required') {
                    // Check on value vs input value in the process that populates the form data into inputs
                    // example: { name: 'required', errorMessage: 'xyz' }
                    if (!thisInput.inputValue) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText(thisInput.label) + getLanguageText(' is required. ');
                    }
                } else if (thisValidation.name == 'match') {
                    // example: { name: 'match', value: '123', errorMessage: 'xyz' }
                    var matchValue = thisValidation.value;
                    var matchValueDescription = thisValidation.errorSuffix || thisValidation.value;
                    if (thisInput.inputValue != matchValue) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText(thisInput.label) + getLanguageText(' input needs to be ') + getLanguageText(matchValueDescription) + '.';
                    }
                } else if (thisValidation.name == 'matchPattern') {
                    // example: { name: 'matchPattern', pattern: 'pattern', errorMessage: 'xyz' }
                    var matchPattern = thisValidation.pattern;
                    var matchPatternDescription = thisValidation.errorSuffix || thisValidation.pattern;
                    if (!thisInput.inputValue.match(matchPattern)) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText(thisInput.label) + getLanguageText(' input needs to match ') + getLanguageText(matchPatternDescription) + '.';
                    }
                } else if (thisValidation.name == 'matchToInputIndex') {
                    // this validation compares the value to the inputValue in an array 
                    // example: { name: 'matchToInputIndex', inputIndex: 3, errorMessage: 'xyz' }
                    var matchValue = workingInputs[thisValidation.inputIndex].inputValue; //workingInputs[thisValidation.inputIndex].value; 
                    if (thisInput.inputValue != matchValue) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText(thisInput.label) + ' input needs to be ' + matchValue + '.';
                    }
                } else if (thisValidation.name == 'matchValues') { 
                    // this validation compares input value to an array of values.  The array of value can be primitives or references. 
                    // because the properties or values might be confusing to the user, the solution developer can pass the validation description that is returned to the user. 
                    // validations: [['matchValues',[Store.currentWorkflowStep.searchResultsSummary.internalid, Store.currentWorkflowStep.searchResultsSummary.upccode ], 'Item or UPC']],
                    // example: { name: 'matchValues', values: [Store.currentWorkflowStep.searchResultsSummary.internalid, Store.currentWorkflowStep.searchResultsSummary.upccode ], errorMessage: 'xyz' }
                    var matchToValues = [];
                    for (var matchToValuesIndex = 0; matchToValuesIndex < thisValidation.values.length; matchToValuesIndex++) {
                        var thisValue = thisValidation.values[matchToValuesIndex];
                        if ( typeof thisValue === 'object' && thisValue.lateBind ) {
                            matchToValues.push( lateBind( thisValue.lateBind ) );
                        } else {
                            matchToValues.push(thisValue); 
                        }
                    }
                    var matchPatternDescription = thisValidation.errorSuffix || thisValidation.values;
                    if (matchToValues.indexOf(thisInput.inputValue) == -1 ) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || 
                            getLanguageText(thisInput.label) + getLanguageText(' input needs to match ') + getLanguageText(matchPatternDescription) + '.';
                    }
                } else if (thisValidation.name == 'numeric') { // || thisInput.typeAs == 'number') {
                    // example: { name: 'numeric', errorMessage: 'xyz' }
                    if (isNaN(thisInput.inputValue)) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || 
                            getLanguageText(thisInput.label) + ' input needs to be a number. ';
                    }
                } else if (thisValidation.name == 'integer') {
                    // example: { name: 'integer', errorMessage: 'xyz' }
                    if (parseInt(thisInput.inputValue, 10) != thisInput.inputValue) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || 
                            getLanguageText(thisInput.label) + ' input needs to be a whole number. ';
                    }
                } else if (thisValidation.name == 'max') { // || thisInput.max) {
                    // example: { name: 'max', max: '123', errorMessage: 'xyz' }
                    var matchValue = thisInput.max;
                    if (thisInput.inputValue > matchValue) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || 
                            getLanguageText(thisInput.label) + getLanguageText(' input needs to be no more than ') + matchValue + '.';
                    }
                } else if (thisValidation.name == 'min') { // || thisInput.min) {
                    // example: { name: 'min', min: '123', errorMessage: 'xyz' }
                    var matchValue = thisInput.min;
                    if (thisInput.inputValue < matchValue) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || 
                            getLanguageText(thisInput.label) + getLanguageText(' input needs to be at least ') + matchValue + '.';
                    }
                } else if (thisValidation.name == 'date') { // || thisInput.typeAs == 'date') {
                    // example: { name: 'date', errorMessage: 'xyz' }
                    if (!isValidDate(thisInput.inputValue)) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || 
                            getLanguageText(thisInput.label) + getLanguageText(' needs to be a valid date.');
                    }
                } else if (thisValidation.name == 'inDatalist') { // || thisInput.typeAs == 'inDatalist') {
                    // example: { name: 'inDatalist', propertyName: 'invOnHand', datalistName: 'inventories', errorMessage: 'xyz' }
                    try {
                        var datalistPropertyToMatch = thisValidation.propertyName; //|| thisInput.name; // Here we are obtaining the name of the column to match in the datalist
                        var currentDataList = thisValidation.datalistName || thisInput.datalistSource; // This is the current datalist
                        if (typeof datalistPropertyToMatch == "undefined") { // AB 20190523: In case that you didn't add any particular id to validate, it will take the search default column to match
                            datalistPropertyToMatch = Store.datalists[currentDataList].searchRequest.searchResultColumns.name['name']; //TODO I don't think this will ever find a column... searchResultColumns is an array. 
                        }
                        if (Store.debug) { console.log(indent() + 'validateInput: inDatalist: thisInput:', thisInput ) };
                        var datalistData = {};
                        if ( Store.datalists[currentDataList] && Store.datalists[currentDataList].searchRequest && Store.datalists[currentDataList].searchRequest.searchResultFlat ) { 
                            datalistData = Store.datalists[currentDataList].searchRequest.searchResultFlat;
                        } else {
                            datalistData = thisInput.datalist.data;
                        }
                        if (Store.debug) { console.log(indent() + 'validateInput: inDatalist: datalistData:', datalistData ) };
                        var indexInDatalist = getArrayValueByPropertyValue( datalistData, datalistPropertyToMatch, thisInput.inputValue, null );
                        if (Store.debug) { console.log(indent() + 'validateInput: inDatalist: thisInput.inputValue, datalistPropertyToMatch, currentDataList, indexInDatalist', 
                            thisInput.inputValue, datalistPropertyToMatch, currentDataList, indexInDatalist ) };
                        if (indexInDatalist < 0 || typeof indexInDatalist == "undefined") {
                            Store.current.successMessage = '';
                            thisErrorMessage = getLanguageText(thisValidation.errorMessage) || thisInput.label + ' input needs to be in the list.'
                        }
                    } catch (error) {
                        if (Store.debug) { console.log(indent() + 'validateInput: inDatalist error: ', error.message) };
                    }
                } else if (thisValidation.name == 'minimumInputLength') { 
                    // this is just checking that the user input contains at least the number of characters specified.
                    // example: { name: 'minimumInputLength', length: '123', errorMessage: 'xyz' }
                    var minimumLength = thisValidation.length; 
                    if (thisInput.inputValue && thisInput.inputValue.length < minimumLength ) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText(thisInput.label) + getLanguageText(' input needs to be at least ') + minimumLength + getLanguageText(' characters.');
                    }
                } else if (thisValidation.name == 'maximumInputLength') { 
                    // this is just checking that the user input contains more than the number of characters specified.
                    // example: { name: 'maximumInputLength', length: '123', errorMessage: 'xyz' }
                    var maximumLength = thisValidation.length; 
                    if (thisInput.inputValue && thisInput.inputValue.length > maximumLength ) {
                        Store.current.successMessage = '';
                        thisErrorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText(thisInput.label) + getLanguageText(' input needs to be more then ') + minimumLength + getLanguageText(' characters.');
                    }
                } else {
                    if (Store.debug) { console.log(indent() + 'validateInput: No validation rule defined for thisValidation.name: ', thisValidation.name) };
                }

                if (thisErrorMessage != '' && !Store.current.errorMessage) {
                    Store.current.errorMessage = getLanguageText('Sorry, ') + thisErrorMessage;
                } else if (thisErrorMessage != '') {
                    Store.current.errorMessage = Store.current.errorMessage + getLanguageText(' And,<br>') + thisErrorMessage;
                }

            }
        }
    }

    if (Store.debug) { console.log(indent() + 'validateInput: returning.') };
    callStackDepth--;
}

function validateForm(workingObject, actionsArray) {
    /* This function performs validations that span multiple objects on a page.  
        For example, assuring that at least one input is provided in a search form, or that at least one row is selected in in a multi-select table.
    */
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'validateForm: called.') };

    //try {
        if (Store.debug) { console.log(indent() + 'validateForm: workingObject.', JSON.parse(JSON.stringify( workingObject ) ) ) };
        //var workingObject = getWorkingObject( workingObject, searchRequest ) || workingObject;
        //if (Store.debug) { console.log(indent() + 'validateForm: workingObject.', JSON.parse(JSON.stringify( workingObject ) ) ) };
        var workingInputs = workingObject.inputs || [];

        for (var sectionIndex = 0; sectionIndex < workingObject.elements.length; sectionIndex++) {
            var thisSection = workingObject.elements[sectionIndex];
            var sectionValidations = thisSection.validations;

            if (sectionValidations && sectionValidations.length != 0) {
                for (var validationsIndex = 0; validationsIndex < sectionValidations.length; validationsIndex++) {
                    var thisValidation = sectionValidations[validationsIndex];

                    if (thisValidation.name == 'atLeastXRequired') {
                        /*
                        This validation assures that at inputs have been provided across multiple input fields.
                        Example of use:
                        elements: [
                                {
                                    type: 'section',
                                    name: 'printAfterReceiptLabelsSearch',
                                    class: 'workflowForm',
                                    validations: [
                                        { name: 'atLeastXRequired', minimumInputs: 2 , inputNames: ['itemid', 'inventoryNumber.inventorynumber', 'binnumber'], errorMessage: 'xyz' },
                                        { name: 'atLeastXRequired', minimumInputs: 1 , inputNames: ['accountId', 'binName', 'binNumber'] }
                                    ],
                                    elements: [
                                        { type: 'input', typeAs: 'search', name: 'itemid', label: 'Item ID' },
                                        ...
                                    ]
                                    ...
                                }
                        ...
                        The important part is this one:
                            The name property is going to be atLeastXRequired, to identify the call for this validation.
                            The minimumInputs property is how many of the fields must be populated.
                            The inputNames property is an array of inputs that must be are populated ('itemid' or 'inventoryNumber.inventorynumber' or 'binnumber') then the validation is passed else throw error
                            the errorMessage roperty (optional) is the string that will be displayed to a user if the validation fails
                                note: if omitted, the user will see a message with the list of fields that must be supplied. 
                            The second example, if at least 1 of the fields are populated ('itemid' or 'inventoryNumber.inventorynumber' or 'binnumber') then the validation is passed else throw error
                        */
                        //if (Store.debug) { console.log(indent() + 'validateForm: no atLeastXRequired validation, returning.') };

                        var inputNames = thisValidation.inputNames;
                        var countOfInputValues = 0;
                        var fieldsBeingValidated = [];

                        for (var i = 0; i < inputNames.length; i++) {
                            //if (Store.debug) { console.log(indent() + 'validateForm: inputNames[i]:'+inputNames[i]) };
                            var thisInputField = inputNames[i];
                            if (getArrayValueByPropertyValue(workingInputs, 'name', thisInputField, null) != -1 && getArrayValueByPropertyValue(workingInputs, 'name', thisInputField, 'value') != '') {
                                countOfInputValues++;
                            }
                            if(getArrayValueByPropertyValue(workingInputs, 'name', thisInputField, null) != -1){
                                fieldsBeingValidated.push(getArrayValueByPropertyValue(workingInputs, 'name', thisInputField, 'label'));
                            }
                            if (countOfInputValues >= thisValidation.minimumInputs) {
                                i = inputNames.length;
                            }
                        }
                        if (countOfInputValues < thisValidation.minimumInputs) {
                            Store.current.successMessage = '';
                            Store.current.errorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText('Sorry, at least ') +
                                thisValidation.minimumInputs + getLanguageText(' of the following fields must be provided: ') +
                                fieldsBeingValidated.join(", ") + '.';
                        } else {
                            Store.current.errorMessage = '';
                        }
                    } else if (thisValidation.name == 'atLeastXResultsSelected') {
                        /*
                        This validation assures that one or more results are selected on a multi-select table.
                        Example of use:
                            elements: [
                                {
                                    type: 'searchResultsTable',
                                    name: 'printAfterReceiptLabelsSearchResults',
                                    elements: [
                                    validations: [
                                        { name: 'atLeastXResultsSelected', minimumSelectedResults: 1, errorMessage: 'Sorry, you need ot select a search result' },
                                        { name: 'atLeastXResultsSelected', minimumSelectedResults: 2 }
                                    ],
                                    elements: [
                                        { type: 'input', typeAs: 'search', name: 'itemid', label: 'Item ID' },
                                        ...
                                    ]
                                    ...
                                }
                        ...
                        The important part is this one:
                            The name property is going to be atLeastXResultsSelected, to identify the call for this validation.
                            The minimumSelectedResults property is how many results must be selected (default 1).
                            //The selectorPropertyName is the property on each result that is true is selected (defaults to 'rowSelected')
                            the errorMessage property (optional) is the string that will be displayed to a user if the validation fails.
                                note: if omitted, the user will see a message with the required number of selected results. 
                            The second example, if at least 1 of the fields are populated ('itemid' or 'inventoryNumber.inventorynumber' or 'binnumber') then the validation is passed else throw error
                        */
                        
                        var selectedResults = workingObject.searchRequest.selectedResults;
                        var countOfSelectedResults = selectedResults.length;
                        var minimumSelectedResults = thisValidation.minimumSelectedResults || 1;
                        //var selectorPropertyName = thisValidation.selectorPropertyName || 'rowSelected'
                        
                        // for each result, check in selectorPropertyName is true.  
                        if (countOfSelectedResults < minimumSelectedResults) {
                            Store.current.successMessage = '';
                            Store.current.errorMessage = getLanguageText(thisValidation.errorMessage) || getLanguageText('Sorry, at least ') +
                                minimumSelectedResults + getLanguageText(' result(s) must be selected.');
                        } else {
                            Store.current.errorMessage = '';
                        }
                    } else if (thisValidation.name == 'custom') {
                        if (Store.debug) { console.log(indent() + 'validateForm: custom form validation not implemented yet: ', thisValidation.name) };
                        // TODO implement { name: 'custom', functionName: 'testThis', parameters: ['x','y',...], errorMessage: 'xyz' }
                    } else {
                        if (Store.debug) { console.log(indent() + 'validateForm: no form validation matching: ', thisValidation.name) };
                    }
                }
            }
        }
    //} catch (error) {
    //    if (Store.debug) { console.log(indent() + "validateForm: There was an error: " + error); }
    //}

    if (Store.debug) { console.log(indent() + 'validateForm: returning.') };
    callStackDepth--;
}

function dateToUsEn(dateArray) {
    // note: adding the noon time resolves the time zone issue.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'dateToUsEn: called.') };

    if (Store.debug) { console.log(indent() + 'dateToUsEn: date, is date:', dateArray[0], typeof dateArray[0] ) };
    var inputDate = dateArray[0];
    var formattedDate = inputDate.split('-')[1] + '/' + inputDate.split('-')[2] + '/' + inputDate.split('-')[0];

    if (Store.debug) { console.log(indent() + 'dateToUsEn: inputDate, formattedDate:', inputDate, formattedDate) };
    callStackDepth--; 
    return [formattedDate];
}

function dateTimeToUsEn(date) {
    // note: adding the noon time resolves the time zone issue.
    if (Store.debug) { console.log(indent() + 'dateToUsEn: date, dateToUsEn: ', date + ' 12:00:00 ', (new Date(date)).toLocaleDateString('en-US')) };
    return (new Date(date + ' 12:00:00')).toLocaleDateString('en-US');
}

function dateStringToDateNS(browserInput) {
    // this flips the format of the browser date picker ('yyyy-mm-dd') to NetSuite string 'mm/dd/yyyy'.
    if (Store.debug) { console.log(indent() + 'dateStringToDateNS: browserInput: ', browserInput ) };
    var browserInputDate = new Date(browserInput);
    var d = new Date();
    var curr_date = d.getDate();
    var curr_month = d.getMonth() + 1; //Months are zero based
    var curr_year = d.getFullYear();
    console.log(curr_date + "-" + curr_month + "-" + curr_year);
    //var dateNS = ((browserInputDate.getMonth() > 8) ? (browserInputDate.getMonth() + 1) : ('0' + (browserInputDate.getMonth() + 1))) + '/' + ((browserInputDate.getDate() > 9) ? browserInputDate.getDate() : ('0' + browserInputDate.getDate())) + '/' + browserInputDate.getFullYear();    
    var dateNS = browserInput.split('-')[1] + '/'+browserInput.split('-')[2] + '/'+browserInput.split('-')[0]
    if (Store.debug) { console.log(indent() + 'dateStringToDateNS: browserInput, dateToNS: ', browserInput, dateNS ) };
    return (dateNS);
}

function validateRowsSelected() {
    // this function validates that there are rows selected before allowing following actions to progress
    // it sets the error message to "Please select rows before tapping "
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'validateRowsSelected: called.') };

    if (!Store.currentWorkflowStep.searchRequest.selectedResults || Store.currentWorkflowStep.searchRequest.selectedResults < 1) {
        Store.current.errorMessage = 'Please select one or more rows before tapping "' + Store.current.clickedElement.value + '".'
    }

    if (Store.debug) { console.log(indent() + 'validateRowsSelected: returning.') };
    callStackDepth--; 
}




// REST Functions 
function setAuthHeader(xhr) {
    // this helper function conditionally adds the authorization header to the xhr request if the the client has provided "local" authorization credentials (e.g. for debugging)
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'setAuthHeader: called.') };

    var authObj = Store.current.temporary.test
    if (authObj.nlauth_email) {
        xhr.setRequestHeader("Authorization", "NLAuth nlauth_account=" + authObj.nlauth_account +
            ", nlauth_email=" + authObj.nlauth_email +
            ", nlauth_signature=" + authObj.nlauth_signature +
            ", nlauth_role=" + authObj.nlauth_role);
    }

    if (Store.debug) { console.log(indent() + 'setAuthHeader: returning.') };
    callStackDepth--;
}




// debug functions 
function indent() {
    if (Store.environment.thisIsIE == true) {
        return ''
    }
    var indentString = ' '.repeat(callStackDepth * 3)
    return indentString
}

function toggleDebug() {
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'toggleDebug: called.') };
    Store.debug = !Store.debug;
    if (Store.debug) { console.log(indent() + 'toggleDebug: Console Logging is now enabled.') };
    if (Store.debug) { console.log(indent() + 'toggleDebug: returning.') };
    callStackDepth--;
}




// Utility Functions 
function downloadAsFile( fileContent, fileName, fileType ) {
    // this function puts a string in a txt file and downloads it to the downloads folder.
    callStackDepth++;
    if (Store.debug) {console.log(indent() + 'downloadAsFile: called.')};
    
    // get the work area settings 
    var workArea = Store.LPTransferData.workAreas.current;
    //if (Store.debug) {console.log(indent() + 'downloadAsFile: workArea', workArea )};

    // write the file if enabled for workArea.
    if ( workArea.downloadAsFile ) {
        if (Store.debug) {console.log(indent() + 'downloadAsFile: writing file.' )};
        var fileContentString = fileContent || '';
        var fileNameString = fileName || 'download_file.txt';
        var fileTypeString = fileType || 'text/plain';
        var fileObj = new Blob([fileContentString], {type: fileTypeString });
        var fileElement = document.createElement('a');
        //a.innerHTML = 'download'
        fileElement.href= URL.createObjectURL(fileObj);
        fileElement.download = fileNameString;
        fileElement.click();
        URL.revokeObjectURL(fileElement.href);
    }

    if (Store.debug) {console.log(indent() + 'downloadAsFile: returning.')};
    callStackDepth--;
}

function getArrayValueByPropertyValue(inputArray, findPropertyName, findPropertyValue, returnPropertyName) {
    callStackDepth++;
    //if (Store.debug) { console.log(indent() + 'getArrayValueByPropertyValue: called.') };

    var thisInputArray = inputArray;

    //if (Store.debug) {
    //    console.log(indent() + 'getArrayValueByPropertyValue: inputArray,findPropertyName,findPropertyValue,returnPropertyName:',
    //        inputArray, findPropertyName, findPropertyValue, returnPropertyName)
    //};

    for (var arrayIndex = 0; arrayIndex < thisInputArray.length; arrayIndex++) {
        //if (Store.debug) { console.log(indent() + 'getArrayValueByPropertyValue: arrayIndex, findPropertyName, findPropertyValue: ', arrayIndex, findPropertyName, findPropertyValue) };
        if (thisInputArray[arrayIndex][findPropertyName] === findPropertyValue) {
            //if (Store.debug) {
            //    console.log(indent() +
            //        'getArrayValueByPropertyValue: thisInputArray[arrayIndex][findPropertyName], thisInputArray[arrayIndex][returnPropertyName]',
            //        thisInputArray[arrayIndex][findPropertyName], thisInputArray[arrayIndex][returnPropertyName])
            //};
            if (returnPropertyName && returnPropertyName === -1) {
                //if (Store.debug) { console.log(indent() + 'getArrayValueByPropertyValue: returning value: ', returnPropertyName, thisInputArray[arrayIndex][returnPropertyName]) };
                callStackDepth--;
                return thisInputArray[arrayIndex];
            } else if (returnPropertyName) {
                //if (Store.debug) { console.log(indent() + 'getArrayValueByPropertyValue: returning value: ', returnPropertyName, thisInputArray[arrayIndex][returnPropertyName]) };
                callStackDepth--;
                return thisInputArray[arrayIndex][returnPropertyName];
            } else {
                //if (Store.debug) { console.log(indent() + 'getArrayValueByPropertyValue: returning arrayIndex: ', arrayIndex) };
                callStackDepth--;
                return arrayIndex;
            }
        }
    }


    //if (Store.debug) { console.log(indent() + 'getArrayValueByPropertyValue: returning not found') };
    callStackDepth--;
    // not found
    return -1;
}

function getReferenceByPropertyValue(sourceObject, propertyName, propertyValue) {
    // this function iterates over an object and returns the reference to the first occurrence of the property value in the object.
    callStackDepth++;
    //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: called.') }; //, sourceObject
    //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: called with sourceObject, propertyName, propertyValue', propertyName, propertyValue) }; //, sourceObject
    //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: typeof sourceObject', typeof sourceObject) };

    var startTimeMs = Date.now();
    var foundObject = null

    if (Array.isArray(sourceObject)) {
        for (var sourceArrayIndex = 0; sourceArrayIndex < sourceObject.length; sourceArrayIndex++) {
            var thisSourceArrayEntry = sourceObject[sourceArrayIndex];
            if (typeof thisSourceArrayEntry == 'object') {
                foundObject = getReferenceByPropertyValue(thisSourceArrayEntry, propertyName, propertyValue);
                if (!!foundObject) {
                    if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: Found!!! Duration: ', Date.now()-startTimeMs, thisObjectKeyName, thisObjectKeyType) };
                    callStackDepth--;
                    return foundObject;
                }
            }
        }
    } else if (typeof sourceObject === 'object') {
        for (var objectKeyIndex = 0; objectKeyIndex < Object.keys(sourceObject).length; objectKeyIndex++) {
            
            var thisObjectKeyName = Object.keys(sourceObject)[objectKeyIndex];
            var thisObjectKeyValue = sourceObject[thisObjectKeyName];
            var thisObjectKeyType = typeof thisObjectKeyValue;
            //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: in for thisObjectKeyName, thisObjectKeyType, thisObjectKeyValue', thisObjectKeyName, thisObjectKeyType, thisObjectKeyValue) };
            
            if (thisObjectKeyName === propertyName) {
                //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: in name') };
                if (thisObjectKeyValue === propertyValue) {
                    if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: Found!!! Duration: ', Date.now()-startTimeMs, thisObjectKeyName, thisObjectKeyType) };
                    callStackDepth--;
                    return sourceObject;
                } else if (thisObjectKeyValue === 'object' && !!thisObjectKeyValue ) {
                    //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: in name + object thisObjectKeyValue', thisObjectKeyName, thisObjectKeyType) };
                    foundObject = getReferenceByPropertyValue(thisObjectKeyValue, propertyName, propertyValue);
                    if (!!foundObject) {
                        if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: Found!!! Duration: ', Date.now()-startTimeMs, thisObjectKeyName, thisObjectKeyType) };
                        callStackDepth--;
                        return foundObject;
                        }
                }
            } else if (thisObjectKeyType == 'object' && !!thisObjectKeyValue ) {
                //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: in object thisObjectKeyValue', thisObjectKeyName, thisObjectKeyType) };
                foundObject = getReferenceByPropertyValue(thisObjectKeyValue, propertyName, propertyValue);
                if (!!foundObject) {
                    if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: Found!!! Duration: ', Date.now()-startTimeMs, thisObjectKeyName, thisObjectKeyType) };
                    callStackDepth--;
                    return foundObject;
                }
        } else if (!!thisObjectKeyValue && thisObjectKeyType != 'string' && thisObjectKeyType != 'number' && thisObjectKeyType != 'boolean') {
                if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: in else', thisObjectKeyName, thisObjectKeyType) };
                //getReferenceByPropertyValue(thisObjectKeyValue, propertyName, propertyValue);
            }
        }
    }
    callStackDepth--;
    //if (Store.debug) { console.log(indent() + 'getReferenceByPropertyValue: returning not found') };
}

function unique(obj) {
    //expects an array of objects 
    var uniques = [];
    var stringify = {};
    for (var i = 0; i < obj.length; i++) {
        // get the object property names
        var keys = Object.keys(obj[i]);
        keys.sort(function (a, b) { return a - b });
        var str = '';
        for (var j = 0; j < keys.length; j++) {
            str += JSON.stringify(keys[j]);
            str += JSON.stringify(obj[i][keys[j]]);
        }
        if (!stringify.hasOwnProperty(str)) {
            uniques.push(obj[i]);
            stringify[str] = true;
        }
    }
    return uniques;
}

function getNested(theObject, path, separator) {
    try {
        separator = separator || '.';

        return path.
            replace('[', separator).replace(']', '').
            split(separator).
            reduce(
                function (obj, property) {
                    return obj[property];
                }, theObject
            );

    } catch (err) {
        return undefined;
    }
}

function isValidDate(dateString) {
    // Validates that the input string is a valid date formatted as "mm/dd/yyyy"
    // First check for the pattern
    if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateString)) {
        return false;
    }

    // Parse the date parts to integers
    var parts = dateString.split("/");
    var day = parseInt(parts[1], 10);
    var month = parseInt(parts[0], 10);
    var year = parseInt(parts[2], 10);

    // Check the ranges of month and year
    if (year < 1000 || year > 3000 || month == 0 || month > 12) {
        return false;
    }

    var monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    // Adjust for leap years
    if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
        monthLength[1] = 29;

    // Check the range of the day
    return day > 0 && day <= monthLength[month - 1];
};

function summarizeArray(sourceArray, targetObject, summarizationArray) {
    // this function summarizes an array into a summarization object
    // the summarization array includes: 
    // this assumes an array of objects (e.g. [{x:y, a:b},{x:y1, a:b1}])
    //  [ [ <array property name>: <summarization type> ], [ <array property name 2>: <summarization type 2> ],...]
    //  e.g. - [{'quantityCommitted': 'sum'}, {'itemid': 'first'}, {'itemid': 'count'}, {'itemid': 'countUnique'}]
    //  { targetProperty: 'orderNumber', sourceProperty:'GROUP(transactionId)', summarizationType: 'first'}
    //
    // !!!! NOTE: this function needs to be refactored... it needs to iterate through the source array once and perform the summarizations.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'summarizeArray: called.') };

    //if (Store.debug) { console.log(indent() + 'summarizeArray: sourceArray, targetObject, summarizationArray', JSON.parse(JSON.stringify(sourceArray)), sourceArray, JSON.parse(JSON.stringify(targetObject)), targetObject, JSON.parse(JSON.stringify(summarizationArray)), summarizationArray) };


    var sourceArrayLength = sourceArray.length;
    //if (Store.debug) { console.log(indent() + 'summarizeArray: sourceArrayLength:' + sourceArrayLength) };
    var summarizationArrayLength = summarizationArray.length;
    //if (Store.debug) { console.log(indent() + 'summarizeArray: summarizationArrayLength:' + summarizationArrayLength) };

    if (sourceArrayLength > 0 && summarizationArrayLength > 0) {
        // iterate over the summarizations and process each
        for (var i = 0; i < summarizationArrayLength; i++) {

            var thisSummarization = summarizationArray[i];
            //if (Store.debug) { console.log(indent(), thisSummarization) };
            var targetProperty = thisSummarization.targetProperty;
            var sourceProperty = thisSummarization.sourceProperty;
            var summarizationType = thisSummarization.summarizationType;

            //if (Store.debug) { console.log(indent() + 'summarizeArray: sourceProperty:' + sourceProperty + ' summarizationType:' + summarizationType) };

            if (summarizationType == 'sum') {
                var totalSum = 0;
                var thisAddend = 0;
                for (var j = 0; j < sourceArrayLength; j++) {
                    var sourceObject = sourceArray[j];
                    //console.log(indent(), typeof sourceObject[sourceProperty]);
                    if (typeof sourceObject[sourceProperty] == 'number') {
                        thisAddend = sourceObject[sourceProperty];
                    } else {
                        thisAddend = Number(sourceObject[sourceProperty]);
                    }
                    if (sourceObject[sourceProperty]) {
                        totalSum += thisAddend;
                    }
                }
                targetObject[targetProperty] = totalSum;
            } else if (summarizationType == 'count') {
                var totalCount = 0;
                for (var j = 0; j < sourceArrayLength; j++) {
                    var sourceObject = sourceArray[j];
                    if (sourceObject[sourceProperty]) {
                        totalCount++;
                    }
                }
                targetObject[targetProperty] = sourceArrayLength;
            } else if (summarizationType == 'first') {
                for (var j = 0; j < sourceArrayLength; j++) {
                    var sourceObject = sourceArray[j];
                    //if (Store.debug) { console.log(indent() + 'summarizeArray: first called: ', JSON.parse(JSON.stringify(sourceObject))) };
                    if (sourceObject[sourceProperty]) {
                        targetObject[targetProperty] = sourceObject[sourceProperty];
                        j = sourceArrayLength;
                    }
                }
            } else if (summarizationType == 'countUnique') {
                var uniqueArray = [];
                var countUniques = 0;
                for (var j = 0; j < sourceArrayLength; j++) {
                    //if (Store.debug) { console.log(indent(), uniqueArray) };
                    var sourceObject = sourceArray[j];
                    if (sourceObject[sourceProperty] && !uniqueArray[sourceObject[sourceProperty]]) {
                        uniqueArray[sourceObject[sourceProperty]] = sourceObject[sourceProperty];
                        countUniques++;
                    }
                }
                targetObject[targetProperty] = countUniques;
            } else if (summarizationType == 'min') {
                if (!targetObject[targetProperty]) {
                    targetObject[targetProperty] = sourceObject[sourceProperty];
                }
                var minValue = '';
                for (var j = 0; j < sourceArrayLength; j++) {
                    var sourceObject = sourceArray[j];
                    //console.log('min',sourceObject[sourceProperty]);
                    if (sourceObject[sourceProperty] && sourceObject[sourceProperty] < minValue) {
                        minValue = sourceObject[sourceProperty];
                        targetObject[targetProperty] = sourceObject[sourceProperty];
                    }
                }
            } else if (summarizationType == 'max') {
                if (!targetObject[targetProperty]) {
                    targetObject[targetProperty] = sourceObject[sourceProperty];
                }
                var maxValue = '';
                for (var j = 0; j < sourceArrayLength; j++) {
                    var sourceObject = sourceArray[j];
                    //console.log('max',sourceObject[sourceProperty]);
                    if (sourceObject[sourceProperty] && sourceObject[sourceProperty] > maxValue) {
                        maxValue = sourceObject[sourceProperty];
                        targetObject[targetProperty] = sourceObject[sourceProperty];
                    }
                }
            } else if (summarizationType == 'listUnique') {
                if (!targetObject[targetProperty]) {
                    targetObject[targetProperty] = [];
                } else {
                    targetObject[targetProperty].length = 0
                }
                for (var j = 0; j < sourceArrayLength; j++) {
                    //if (Store.debug) { console.log(indent(), uniqueListArray) };
                    var sourceObject = sourceArray[j];
                    if (Store.debug) { console.log(indent() + 'summarizeArray: targetObject[targetProperty], sourceObject[sourceProperty]' + targetObject[targetProperty], sourceObject[sourceProperty]) };
                    if ( sourceObject[sourceProperty] && targetObject[targetProperty].indexOf(sourceObject[sourceProperty]) == -1 ) {
                        targetObject[targetProperty].push(sourceObject[sourceProperty]);
                        if (Store.debug) { console.log(indent() + 'summarizeArray: targetObject[targetProperty], sourceObject[sourceProperty]' + targetObject[targetProperty], sourceObject[sourceProperty]) };
                    }
                }
                //targetObject[targetProperty] = uniqueListArray;
            } else if (summarizationType == 'listUniqueString') {
                // this builds a concatenated string of all the unique values.
                //if (!targetObject[targetProperty]) {
                targetObject[targetProperty] = '';
                //}
                //var uniqueListArray = [];
                //if (!targetObject[targetProperty]) {
                //    targetObject[targetProperty] = [];
                //}
                var workingUniqueArray = []
                for (var j = 0; j < sourceArrayLength; j++) {
                    //if (Store.debug) { console.log(indent(), uniqueListArray) };
                    var sourceObject = sourceArray[j];
                    //console.log('listUnique',sourceObject[sourceProperty]);
                    //if (sourceObject[sourceProperty] && uniqueListArray.indexOf([sourceObject[sourceProperty]]) > -1 ) {
                    //console.log(targetObject[targetProperty].indexOf(sourceObject[sourceProperty]));
                    if (sourceObject[sourceProperty] && workingUniqueArray.indexOf(sourceObject[sourceProperty]) < 0) {
                        workingUniqueArray.push(sourceObject[sourceProperty]);
                        if (workingUniqueArray.length > 1) {
                            targetObject[targetProperty] = targetObject[targetProperty] + ', ';
                        }
                        targetObject[targetProperty] = targetObject[targetProperty] + sourceObject[sourceProperty];
                        //uniqueListArray.push(sourceObject[sourceProperty]);
                        //console.log(targetObject[targetProperty]);
                    }
                }
                //targetObject[targetProperty] = uniqueListArray;
            }
        }
    }

    if (Store.debug) { console.log(indent() + 'summarizeArray: returning.') };
    callStackDepth--;
}

function summarizeAndGroupArray(sourceArray, targetArray, summarizationArray) {
    callStackDepth++;
    //Created variables For Calculating the Average // who added these?
    var totalLength = 0;
    var totalValue = 0;
    var average = 0;
    //Created variables For Calculating the Average // who added these? 
    //iterates over the source array 
    sourceArray.forEach(function (e) {
        var key = summarizationArray.targetGroups.map(function (k) { return e[k]; }).join('|'); // used for grouping the results 
        //creating the summarize array object 
        object = {};
        for (var i in summarizationArray.targetSummaries) {
            var summaryObj = summarizationArray.targetSummaries[i]
            var summaryType = summaryObj.summaryType
            var sourceProperty = summaryObj.sourceProperty
            if (summaryType === 'count' || summaryType === 'sum' || summaryType === 'average') {
                object[summaryObj.targetProperty] = 0;
            }
            else {
                object[summaryObj.targetProperty] = '';
            }
        }
        //Push only the unique objects available in array 
        if (!this[key]) {
            this[key] = object;
            targetArray.push(this[key]);
        }
        //iterates over the summarizationArray array and checking the summary type
        for (var i in summarizationArray.targetSummaries) {
            var summaryObj = summarizationArray.targetSummaries[i]
            var summaryType = summaryObj.summaryType
            var sourceProperty = summaryObj.sourceProperty;
            if (summaryType === 'first') {
                this[key][summaryObj.targetProperty] = e[sourceProperty];
            }
            if (summaryType === 'count') {
                this[key][summaryObj.targetProperty] += 1;
            }
            if (summaryType === 'sum') {
                this[key][summaryObj.targetProperty] += Number(e[sourceProperty]);
            }
            if (summaryType === 'average') {
                totalLength += 1
                totalValue += Number(e[sourceProperty]);

                average = (totalValue / totalLength);
                console.log(average);
                this[key][summaryObj.targetProperty] = average;
            }


        }


    }, {});

}

function summarizeResultsAll() {
    // This function summarizes all the searchRequest.searchResultFlat into 
    // searchRequest.searchResultSummarized using the definition in searchRequest.summarizationArray. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'summarizeResultsAll: called.') };

    // define the search request to use
    if (typeof Store.currentWorkflowStep.searchRequest != 'undefined') {
        var thisSearchRequest = Store.currentWorkflowStep.searchRequest; // TODO: @AB or SRP this needs to find the search request based on the section.
        if (Store.debug) { console.log(indent() + 'summarizeResultsAll: thisSearchRequest:',JSON.parse(JSON.stringify(thisSearchRequest))) };
    } else {
        if (Store.debug) { console.log(indent() + 'summarizeResultsAll: Store.currentWorkflowStep:',JSON.parse(JSON.stringify(Store.currentWorkflowStep))) };
        if (Store.debug) { console.log(indent() + 'summarizeResultsAll: returning. No searchResults.') };
        callStackDepth--;
        return;
    }

    // if the summarizationArrayAll exists, continue, else return
    if (typeof thisSearchRequest.summarizationArrayAll != 'undefined') {
        var thisSummarizationArray = thisSearchRequest.summarizationArrayAll; 
    } else if (typeof thisSearchRequest.summarizationArray != 'undefined') {
        var thisSummarizationArray = thisSearchRequest.summarizationArray; 
    } else {
        if (Store.debug) { console.log(indent() + 'summarizeResultsAll: returning. No summarization Array.') };
        callStackDepth--;
        return;
    }

    // define the search results to use
    var theseSearchResults = thisSearchRequest.searchResultFlat; 

    // define the results objet
    if (typeof thisSearchRequest.searchResultSummarizedAll == 'undefined') {
        thisSearchRequest.searchResultSummarizedAll = {};
    } 

    thisSummarizationArray.forEach( function (row){
        thisSearchRequest.searchResultSummarizedAll[row.targetProperty] = [row.initializationValue] || '&nbsp;'
    })
    
    var theseSearchResultsSummarized = thisSearchRequest.searchResultSummarizedAll; 

    // now summarize the selected results.
    if (theseSearchResults.length != 0) {
        summarizeArray(theseSearchResults, theseSearchResultsSummarized, thisSummarizationArray);
    }
    
    if (Store.debug) { console.log(indent() + 'summarizeResultsAll: returning.') };
    callStackDepth--;
}

function summarizeResultsAllBySearchRequest(searchRequest) {
    // This function summarizes all the searchRequest.searchResultFlat into 
    // searchRequest.searchResultSummarized using the definition in searchRequest.summarizationArray. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'summarizeResultsAllBySearchRequest: called.') };

    // define the search request to use
    if (typeof searchRequest != 'undefined') {
        var thisSearchRequest = searchRequest; // TODO: @AB or SRP this needs to find the search request based on the section.
        if (Store.debug) { console.log(indent() + 'summarizeResultsAllBySearchRequest: thisSearchRequest:',JSON.parse(JSON.stringify(thisSearchRequest))) };
    } else {
        if (Store.debug) { console.log(indent() + 'summarizeResultsAllBySearchRequest: Store.currentWorkflowStep:',JSON.parse(JSON.stringify(Store.currentWorkflowStep))) };
        if (Store.debug) { console.log(indent() + 'summarizeResultsAllBySearchRequest: returning. No searchResults.') };
        callStackDepth--;
        return;
    }

    // if the summarizationArrayAll exists, continue, else return
    if (typeof thisSearchRequest.summarizationArrayAll != 'undefined') {
        var thisSummarizationArray = thisSearchRequest.summarizationArrayAll; 
    } else if (typeof thisSearchRequest.summarizationArray != 'undefined') {
        var thisSummarizationArray = thisSearchRequest.summarizationArray; 
    } else {
        if (Store.debug) { console.log(indent() + 'summarizeResultsAllBySearchRequest: returning. No summarization Array.') };
        callStackDepth--;
        return;
    }

    // define the search results to use
    var theseSearchResults = thisSearchRequest.searchResultFlat; 

    // define the results objet
    if (typeof thisSearchRequest.searchResultSummarizedAll == 'undefined') {
        thisSearchRequest.searchResultSummarizedAll = {};
    } 

    thisSummarizationArray.forEach( function (row){
        thisSearchRequest.searchResultSummarizedAll[row.targetProperty] = [row.initializationValue] || '&nbsp;'
    })
    
    var theseSearchResultsSummarized = thisSearchRequest.searchResultSummarizedAll; 

    // now summarize the selected results.
    if (theseSearchResults.length != 0) {
        summarizeArray(theseSearchResults, theseSearchResultsSummarized, thisSummarizationArray);
    }
    
    if (Store.debug) { console.log(indent() + 'summarizeResultsAllBySearchRequest: returning.') };
    callStackDepth--;
}

function summarizeResultsSelected() {
    // This function summarizes all the searchRequest.searchResultFlat into 
    // searchRequest.searchResultSummarized using the definition in searchRequest.summarizationArray. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'summarizeResultsSelected: called.') };

    // define the search request to use
    if (typeof Store.currentWorkflowStep.searchRequest != 'undefined') {
        var thisSearchRequest = Store.currentWorkflowStep.searchRequest; // TODO: @AB or SRP this needs to find the search request based on the section.
        if (Store.debug) { console.log(indent() + 'summarizeResultsSelected: thisSearchRequest:',JSON.parse(JSON.stringify(thisSearchRequest))) };
    } else {
        if (Store.debug) { console.log(indent() + 'summarizeResultsSelected: Store.currentWorkflowStep:',JSON.parse(JSON.stringify(Store.currentWorkflowStep))) };
        if (Store.debug) { console.log(indent() + 'summarizeResultsSelected: returning. No searchResults.') };
        callStackDepth--;
        return;
    }

    // if the summarizationArrayAll exists, continue, else return
    if (typeof thisSearchRequest.summarizationArraySelected != 'undefined') {
        var thisSummarizationArray = thisSearchRequest.summarizationArraySelected; 
    } else if (typeof thisSearchRequest.summarizationArray != 'undefined') {
        var thisSummarizationArray = thisSearchRequest.summarizationArray; 
    } else {
        if (Store.debug) { console.log(indent() + 'summarizeResultsSelected: returning. No summarization Array.') };
        callStackDepth--;
        return;
    }

    // define the search results to use
    var theseSearchResults = thisSearchRequest.searchResultFlat; 

    // define the results objet.  
    if (typeof thisSearchRequest.searchResultSummarizedSelected == 'undefined') {
        thisSearchRequest.searchResultSummarizedSelected = {};
        thisSummarizationArray.forEach( function (row){
            thisSearchRequest.searchResultSummarizedSelected[row.targetProperty] = [row.initializationValue] || '&nbsp;'
        })
    } 
    var theseSearchResultsSummarized = thisSearchRequest.searchResultSummarizedSelected; 

    // now summarize the selected results.
    if (theseSearchResults.length != 0) {
        summarizeArray(theseSearchResults, theseSearchResultsSummarized, thisSummarizationArray);
    }
    
    if (Store.debug) { console.log(indent() + 'summarizeResultsSelected: returning.') };
    callStackDepth--;
}

function sortCompare(sortArray) {
    // this function returns the function that returns 1, -1, or 0 for the JS sort algorithm. 
    // the sort array is an array of objects that define 1-n sort levels. 
    // e.g. [{propertyName:'type',sortDirection:'desc'},{propertyName:'name',sortDirection:'asc'}]
    // TODO: Add support for numeric and exact comparison
    // callStackDepth++;
    //if (Store.debug) { console.log(indent() + 'sortCompare: called.') };
    //if (Store.debug) { console.log(indent() + 'sortCompare: sortArray.', JSON.parse(JSON.stringify(sortArray))) };

    return function compare(a, b) {
        //callStackDepth++;
        //if (Store.debug) { console.log(indent() + 'sortCompare compare sortArray:', JSON.parse(JSON.stringify(sortArray))) };
        for (var sortIndex = 0; sortIndex < sortArray.length; sortIndex++) {
            var propertyName = sortArray[sortIndex].propertyName || '';
            //console.log('propertyName', propertyName);
            var sortDirection = sortArray[sortIndex].sortDirection || '';
            //console.log('sortDirection', sortDirection);
            
            var aProperty = a[propertyName] || '';
            if (typeof aProperty == 'string') {
                aProperty = aProperty.toLowerCase();
            } 

            var bProperty = b[propertyName] || '';
            if (typeof bProperty == 'string') {
                bProperty = bProperty.toLowerCase();
            } 

            //console.log('aProperty',JSON.stringify(a) +', '+ a[propertyName] + ', '+typeof a[propertyName]);
            //console.log('bProperty',JSON.stringify(b) +', '+ b[propertyName] + ', '+typeof b[propertyName]);
            if (aProperty < bProperty) {
            //if (aProperty.toLowerCase() < bProperty.toLowerCase()) {
            //if (( typeof aProperty == 'string' &&  typeof bProperty == 'string' &&  (aProperty.toLowerCase() < bProperty.toLowerCase())) ||  (typeof aProperty == 'number' &&  typeof bProperty == 'number' &&  (aProperty < bProperty))) {
                sortIndex = sortArray.length + 1
                if ( sortDirection.toLowerCase() == 'desc') {
                    return 1;
                } else {
                    return -1;
                }
            } else if ( aProperty > bProperty ) {
            //} else if ((typeof aProperty == 'string' && typeof bProperty == 'string' && (aProperty.toLowerCase() > bProperty.toLowerCase())) || (typeof aProperty == 'number' && typeof bProperty == 'number' && (aProperty > bProperty))) {
                sortIndex = sortArray.length + 1
                if (sortDirection.toLowerCase() == 'desc') {
                    return -1;
                } else {
                    return 1;
                }
            }
        }
        return 0;
    };
    //if (Store.debug) { console.log(indent() + 'sortCompare: returning.') };
    //callStackDepth--;
}

function addToArray(targetArray, valuesArray, method) {
    // this function is used to add values from one array to another array
    // methods: If the value is found in the targetArray... 
    //  moveValueToEnd: the function removes the value and pushes the value to array.
    //  moveValueToStart: the function removes the value and unshift the value to array.
    //  skipValue: the function leaves the targetArray as is.
    //  error: return an error if the value is found.  
    //  addValueToEnd: this method pushes each value in the source to the end of the target array.
    //  addValueToStart: this method unshift each value in the source to the start of the target array.
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'addToArray: called.') };

    if (!targetArray) {
        if (Store.debug) { console.log(indent() + 'addToArray: targetArray is required.') };
        return;
    }
    if (!valuesArray) {
        if (Store.debug) { console.log(indent() + 'addToArray: valuesArray is required.') };
        return;
    }
    var method = method || 'moveValueToEnd'

    // process each value in the valuesArray
    for (var currentArrayIndex = 0; currentArrayIndex < valuesArray.length; currentArrayIndex++) {
        var thisValue = valuesArray[currentArrayIndex];
        var foundIndex = targetArray.indexOf(thisValue);
        //if (Store.debug) { console.log(indent() + 'addToArray: targetArray:', targetArray) };
        //if (Store.debug) { console.log(indent() + 'addToArray: thisValue, foundIndex:', thisValue, foundIndex) };
        // perform the appropriate action if found
        if (method == 'moveValueToEnd') {
            if (foundIndex >= 0) {
                targetArray.splice(foundIndex, 1);
            }
            targetArray.push(thisValue);
        } else if (method == 'moveValueToStart') {
            if (foundIndex >= 0) {
                targetArray.splice(foundIndex, 1);
            }
            targetArray.unshift(thisValue);
        } else if (method == 'skip') {
            if (foundIndex >= 0) {
                // nothing to see here... move along
            }
        } else if (method == 'error') {
            if (foundIndex >= 0) {
                if (Store.debug) { console.log(indent() + 'addToArray: returning error.') };
                callStackDepth--;
                return ('That was in the array');
            }
        } else if (method == 'addValueToEnd') {
            targetArray.push(thisValue);
        } else if (method == 'addValueToStart') {
            targetArray.unshift(thisValue);
        }
    }

    if (Store.debug) { console.log(indent() + 'addToArray: returning.') };
    callStackDepth--;
}

function updateObjectProperties(targetObject, newPropertyValuesObject) {
    // this function is used to update an objects properties from another objects properties. 
    //  where the newObject property names match, the new object's property overrides the original object's properties.  
    //  original object properties that are not in the new object are unaffected. 
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'updateObjectProperties: called.') };

    // validate the newObject exists and is an object
    if (typeof newPropertyValuesObject !== 'object') {
        if (Store.debug) { console.log(indent() + 'updateObjectProperties: returning: No newPropertyValuesObject.') };
        callStackDepth--;
        return;
    }

    // validate the object to update 
    if (typeof targetObject !== 'object') {
        if (Store.debug) { console.log(indent() + 'updateObjectProperties: returning: targetObject is not an object.') };
        callStackDepth--;
        return;
    }

    // if the target object exists and is an object
    var newPropertyValuesObjectKeys = Object.keys(newPropertyValuesObject);
    var targetObjectKeys = Object.keys(targetObject);

    // remove any properties that are not properties in the new object
    /* SRP 20210326 re-commented this block
    for ( var targetObjectKeysIndex = 0; targetObjectKeysIndex < targetObjectKeys.length; targetObjectKeysIndex++ ) {
        if (newPropertyValuesObjectKeys.indexOf(targetObjectKeys[targetObjectKeysIndex]) < 0 ) {
           delete targetObject[targetObjectKeys[targetObjectKeysIndex]]; 
        }
    }*/
    

    // iterate over the keys of the newPropertyValuesObject
    for (var newPropertyValuesObjectKeysIndex = 0; newPropertyValuesObjectKeysIndex < newPropertyValuesObjectKeys.length; newPropertyValuesObjectKeysIndex++) {
        var workingKey = newPropertyValuesObjectKeys[newPropertyValuesObjectKeysIndex];
        // set the key in the targetObject
        targetObject[workingKey] = newPropertyValuesObject[workingKey];
    }

    if (Store.debug) { console.log(indent() + 'updateObjectProperties: returning.') };
    callStackDepth--;
}

function getReferenceFromPath(path) { //},workingPathReference) {
    // this function returns a reference to a property in the Store from a string.
    // the Array accepts the full path or the path within the Store (e.g. 'Store.datalists.bins' or 'datalists.bins').
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'getReferenceFromPath: called.') };

    if (typeof path === 'object') {
        if (Store.debug) { console.log(indent() + 'getReferenceFromPath: return. The path is an object. ') };
        callStackDepth--;
        return path;
    }

    // SRP 20210326 - added the replace so that the sting can reference an array entry (e.g. somObject.someChileArray[0]).
    // SRP 20210326 - added the replace so that the sting can reference a property name with special characters (e.g. somObject.someChileArray["fish.bones"]).
    // SRP 20210327 - added regex replace to handle property/object/array names with a . inside []... the ~ is replaced in the for loop.
    var dotInSquareBrackets = /(\[[",']\w*[^\.])(\.)([^\.]\w*[",']\])/;
    var workingPath = path.replace(dotInSquareBrackets, '$1' + '~' + '$3').replaceAll('[','.').replaceAll('"','').replaceAll("'","").replaceAll(']','')
    
    var workingPathArray = workingPath.split('.');
    //if (Store.debug) { console.log(indent() + 'getReferenceFromPath: workingPath, workingPathArray: ', workingPath, workingPathArray ) };

    var workingPathReference = {}

    if (workingPathArray[0] != 'Store') {
        workingPathReference = Store;
    } else {
        workingPathReference = window[workingPathArray[0]];
        workingPathArray.shift();
    }
    //if (Store.debug) { console.log(indent() + 'getReferenceFromPath: workingPathReference: ', workingPathReference ) };

    var workingPathReferenceString = '';

    for (var workingPathArrayIndex = 0; workingPathArrayIndex < workingPathArray.length; workingPathArrayIndex++) {
        var thisPropertyName = workingPathArray[workingPathArrayIndex].replaceAll('~','.')
        workingPathReferenceString = workingPathReferenceString + '.' + thisPropertyName;
        workingPathReference = workingPathReference[thisPropertyName];
        //if (Store.debug) { console.log(indent() + 'getReferenceFromPath: workingPathReferenceString: ', workingPathReferenceString ) };
        //if (Store.debug) { console.log(indent() + 'getReferenceFromPath: workingPathReference: ', workingPathReference ) };
    }

    if (Store.debug) { console.log(indent() + 'getReferenceFromPath: returning.') };
    callStackDepth--;

    return workingPathReference;
}

function replaceArrayContents(targetArray, newArray) {
    // this function will replace the contents of the array without loosing the reference to the array
    var workingArray = targetArray;
    var workingNewArray = newArray || [];
    // remove existing entries
    workingArray.length = 0;
    // add the new contents
    if (workingNewArray.length > 0) {
        workingArray.push.apply(workingArray, workingNewArray);
    }
} 

function makeFilteredArray(sourceArray, targetArray, filterArray) {
    // this function creates a filtered array of objects from another array of object based on a filter array
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'makeFilteredArray: called.') };

    if (!sourceArray || !targetArray || !filterArray) {
        if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.  Missing parameters: ', sourceArray, targetArray, filterArray) };
        callStackDepth--;
        return;
    }

    // validate filter array
    if (typeof filterArray === 'object') {
        var workingFilterArray = filterArray;
    } else if (typeof filterArray === 'string') {
        var workingFilterArray = getReferenceFromPath(filterArray);
        if (workingFilterArray == 'undefined') {
            if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.  the filterArray could not be found. ', filterArray) };
            callStackDepth--;
            return;
        }
    } else {
        if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.  the filterArray needs to be an Object or a string. ', filterArray) };
        callStackDepth--;
        return;
    }

    // validate source array
    if (typeof sourceArray === 'object') {
        var workingSourceArray = sourceArray;
    } else if (typeof sourceArray === 'string') {
        var workingSourceArray = getReferenceFromPath(sourceArray);
        if (Store.debug) { console.log(indent() + 'makeFilteredArray: workingSourceArray ', workingSourceArray) };
        if (workingSourceArray == 'undefined') {
            if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.  the sourceArray could not be found. ', sourceArray) };
            callStackDepth--;
            return;
        }
    } else {
        if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.  the sourceArray needs to be an Object or a string. ', sourceArray) };
        callStackDepth--;
        return;
    }

    // validate target array
    console.log('targetArray before', targetArray);

    if (typeof targetArray === 'object') {
        var workingTargetArray = targetArray;
    } else if (typeof targetArray === 'string') {
        var workingTargetArray = getReferenceFromPath(targetArray);
        if (Store.debug) { console.log(indent() + 'makeFilteredArray: workingTargetArray ', workingTargetArray) };
        if (workingTargetArray == 'undefined') {
            if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.  the targetArray could not be found. ', targetArray) };
            callStackDepth--;
            return;
        }
    } else {
        if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.  the targetArray needs to be an Object or a string. ', targetArray) };
        callStackDepth--;
        return;
    }

    // prepare target array 
    // populate target array 

    /*var theseElements = Store.workflowSteps[Store.current.workflowStep].elements;
    //Checking which columns are selected for Filter 
    for (var thisElementIndex in theseElements[0].elements) {
        var thisElement = theseElements[0].elements[thisElementIndex];
        if (thisElement.filter) {
            filterKeyValues.push(thisElement.name);
        }
        if (Store.debug) { console.log(filterKeyValues, 'filterKeyValues'); }
    }*/

    // use Regular Expression 
    var filterKeyValues = [['custrecord_wmsse_bin_loc_type', 'stage'], ['custrecord_wmsse_bin_loc_type.text', 'stage'], ['custrecord_wmsse_bin_stg_direction', 'out']];
    //var filterKeyValues = ['custrecord_wmsse_bin_loc_type','custrecord_wmsse_bin_loc_type.text','custrecord_wmsse_bin_stg_direction'];
    //var searchProperty = 'custrecord_wmsse_bin_loc_type';
    var searchValue = 'stage'; //document.getElementById("globalSearchInput").value.toLowerCase().trim();
    var results = workingTargetArray; //[]; // 
    var objects = workingSourceArray; // Store.workflowSteps[Store.current.workflowStep].searchRequest['searchResultFlat']
    /*for (var i = 0; i < objects.length; i++) { 
        console.log('object:',objects[i]);
        for (keyvalue in objects[i]) { // looping through the properties in the object.
            //console.log('keyvalue',keyvalue);
            for (var key in filterKeyValues) { // looping through the property names to look at
                //console.log('filterKeyValues[key]',filterKeyValues[key]);
                if (keyvalue == filterKeyValues[key]) { 
                    console.log('objects[i][keyvalue]',objects[i][keyvalue]);
                    var value = objects[i][keyvalue].toLowerCase();
                    if (value.indexOf(searchValue) != -1) {
                        results.push(objects[i]);
                    }
                }
            }
        }
    }*/
    //var stopMe = 0;
    //var keysLength = filterKeyValues.length;
    for (var i = 0; i < objects.length; i++) {
        console.log('object:', objects[i]);
        for (var key in filterKeyValues) { // looping through the property names to look at
            console.log('filterKeyValues[key]', filterKeyValues[key]);
            console.log('filterKeyValues[key][0], filterKeyValues[key][1]', filterKeyValues[key][0], filterKeyValues[key][1]);
            console.log('objects[i][filterKeyValues[key][0]]', objects[i][filterKeyValues[key][0]]);
            //if (objects[i][searchProperty].toLowerCase() == searchValue) { 
            if (objects[i][filterKeyValues[key][0]] && objects[i][filterKeyValues[key][0]].toLowerCase() == searchValue) {
                //console.log('objects[i][searchProperty].toLowerCase()',objects[i][searchProperty].toLowerCase() ); 
                console.log('objects[i][filterKeyValues[key][0]].toLowerCase()', objects[i][filterKeyValues[key][0]].toLowerCase());
                results.push(objects[i]);
                break;
            }
        }
        //if (stopMe >= 300) {
        //    console.log('hit the limit');
        //    return;
        //}
        //stopMe++;
    }

    //Store.workflowSteps[Store.current.workflowStep].searchRequest['searchResultFilter'] = results;
    if (Store.debug) { console.log(indent() + 'makeFilteredArray: workingTargetArray', JSON.parse(JSON.stringify(workingSourceArray))) };

    //workingTargetArray.push(workingSourceArray.slice()[0]);

    console.log('targetArray after', targetArray);

    if (Store.debug) { console.log(indent() + 'makeFilteredArray: returning.') };
    callStackDepth--;
}

/* function returnChildObjects( sourceArray, childObjectPropertyName, comparisonOperator, childObjectPropertyValue ) {
    // this function iterates over an array and returns matching child objects
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'returnChildObjects: called.') };

    // verify the source object is an array
    if ( Array.isArray( sourceArray ) ) {

        //iterate children
        for ( var childIndex in sourceArray ) {
            var thisChild = sourceArray[childIndex];

            if ( valueCompare( thisChild[childObjectPropertyName] )
        }

    }

    if (Store.debug) { console.log(indent() + 'returnChildObjects: returning.') };
    callStackDepth--;
} */


// Conditional Functions
    //
    // where
    //      this function is used to return some value if a set of conditions are true, else return a different value.
    //      this calls whereCompare with one node 
    // whereCompare 
    //        this takes input in the NS Filter array syntax (field, operator and 0-n values) in the NS Syntax and returns true or false 
    // whereReturn 
    //makeFilteredArray
    //isIt
    //isIt2
    //evaluateBooleanArray

    // 
    // Revise to new conditional behavior
    //
    // Any property that will support conditional or late bound values will accept a consistent conditional input format and functions to process he condition
    // Input formats 
    // { conditionFunction: 'someFunctionNameHere' }
    // { conditionFunction: 'someFunctionNameHere', trueValue: 'some value', falseValue: 'some other value' }
    // { conditionFunction: 'someFunctionNameHere(someInputParameters)' }
    // { conditionFunction: 'someFunctionNameHere(someInputParameters)', trueValue: 'some value', falseValue: 'some other value' }
    // { conditionEval: 'if (!a) return 'fish' }
    // { conditionEval: 'if (!a) return 'fish', trueValue: 'some value', falseValue: 'some other value' }
    // { conditionFilterArray: [['someVariableOrProperty', '===', 'fish' ], 'and', ['someOtherVariableOrProperty', '!=', 'Bob' ]] }
    // { conditionFilterArray: [['someVariableOrProperty', '===', 'fish' ], 'and', ['someOtherVariableOrProperty', '!=', 'Bob' ]], trueValue: 'some value', falseValue: 'some other value' }
    // { lateBind: 'Store.current.workflowStep' }
// 
function valueCompare(value1, operator, value2) {
    // this helper function compares two values with an operator to allow for dynamic comparisons. 
    // this will now lateBind the values if they are an object with a lateBind property e.g. { lateBind: 'Store.current.clickedSearchResult.zone'}

    //if (Store.debug) { console.log(indent() + 'valueCompare: called with value1, operator, value2:', value1, operator, value2 ) };

    if ( typeof value1 === 'object' && value1.lateBind ) { var value1Value = lateBind( value1 ); } else { var value1Value = value1; }
    if ( typeof value2 === 'object' && value2.lateBind ) { var value2Value = lateBind( value2 ); } else { var value2Value = value2; }
    
    switch (operator) {
      case '>':   return value1Value > value2Value;
      case '<':   return value1Value < value2Value;
      case '>=':  return value1Value >= value2Value;
      case '<=':  return value1Value <= value2Value;
      case '==':  return value1Value == value2Value;
      case '!=':  return value1Value != value2Value;
      case '===': return value1Value === value2Value;
      case '!==': return value1Value !== value2Value;
    }
}

function where(whereInput) {
    // this function is used to return some value if a set of conditions are true, else return a different value.
    // this uses the NetSuite SuiteScript 2.0 search filter syntax... 
    // this function is late bound
    // [['property name','comparison','value'],'optional and or or',['property name','comparison','value']...]

    var whereArray = whereInput;

    var whereArrayLength = whereArray.length;

    if (typeof whereArray[0] != 'object') return;

    for (var whereArrayIndex; whereArrayIndex < whereArrayLength; whereArrayIndex++) {
        var thisCondition = whereArray[whereArrayIndex];

        whereCompare(thisCondition);
    }
}


function testWhereCompare(thisComparison) {
    // just testing the whereCompare function
    if (Array.isArray(thisComparison) ) {
        console.log(whereCompare(thisComparison));
    } else {
        console.log(whereCompare(['a','==','a']));
        console.log(whereCompare(['a','==','b']));
    }
    return 'Done!';
} 

function whereCompare(thisComparison) {
    // this function performs the the granular where comparison 
    // SRP 20190505: added function 
    // 'value1', 'comparison', 'value2'
    callStackDepth++;
    if (Store.debug) { console.log(indent() + 'whereCompare: called with:',thisComparison) };

    if (Array.isArray(thisComparison) && thisComparison.length > 0) {

        var thisArrayLength = thisComparison.length;
        var inverseResult = false;
        var thisProperty = null;
        var thisOperator = null;
        var thisConnector = null;
        var theseValues = [];
        var thisValue = '';

        for (var thisComparisonComponentIndex = 0; thisComparisonComponentIndex < thisComparison.length; thisComparisonComponentIndex++ ) {

            var thisComparisonComponent = thisComparison[thisComparisonComponentIndex];
            
            // handle special nodes
            if ( typeof thisComparisonComponent === 'object' && !Array.isArray(thisComparisonComponent) ) {
                thisComparisonComponent = evaluateConditionalObject(thisComparisonComponent);
            } else if ( Array.isArray(thisComparisonComponent) ) {
                thisComparisonComponent = whereCompare( thisComparisonComponent ); 
            } else {
                // that's it for now.
            }

            console.log(thisComparisonComponentIndex, thisComparisonComponent);

            // set the formula components
            if ( thisComparisonComponentIndex == 0 ) {
                if ( thisComparisonComponent.toLowerCase === 'not' ) {
                    inverseResult = true; 
                } else {
                    thisProperty = thisComparisonComponent;
                }
            } else if ( thisComparisonComponentIndex == 1 ) {
                if ( thisComparisonComponent == 'and' ) {
                    thisConnector = ' && ' // thisComparisonComponent;
                    console.log('thisConnector',thisConnector);
                } else if ( thisComparisonComponent == 'or' ) {
                    thisConnector = ' || ' // thisComparisonComponent;
                    console.log('thisConnector',thisConnector);
                } else if ( thisComparisonComponentIndex == 1 ) {
                    thisOperator = thisComparisonComponent;
                    console.log('thisOperator',thisOperator);
                }
            } else { 
                theseValues.push( thisComparisonComponent );
            } 
        }

        // evaluate the result
        //var comparisonExpression = '"' + thisProperty + '" ' + thisOperator + ' "' + theseValues[0] + '"'; 
        console.log(thisProperty + thisConnector + thisOperator + theseValues[0]);
        
        var thisResult = null;
        if (thisOperator) {
            thisResult =  eval(thisProperty + thisOperator + theseValues[0]); // eval(comparisonExpression);
        }
        console.log(thisResult);

        if ( typeof thisResult == 'boolean' ) {
            if (inverseResult) {
                return !thisResult;
            } else {
                return thisResult;
            }
        } else {
            return thisResult;
        }

    } else {
        if (Store.debug) { console.log(indent() + 'whereCompare: input was not an array.') };    
    }

    callStackDepth--;
    if (Store.debug) { console.log(indent() + 'whereCompare: returning.') };
}

function whereReturn(compareArray, trueReturn, falseReturn) {
    // this function is used to return a value if a set of conditions are true 
    // this uses the NetSuite SuiteScript 2.0 search filter syntax... 
    // [['property name','comparison','value'],'optional and or or',['property name','comparison','value']...]

    var whereTrueFalse = whereCompare(compareArray);

    if (whereTrueFalse) {
        return trueReturn;
    } else {
        return falseReturn
    }

}

function isIt(checkObject, conditionArray) {
    // this function looks an an object and returns true or false based on the condition array
    console.log('isIt( checkObject, conditionArray )', checkObject, conditionArray);

    var workingConditionArray = conditionArray;
    var boolArray = []; // the holds the success or failure of each evaluation. 

    for (var conditionPartIndex = 0; conditionPartIndex < workingConditionArray.length; conditionPartIndex++) {
        var conditionPart = workingConditionArray[conditionPartIndex];
        console.log('conditionPart', conditionPart);
        if (typeof conditionPart == 'object') {
            if (conditionPart.length == 3 && typeof conditionPart[0] == 'string' && typeof conditionPart[1] == 'string' && typeof conditionPart[2] == 'string') {
                boolArray.push(isIt2(checkObject, conditionPart));
            } else {
                boolArray.push(isIt(checkObject, conditionPart));
            }
        } else {
            boolArray.push(conditionPart);
        }
        console.log('boolArray', boolArray);
    }

    var result = evaluateBooleanArray(boolArray);
    console.log('result', result);
    return result;
}

function isIt2(checkObject, conditionsArray) {
    // this checks an object based on property, condition, value
    console.log('isIt2( checkObject, conditionsArray )', checkObject, conditionsArray);

    var property = conditionsArray[0];
    var condition = conditionsArray[1];
    var value = conditionsArray[2];
    var propertyValue = checkObject[property];
    var comparisonResult = -1;

    if (typeof value === 'string') {
        value = value.toLowerCase();
    }
    if (typeof propertyValue === 'string') {
        propertyValue = propertyValue.toLowerCase();
    }

    if (propertyValue == 'undefined') {
        return -1;
    }

    if (condition == 'is' || condition == '=' || condition == '==' || condition == '===') {
        comparisonResult = (propertyValue == value);
    } else if (condition == 'isNot' || condition == '!=' || condition == '!==' || condition == '!===') {
        comparisonResult = (propertyValue != value);
    } else if (condition == 'contains' || condition == 'like' || condition == '~') {
        comparisonResult = (propertyValue.indexOf(value) > -1);
    }

    return comparisonResult;
}

function evaluateBooleanArray(boolArray) {
    // Process the booleanArray to determine result and returns true or false. 
    // the input boolean array can contain true, false, not, and or or... the not must precede a boolean 
    // example: [true,'and','not',false,'or',true]
    var computedBoolean = -1;
    var thisElement;
    var thisComp;

    //for (var boolArrayIndex = 0; boolArrayIndex < boolArray.length; boolArrayIndex++) {
    while (boolArray.length > 0) {

        thisElement = boolArray.shift();

        if (typeof thisElement === 'string' && (thisElement.toLowerCase() === 'and' || thisElement.toLowerCase() === 'or')) {
            //console.log('and/or ', thisElement);
            thisComp = thisElement.toLowerCase();
            thisElement = boolArray.shift();
        }
        if (typeof thisElement === 'string' && thisElement.toLowerCase() === 'not') {
            //console.log('not', thisElement);
            thisElement = !boolArray.shift();
        }

        //console.log('computedBoolean, thisComp, thisElement ', computedBoolean, thisComp, thisElement )

        if (computedBoolean == -1) {
            //console.log('computedBoolean == -1');
            computedBoolean = thisElement;
        } else {
            if (thisComp === 'and') {
                //console.log('thisComp === and');
                computedBoolean = (computedBoolean && thisElement);
            } else if (thisComp === 'or') {
                //console.log('thisComp === or');
                computedBoolean = (computedBoolean || thisElement);
            }
        }
        //console.log('computedBoolean', computedBoolean);
    }
    return computedBoolean;
}






// pending testing

updateObjectProperties(Store.operators, {
    // this object holds the mapping from user input search operators to the corresponding NetSuite operator by data type. 
    // "SuiteScript 1.0 Search Operators" : "https://nlcorp.app.netsuite.com/app/help/helpcenter.nl?fid=section_N3005172.html&whence="
    // the use of this requires:
    // - foundation after 20191117. 
    // - this is temporarily using a new search preparation function (prepareSearchRequest2) until this is fully tested.  after that prepareSearchRequest will be removed and prepareSearchRequest2 renamed to prepareSearchRequest.
    // - a datatype to be defined as a default and/or on the search form element (e.g. "{ type: 'input', typeAs: 'search', name: "created", label: "Date Created", dataType: 'date' },").
    ':': {
        name: 'Between',
        inputCount: 2,
        inputSplitString: ' : ',
        checkbox: '',
        date: 'within',
        file: '',
        multiselect: '',
        number: 'between',
        related: '',
        string: ''
    },
    '-:': {
        name: 'Not Between',
        inputCount: 2,
        inputSplitString: ' : ',
        checkbox: '',
        date: 'notwithin',
        file: '',
        multiselect: '',
        number: 'notbetween',
        related: '',
        string: ''
    },
    '~': {
        name: 'Contains',
        inputCount: 1,
        checkbox: '',
        date: '',
        file: '',
        multiselect: '',
        number: '',
        related: '',
        string: 'contains'
    },
    '-~': {
        name: 'Does Not Contain',
        inputCount: 1,
        checkbox: '',
        date: '',
        file: '',
        multiselect: '',
        number: '',
        related: '',
        string: 'doesnotcontain'
    },
    '~,~': {
        name: 'Any Of',
        inputCount: -1,
        inputSplitString: ' , ',
        checkbox: '',
        date: '',
        file: 'anyof',
        multiselect: 'anyof',
        number: '',
        related: 'anyof',
        string: ''
    },
    '-~,~': {
        name: 'None Of',
        inputCount: -1,
        inputSplitString: ' , ',
        checkbox: '',
        date: '',
        file: 'noneof',
        multiselect: 'noneof',
        number: '',
        related: 'noneof',
        string: ''
    },
    '<': {
        name: 'Less Than',
        inputCount: 1,
        checkbox: '',
        date: 'before',
        file: '',
        multiselect: '',
        number: 'lessthan',
        related: '',
        string: ''
    },
    '-<': {
        name: 'Not Less Than',
        inputCount: 1,
        checkbox: '',
        date: 'notbefore',
        file: '',
        multiselect: '',
        number: 'notlessthan',
        related: '',
        string: ''
    },
    '<=': {
        name: 'Less Than or Equal To',
        inputCount: 1,
        checkbox: '',
        date: 'onorbefore',
        file: '',
        multiselect: '',
        number: 'lessthanorequalto',
        related: '',
        string: ''
    },
    '-<=': {
        name: 'Not Less Than or Equal To',
        inputCount: 1,
        checkbox: '',
        date: 'notonorbefore',
        file: '',
        multiselect: '',
        number: 'notlessthanorequalto',
        related: '',
        string: ''
    },
    '=': {
        name: 'Equal To',
        inputCount: 1,
        checkbox: 'equalto', /*There is a chance that there is a nuance between "equalto" and "is" that will cause this to need to be revised...*/
        date: 'on',
        file: '',
        multiselect: '',
        number: 'equalto',
        related: '',
        string: 'is' /*There is a chance that there is a nuance between "equalto" and "is" that will cause this to need to be revised...*/
    },
    '-=': {
        name: 'Not Equal To',
        inputCount: 1,
        checkbox: '',
        date: 'noton',
        file: '',
        multiselect: '',
        number: 'notequalto',
        related: '',
        string: 'isnot'
    },
    '=*': {
        name: 'Starts With',
        inputCount: 1,
        checkbox: '',
        date: '',
        file: '',
        multiselect: '',
        number: '',
        related: '',
        string: 'startswith'
    },
    '-=*': {
        name: 'Does Not Start With',
        inputCount: 1,
        checkbox: '',
        date: '',
        file: '',
        multiselect: '',
        number: '',
        related: '',
        string: 'doesnotstartwith'
    },
    '=,=': {
        name: 'All Of',
        inputCount: -1,
        inputSplitString: ' , ',
        checkbox: '',
        date: '',
        file: '',
        multiselect: 'allof',
        number: '',
        related: '',
        string: ''
    },
    '-=,=': {
        name: 'Not All Of',
        inputCount: -1,
        inputSplitString: ' , ',
        checkbox: '',
        date: '',
        file: '',
        multiselect: 'notallof',
        number: '',
        related: '',
        string: ''
    },
    '=~': {
        name: 'Has Keywords',
        inputCount: 1,
        inputSplitString: ' , ',
        checkbox: '',
        date: '',
        file: '',
        multiselect: '',
        number: '',
        related: '',
        string: 'haskeywords'
    },
    '""': {
        name: 'Empty',
        inputCount: 0,
        checkbox: '',
        date: 'isempty',
        file: '',
        multiselect: '',
        number: 'isempty',
        related: '',
        string: 'isempty'
    },
    '-""': {
        name: 'Not Empty',
        inputCount: 0,
        checkbox: '',
        date: 'isnotempty',
        file: '',
        multiselect: '',
        number: 'isnotempty', /* there may be some work between any and isnotempty. */
        related: '',
        string: 'isnotempty'
    },
    '>': {
        name: 'Greater Than',
        inputCount: 1,
        checkbox: '',
        date: 'after',
        file: '',
        multiselect: '',
        number: 'greaterthan',
        related: '',
        string: ''
    },
    '->': {
        name: 'Not Greater Than',
        inputCount: 1,
        checkbox: '',
        date: 'notafter',
        file: '',
        multiselect: '',
        number: 'notgreaterthan',
        related: '',
        string: ''
    },
    '>=': {
        name: 'Greater Than or Equal To',
        inputCount: 1,
        checkbox: '',
        date: 'onorafter',
        file: '',
        multiselect: '',
        number: 'greaterthanorequalto',
        related: '',
        string: ''
    },
    '->=': { 
            name: 'Not Greater Than or Equal To', 
            inputCount: 1, 
            checkbox: '', 
            date: 'notonorafter', 
            file: '', 
            multiselect: '', 
            number: 'notgreaterthanorequalto', 
            related: '', 
            string: '' 
        }
} );

// this is an example of setting multiple reference names for one operator.
Store.operators['!='] = Store.operators['-=']; 
Store.operators['!>='] = Store.operators['->=']; 
Store.operators['!>'] = Store.operators['->']; 
Store.operators['!""'] = Store.operators['-""']; 
Store.operators['allof'] = Store.operators['=,=']; 
Store.operators['!allof'] = Store.operators['-=,=']; 
Store.operators['anyof'] = Store.operators['~,~']; 
Store.operators['!anyof'] = Store.operators['-~,~']; 
Store.operators['begins'] = Store.operators['=*']; 
Store.operators['!begins'] = Store.operators['-=*']; 


