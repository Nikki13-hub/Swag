/**
 * Copyright (c) 1998-2020 Oracle-NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 * 
 * * Version    Date            Author           		Remarks
 *   1.00       May 28, 2020	Alexander Bordad		Initial Version
 *
 * 
 */

/**
*@NApiVersion 2.x
*@NScriptType Suitelet
*/

define(['N/runtime', 'N/file'],

	function(NS_Runtime, NS_File){

		var _ComputedType_Computed 	= 'COMPUTED';
		var _ComputedType_Recompute = 'RECOMPUTE';
		var _ComputedType_Optimal 	= 'OPTIMAL';
		
		var _Error_Message = '';


		function onRequest(context){

			var stLogTitle = 'onRequest';

			try{

				var startTime = new Date();

				var stResponse = initialCFProcess();
				log.debug(stLogTitle, stResponse);

				
				log.debug(stLogTitle, 'sec: ' + (new Date() - startTime) / 1000 + ' rem units: ' + NS_Runtime.getCurrentScript().getRemainingUsage() + '/1000.');

				context.response.write(stResponse);

			}catch(e){
				log.error(stLogTitle, e.message);
			}
		}

		function initialCFProcess(){
			var stLogTitle = 'initialCFProcess';
			try{
				var scriptObj = NS_Runtime.getCurrentScript();
				var manifestFileParam = scriptObj.getParameter('custscript_wmsts_cf_manifestfile');
				var manifestFileID = null;
				var manifestFilePath = null;
				log.debug(stLogTitle,"manifestFileParam: "+manifestFileParam);
				manifestFileID = parseInt(manifestFileParam);
				if(isNaN(manifestFileID)){
					manifestFilePath = manifestFileParam;
				}
				// Try to load file by path
				var fileLoaded = null;
				try{
					if(manifestFilePath != null){
						fileLoaded = NS_File.load({id: manifestFilePath});
					}else{
						fileLoaded = NS_File.load({id: manifestFileID});
					}
					var fileLoadedContent 	= fileLoaded.getContents();
					var fileLoadedJSON 		= null;
					try{
						fileLoadedJSON 		= JSON.parse(fileLoadedContent);
						return computeFile(fileLoadedJSON);
					}catch(error){
						throw {message: 'File is not in JSON format'};
					}
				}catch(error){
					log.error(stLogTitle, error);
					throw {message: 'Manifest file path or id not found'};
				}
			}catch(e){
				log.error(stLogTitle, e.message);
				throw e;
			}
		}

		// returns compute content
		function computeFile(paramObj){

			var stLogTitle = 'computeFile';

			try{
				log.debug(stLogTitle, 'paramObj ' + JSON.stringify(paramObj));

				var blValidParams = validateParameters(paramObj);
				if(!blValidParams){
					return _Error_Message;
				}

				var stPathTemplateFile 	= paramObj.templateFilePath;
				var stPathComputedFile 	= paramObj.computedFilePath;
				var stComputeType 		= paramObj.computeType;
				var stComputeTypeUpper  = stComputeType.toUpperCase();
				var fileTemplate 		= null;
				log.debug(stLogTitle, 'stComputeTypeUpper ' + stComputeTypeUpper);

				if(isEmpty(stPathComputedFile)){

					fileTemplate = loadFile(stPathTemplateFile);
					if(isEmpty(fileTemplate)){
						_Error_Message = 'The Template File must exist.';
						return _Error_Message;	
					}					
					
					var indexOfFolder = stPathTemplateFile.lastIndexOf("/");
					var suiteSpaFolder = stPathTemplateFile.substring(0, indexOfFolder);
					var stDeploymentId = NS_Runtime.getCurrentScript().deploymentId;
					var indexOfExtension = stPathTemplateFile.lastIndexOf(".");
					var stExtension = stPathTemplateFile.substring(indexOfExtension, stPathTemplateFile.length);
					
					stPathComputedFile = suiteSpaFolder + '/' + stDeploymentId + stExtension;

					copyFile(fileTemplate, stDeploymentId + stExtension);
				}
				log.debug(stLogTitle, 'stPathComputedFile ' + stPathComputedFile);
				
				var fileComputed = loadFile(stPathComputedFile);
				if(isEmpty(fileComputed)){
					_Error_Message = 'The Computed File must exist. ' + stPathComputedFile;
					return _Error_Message;	
				}				

				var stComputedFileId 		= fileComputed.id;
				var stComputedFileContent 	= fileComputed.getContents();
				log.debug(stLogTitle, 'stComputedFileId ' + stComputedFileId);

				// COMPUTED
				if(stComputeTypeUpper == _ComputedType_Computed){
					return stComputedFileContent;
				}

				// OPTIMAL
				else if(stComputeTypeUpper == _ComputedType_Optimal){
					if(!isEmpty(stComputedFileId)){
						return stComputedFileContent;
					}
				}

				//RECOMPUTE
				var stConfiguration = paramObj.configuration;
				if(isEmpty(stConfiguration)){
					return stComputedFileContent;
				}
				
				if(isEmpty(fileTemplate)){
					fileTemplate = loadFile(stPathTemplateFile);
				}
				
				if(isEmpty(fileTemplate)){
					_Error_Message = 'The Template File must exist.';
					return _Error_Message;	
				}

				var stTemplateFileId 		= fileTemplate.id;
				var stTemplateFileContent 	= fileTemplate.getContents();
				log.debug(stLogTitle, 'stTemplateFileId ' + stTemplateFileId);			

				var objConfiguration = stConfiguration;
				
				//	Substitutions
				log.debug(stLogTitle, 'begin substitutions');

				//log.debug(stLogTitle, objConfiguration);
				var stNewContent = stTemplateFileContent;

				var substitutions = objConfiguration.substitutions;
				var files = objConfiguration.files;

				log.debug("substitutions", substitutions);
				log.debug("files", files);

				for(key in substitutions){
					log.debug("Replacing "+key, substitutions[key]);

					var strkey = "{"+key+"}";

					stNewContent = stNewContent.replace(new RegExp(strkey, 'g'), substitutions[key]);
				}

				//	Replace File URLs
				log.debug(stLogTitle, 'begin file replacing');

				var arrFiles = objConfiguration.files;
				var intFilesLength = arrFiles.length;

				for(var i = 0; i < intFilesLength; i++){

					var stReference 	= arrFiles[i].reference;
					var stFile 			= arrFiles[i].file;
					//log.debug(stLogTitle, 'stReference ' + stReference + ' stFile ' + stFile);

					var fileObj = loadFile(stFile);
					if(isEmpty(fileObj)){
						log.error(stLogTitle, 'file not found ' + stFile);
						continue;
					}

					var stFileURL = fileObj.url;
					//log.debug(stLogTitle, 'stFileURL ' +  stFileURL);


					stReference = "{"+stReference+"}";
					stNewContent = stNewContent.replace(new RegExp(stReference, 'g'), stFileURL);
				}

				log.debug(stLogTitle, 'stNewContent 3:' + stNewContent);

				updateFile(fileComputed, stNewContent);
				

				log.debug('stNewContent', stNewContent);
				return stNewContent;

			}catch(e){
				log.error(stLogTitle, e);
				return e.message;
			}
		}

		// Validate Script Parameters
		function validateParameters(scriptParams){

			var stLogTitle = 'validateParameters';

			var blValidParams = false;
			
			try{

				var stPathTemplateFile 	= scriptParams.templateFilePath;
				var stPathComputedFile 	= scriptParams.computedFilePath;
				var stComputeType 		= scriptParams.computeType;
				var stComputeTypeUpper  = stComputeType.toUpperCase();
				
				// Compute Type	    		
				if(stComputeTypeUpper != _ComputedType_Computed && stComputeTypeUpper != _ComputedType_Recompute && stComputeTypeUpper != _ComputedType_Optimal){
					_Error_Message = 'Unknown computed type ' + stComputeType;
					return blValidParams;
				}

				// Template File
				if(isEmpty(stPathTemplateFile) && stComputeTypeUpper == _ComputedType_Recompute){	    			
					_Error_Message = 'Template File cannot be empty if Compute Type is Recompute.';
					return blValidParams;
				}
				
				// Compute File
				if(isEmpty(stPathComputedFile)){

					if(isEmpty(stPathTemplateFile) && stComputeTypeUpper == _ComputedType_Recompute){
						_Error_Message = 'The Computed File or Template must be specified.';
						return blValidParams;
					}

					if(stComputeTypeUpper == _ComputedType_Computed){
						_Error_Message = 'Computed File cannot be empty if Compute Type is ' + stComputeType;
						return blValidParams;
					}
				}

				blValidParams = true;	    		

			}catch(e){
				log.error(stLogTitle, e.message);
			}

			return blValidParams;
		}

		//	Update content on a file
		function updateFile(fileObj, stNewContent){

			var stLogTitle = 'updateFile';

			try{

				var fileObjUpdated = NS_File.create({
					name: 		fileObj.name,
					fileType: 	fileObj.fileType,
					contents: 	stNewContent,
					folder : 	fileObj.folder,
					isOnline : 	fileObj.isOnline
				});

				var id = fileObjUpdated.save();
				log.audit(stLogTitle, 'file updated ' + id);

			}catch(e){
				log.error(stLogTitle, e.message);
			}
		}


		//	Copy File with a new name
		function copyFile(fileObj, stNewName){

			var stLogTitle = 'copyFile';

			try{

				var fileObjUpdated = NS_File.create({
					name: 		stNewName,
					fileType: 	fileObj.fileType,
					contents: 	fileObj.getContents(),
					folder : 	fileObj.folder,
					isOnline : 	fileObj.isOnline
				});

				var id = fileObjUpdated.save();
				log.audit(stLogTitle, 'file updated ' + id);

			}catch(e){
				log.error(stLogTitle, e.message);
			}	
		}

		// Try/catch load file
		function loadFile(stPathFile){

			var stLogTitle = 'loadFile';

			try{

				return NS_File.load({id: stPathFile});

			}catch(e){
				log.error(stLogTitle, e.message);
			}
		}

		return {
			onRequest: onRequest
		};

	}
);


function isEmpty(value) {
	if (value == null){return true;}    
	if (value == undefined){return true;}
	if (value == 'undefined'){return true;}
	if (value == ''){return true;}
	return false;
};