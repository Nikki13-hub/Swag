/**
 * Copyright (c) 1998-2018 Oracle-NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 * 
 * * Version    Date            Author           		Remarks
 *   1.00       Aug 08, 2018	Fede Garcia				Initial Version
 *
 * 
 * @NApiVersion 2.x
 * @NScriptType Restlet
 *
 **/

define(['N/search', 'N/runtime', './ECB_rest_search_Lib.js'],
function(NS_Search, NS_Runtime, LIB_Search) {

	
	function post(context) {
		
		var stLogTitle = 'post';

		var objResult = {};

		try{

			

			objResult = LIB_Search.getSearchResults(context);

			

		}catch(e){
			log.error(stLogTitle, e.message);
			objResult.success = false;
			objResult.message = e.message;
		}
		
		return objResult;
	}




	return {		
		post: post
	};
});






// This function returns true if the stValue is empty
function isEmpty(stValue) {
	if ((stValue == '') || (stValue == null) || (stValue == undefined)) {
		return true;
	}
	return false;
}