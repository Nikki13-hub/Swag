/**
 * Copyright (c) 1998-2018 Oracle-NetSuite, Inc.
 * 2955 Campus Drive, Suite 100, San Mateo, CA, USA 94403-2511
 * All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * NetSuite, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with NetSuite.
 * 
 * * Version    Date            Author           		Remarks
 *   1.00       Aug 08, 2018	Fede Garcia				Initial Version
 *
 * 
 * @NApiVersion 2.1
 *
 *
 **/

define(['N/search', 'N/runtime', 'N/record', "N/query",],
	function (NS_Search, NS_Runtime, NS_Record, NS_Query) {


		function getSearchResults(context) {

			var stLogTitle = 'getSearchResults';

			var objResult = {};
			objResult.status = {};

			try {

				var startTime = new Date();
				var intStartTimestamp = parseInt(startTime.getTime() / 1000, 10);

				log.debug(stLogTitle, ' ----  START  ---- LIB *************** ');
				log.debug(stLogTitle, context);
				objResult.inputData = context;


				var stRecType = context.RecordType;
				var stSearchId = context.SearchId;
				var stSearchName = context.SearchName;
				var stSQLQuery = context.SQLQuery;
				var stSearchFilter = context.Filters;
				var stSearchFilterJoins = context.Joins;
				var stSearchFilterExpression = context.FilterExpression;
				var stSearchColumn = context.Columns;
				var intBeginRecord = parseInt(context.BeginRecord) || 0;
				var intEndRecord = parseInt(context.EndRecord) || 99999999999;
				var objNSearch = null;
				var arrReturnSearchResults = [];
				var arrResultColumns = [];


				// Validate search type
				if (isEmpty(stRecType) && isEmpty(stSearchId) && isEmpty(stSearchName) && isEmpty(stSQLQuery)) {
					objResult.status.success = false;
					objResult.status.message = 'Missing script parameter(s). At least one value is required: SearchId, SearchName, RecordType, SQLQuery';
					return objResult;
				}

				if (!isEmpty(stSQLQuery)) {

					// const mapResultsToColumns = (result) => {
					// 	let resultObj = {}
					// 	for (columnIndex in columns) {
					// 		resultObj[columns[columnIndex]] = result.values[columnIndex]
					// 	}
					// 	return resultObj
					// }

					/*
					const myQuery = NS_Query.runSuiteQL({
						query: `SELECT ${columns} FROM CUSTOMRECORD_WMSSE_TRN_OPENTASK WHERE
						 custrecord_wmsse_wms_location = ${whLocationId} AND  custrecord_wmsse_tasktype = ${taskType} AND custrecord_wmsse_actbeginloc <> custrecord_wmsse_actendloc AND (custrecord_wmsse_nsconfirm_ref_no IS NOT NULL or custrecord_wmsse_nsconfirm_ref_no != '' ) AND 
						 (custrecord_wmsse_nstrn_ref_no IS NULL or custrecord_wmsse_nstrn_ref_no = '' ) GROUP BY custrecord_wmsse_actbeginloc 
						 HAVING count(*) >= ${maxBinPalletCount} `,
					})
					*/

					
					const columns = []
					const myQuery = NS_Query.runSuiteQL({
						query: stSQLQuery
					})

					//const objResultRec = myQuery.results.map(result => mapResultsToColumns(result))
					const objResultRec = myQuery.results

					objResult.status.success = true;
					objResult.status.message = 'Results: ' + objResultRec.length;
					//objResult.columns = arrResultColumns;
					objResult.results = objResultRec;
					objResult.status.length = objResultRec.length;

				}
				else {
					// Get ID from Name
					//if (isEmpty(stRecType) && isEmpty(stSearchId) && !isEmpty(stSearchName)) {
					if (isEmpty(stSearchId) && !isEmpty(stSearchName)) {
						stSearchId = searchSearchId(stSearchName);
						log.debug(stLogTitle, 'stSearchId ' + stSearchId);
						if (isEmpty(stSearchId)) {
							objResult.status.success = false;
							objResult.status.message = 'Search not found: "' + stSearchName + '"';
							return objResult;
						}
					}

					log.debug(stLogTitle, 'stSearchId ' + stSearchId);
					// Validate Range
					log.debug(stLogTitle, 'intBeginRecord ' + intBeginRecord + ' intEndRecord ' + intEndRecord);
					if (intBeginRecord >= intEndRecord) {
						objResult.status.success = false;
						objResult.status.message = 'BeginRecord cannot be greater or equal to EndRecord.';
						return objResult
					}
					// Create new search
					//if (!isEmpty(stRecType) && isEmpty(stSearchId)) {
					if (!isEmpty(stRecType) && isEmpty(stSearchId) && isEmpty(stSearchName)) {

						objNSearch = NS_Search.create({ type: stRecType });

						stSearchFilterExpression = stSearchFilter;

						if (!isEmpty(stSearchFilterExpression)) {
							objNSearch.filterExpression = objNSearch.filterExpression.concat(stSearchFilterExpression);
						}
					}
					// Load Saved Search if both Record type and  Search ID  is sent
					else if (!isEmpty(stRecType) && !isEmpty(stSearchId)) {

						objNSearch = NS_Search.load({ id: stSearchId, type: stRecType });

						log.debug(stLogTitle, 'stSearchFilter ' + stSearchFilter);

						if (!isEmpty(stSearchFilter)) {

							if (!isEmpty(objNSearch.filterExpression)) {

								var arrFilters = ["and", stSearchFilter];
								objNSearch.filterExpression = objNSearch.filterExpression.concat(arrFilters);

							} else {

								objNSearch.filterExpression = objNSearch.filterExpression.concat([stSearchFilter]);
							}


						}
					}
					// Load Saved Search if just Search ID or Search name is sent
					else if (!isEmpty(stSearchId)) {

						objNSearch = NS_Search.load({ id: stSearchId });

						log.debug(stLogTitle, 'stSearchFilter ' + stSearchFilter);

						if (!isEmpty(stSearchFilter)) {

							if (!isEmpty(objNSearch.filterExpression)) {

								var arrFilters = ["and", stSearchFilter];
								objNSearch.filterExpression = objNSearch.filterExpression.concat(arrFilters);

							} else {

								objNSearch.filterExpression = objNSearch.filterExpression.concat([stSearchFilter]);
							}


						}

						if (isEmpty(stSearchName)) {
							log.debug(stLogTitle, objNSearch);
							//objResult.inputData.SearchName = objNSearch.title;
						}
					}

					log.debug(stLogTitle, 'objNSearch.columns ' + objNSearch.columns);

					log.debug(stLogTitle, 'stSearchColumn ' + stSearchColumn);

					// Add columns
					if (!isEmpty(stSearchColumn)) {
						var arrCurrentcolumns = objNSearch.columns;
						if (isEmpty(arrCurrentcolumns)) {
							objNSearch.columns = stSearchColumn;
						} else {
							objNSearch.columns = objNSearch.columns.concat(stSearchColumn);
						}
					}

					// Get Columns name and label			
					var arrCurrentcolumns = objNSearch.columns;
					log.debug(stLogTitle, arrCurrentcolumns);
					if (arrCurrentcolumns && arrCurrentcolumns.length > 0) {
						for (var i = 0; i < arrCurrentcolumns.length; i++) {
							var objColumn = arrCurrentcolumns[i];
							var objData = {
								name: objColumn.name,
								join: objColumn.join,
								label: objColumn.label
							}
							arrResultColumns.push(objData);
						}
					}


					// Run Search
					var objResultset = objNSearch.run();


					// Get Results
					if ((intEndRecord - intBeginRecord) <= 1000) {

						arrReturnSearchResults = objResultset.getRange(intBeginRecord, intEndRecord);

					} else {

						var arrResultSlice = null;
						var blInit = true;
						var intCount = 1000;

						do {

							var intEndResults = intBeginRecord + intCount;
							if (intEndResults > intEndRecord) {
								intEndResults = intEndRecord;
							}

							arrResultSlice = objResultset.getRange(intBeginRecord, intEndResults);
							if (arrResultSlice == null) {
								break;
							}

							arrReturnSearchResults = arrReturnSearchResults.concat(arrResultSlice);

							intBeginRecord = intEndResults;
							intCount = arrResultSlice.length;
							blInit = false;
						}
						while ((intCount == 1000 || blInit) && (intEndResults <= intEndRecord));

					}


					log.audit(stLogTitle, 'Results: ' + arrReturnSearchResults.length);


					objResult.status.success = true;
					objResult.status.message = 'Results: ' + arrReturnSearchResults.length;
					objResult.columns = arrResultColumns;
					objResult.results = arrReturnSearchResults;
					objResult.status.length = arrReturnSearchResults.length;
				}

				objResult.status.processStartTime = intStartTimestamp;

				var intEndTimestamp = parseInt(new Date().getTime() / 1000, 10);
				objResult.status.processEndTime = intEndTimestamp;
				objResult.status.processingTime = intEndTimestamp - intStartTimestamp;

				log.debug(stLogTitle, 'sec: ' + (new Date() - startTime) / 1000 + ' rem units: ' + NS_Runtime.getCurrentScript().getRemainingUsage() + '/5000.');

			} catch (e) {
				log.error(stLogTitle + "_1", e.message);
				log.error(stLogTitle + "_2", e);
				objResult.status.success = false;
				objResult.status.message = e.message;
			}

			return objResult;
		}


		function searchSearchId(stSearchName) {

			var stLogTitle = 'searchSearchId';

			try {

				// Note: Saved Search Saved Search can't be loaded by script
				var objSavedSearch = NS_Search.create({ type: 'savedsearch' });

				stSearchName = stSearchName.trim();

				var filter1 = NS_Search.createFilter({
					name: 'titletext',
					operator: NS_Search.Operator.IS,
					values: stSearchName
				});
				objSavedSearch.filters.push(filter1);

				var objResultset = objSavedSearch.run();
				var arrResultSlice = objResultset.getRange({ start: 0, end: 2 });
				if (arrResultSlice.length == 0) {
					return null;
				} else {
					return arrResultSlice[0].id;
				}

			} catch (e) {
				log.error(stLogTitle, e);
			}
		}


		function getRecordDefinition(context) {

			var stLogTitle = 'getRecordDefinition';

			var objResult = {};
			objResult.status = {};

			try {

				var startTime = new Date();
				var intStartTimestamp = parseInt(startTime.getTime() / 1000, 10);


				var stRecType = context.RecordType;

				// Validate search type
				if (isEmpty(stRecType)) {
					objResult.status.success = false;
					objResult.status.message = 'Missing script parameter(s). RecordType is required.';
					return objResult;
				}

				var arrResults = NS_Search.create({ type: stRecType }).run().getRange({ start: 0, end: 1 });
				log.debug(stLogTitle, arrResults.length);

				if (arrResults.length == 0) {
					objResult.status.success = false;
					objResult.status.message = 'No record found.';
					return objResult;
				}

				var stRecordId = arrResults[0].id;
				var stRecordType = arrResults[0].recordType;
				log.debug(stLogTitle, 'stRecordId ' + stRecordId + ' stRecordType ' + stRecordType);

				var objRecord = NS_Record.load({ type: stRecordType, id: stRecordId, isDynamic: false });

				objResult.fields = objRecord.getFields();

				var arrSublists = objRecord.getSublists();
				objResult.sublists = arrSublists;
				objResult.sublistFields = {}

				for (var i = 0; i < arrSublists.length; i++) {

					var stSublistId = arrSublists[i];
					log.debug(stLogTitle, 'stSublistId ' + stSublistId);

					var objColumnFields = objRecord.getSublistFields({ sublistId: stSublistId });
					log.debug(stLogTitle, objColumnFields);

					objResult.sublistFields[stSublistId] = objColumnFields;

				}

				var intEndTimestamp = parseInt(new Date().getTime() / 1000, 10);
				objResult.status.processStartTime = intStartTimestamp;
				objResult.status.processEndTime = intEndTimestamp;
				objResult.status.processingTime = intEndTimestamp - intStartTimestamp;
				objResult.status.success = true;

				log.debug(stLogTitle, 'sec: ' + (new Date() - startTime) / 1000 + ' rem units: ' + NS_Runtime.getCurrentScript().getRemainingUsage() + '/5000.');

			} catch (e) {
				log.error(stLogTitle, e.message);
				objResult.status.success = false;
				objResult.status.message = e.message;
			}

			return objResult;

		}

		return {
			getSearchResults: getSearchResults,
			getRecordDefinition: getRecordDefinition
		};
	});






// This function returns true if the stValue is empty
function isEmpty(stValue) {
	if ((stValue == '') || (stValue == null) || (stValue == undefined)) {
		return true;
	}
	return false;
}