/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */
define(['N/record', 'N/error', 'N/log', 'N/redirect', 'N/search', 'N/task', 'N/runtime', 'N/format', 'N/email', 'N/file', 'N/ui/serverWidget'],
function(record, error, log, redirect, search, task, runtime, format, email, file, serverWidget) {
    function onRequest(context) {
        if (context.request.method === 'GET') {
            var parameters = context.request.parameters;
            try {
                var stId = parameters.invoice;
                var type = parameters.type || 'page';
              	log.debug('Parameter', 'Invoice = '+stId + ', '+type);
              	if( type == 'direct' ) {
              		if( isEmpty(stId) )  throw 'No requestId!';
	                var arrFilter = [], arrColumns = [];
					arrFilter.push(search.createFilter({name: 'internalidnumber', operator: "equalto", values: [stId]}));
					arrFilter.push(search.createFilter({name: 'mainline', operator: "is", values: ['T']}));
					arrColumns.push(search.createColumn({name: "internalid", join: "file", sort: 'DESC'}));
					arrColumns.push(search.createColumn({name: 'name', join: "file"}));
					
					var arrResult = runSearch(search, 'invoice', null, arrFilter, arrColumns);
					log.debug('Invoice Files', 'Files = ' + arrResult.length);
					var isExist = false;
					//for (var idx = 0; idx < arrResult.length; idx++){
					if( arrResult.length ) {
						objResult = arrResult[0];
						var fileId = objResult.getValue({name: 'internalid', join: 'file'});
						var fileName = objResult.getValue({name: 'name', join: 'file'})||'';
						record.submitFields({
							type: 'invoice',
							id: stId,
							values: { custbody_pod_signature: fileId },
							options: {
								enableSourcing: false,
								ignoreMandatoryFields: true
							}
						});
						isExist = true;

						if( fileName.indexOf('swad_') == -1 && fileName.indexOf('SWAD_') == -1 ) {
							var fileObj = file.load({id: Number(fileId)});
							fileObj.name = 'swad_' + fileObj.name;
							fileObj.save();
						}
					}
	                
	                context.response.write(JSON.stringify({
	                    "success": isExist
	                }));
              	} else {
              		var objForm = serverWidget.createForm({ title: 'Signature File', hideNavBar: false });
              		var objFldAction = objForm.addField({
						id: 'custpage_invoice',
						type: serverWidget.FieldType.TEXT,
						label: 'Invoice'
					});
					objFldAction.defaultValue = stId;
					objFldAction.updateDisplayType({ displayType: "HIDDEN" });
              		var objFldFile = objForm.addField({
						id: 'custpage_podfile',
						type: serverWidget.FieldType.FILE,
						label: 'Signature File'
					});
                    objFldFile.isMandatory = true;
					objForm.addSubmitButton({
						label: 'Upload'
					});
					context.response.writePage(objForm);    
				}
            } catch (e) {
                log.debug('Error', e);
                return {
                    "success": false
                }
            }
        } else {
        	var parameters = context.request.parameters;
        	var stId = parameters.custpage_invoice;
        	var sigFile = context.request.files['custpage_podfile'];
        	sigFile.folder = 853188;
        	var fileId = sigFile.save();
        	if( !isEmpty(fileId) ) {
        		record.submitFields({
					type: 'invoice',
					id: stId,
					values: { custbody_pod_signature: fileId },
					options: {
						enableSourcing: false,
						ignoreMandatoryFields: true
					}
				});
				record.attach({
	    			record: {
	    				type: 'file',
	        			id: fileId
	    			},
	    			to: {
	    				type: 'invoice',
	    				id: stId
	    			}
	    		});
				context.response.write("Success uploading file!<script>window.opener.location.reload(true);window.close();</script>");
				// redirect.toRecord({
				//  	type : 'invoice', 
				//  	id : stId
				// });
        	} else
        		context.response.write("Failed uploading file!");
        }
    }
    
    function runSearch(search, recType, searchId, filters, columns) {
        var retList = new Array();
        var srchObj = null;
        if (searchId == null || searchId == '')
            srchObj = search.create({type : recType, filters: filters, columns: columns});
        else
        {
            srchObj = search.load({id : searchId});
            var existFilters = srchObj.filters;
            var existColumns = srchObj.columns;

            existFilters = (existFilters == null || existFilters == '') ? new Array() : existFilters;
            existColumns = (existColumns == null || existColumns == '') ? new Array() : existColumns;
            if (filters != null && filters != '')
            {
                for (var idx = 0; idx < filters.length; idx++)
                    existFilters.push(filters[idx]);
            }
            if (columns != null && columns != '')
            {
                for(var idx = 0; idx < columns.length; idx++)
                    existColumns.push(columns[idx]);
            }

            srchObj.filters = existFilters;
            srchObj.columns = existColumns;
        }

        var resultSet = srchObj.run();
        var startPos = 0, endPos = 1000;
        while (startPos <= 10000)
        {
            var options = new Object();
            options.start = startPos;
            options.end = endPos;
            var currList = resultSet.getRange(options);
            if (currList == null || currList.length <= 0)
                break;
            if (retList == null)
                retList = currList;
            else
                retList = retList.concat(currList);

            if (currList.length < 1000)
                break;

            startPos += 1000;
            endPos += 1000;
        }

        return retList;
    }

    function isEmpty(value) {
        var bResult = false;
        if (
            value === null ||
            value === 'null' ||
            value === undefined ||
            value === '' ||
            value.length <= 0
        ) {
            bResult = true;
        }
        return bResult;
    }

    function inArray(val, arr) {   
        var bIsValueFound = false;  
        
        for(var i = 0; i < arr.length; i++)
        {
            if(val == arr[i])
            {
                bIsValueFound = true;        
                break;    
            }
        }
        
        return bIsValueFound;
    }
    
    return {
        onRequest: onRequest
    };
});
