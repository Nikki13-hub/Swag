/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record', 'N/search', 'N/ui/serverWidget', 'N/runtime', 'N/task'],

function(record, search, ui, runtime, task) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
        log.debug('beforeLoad', 'Start = '+scriptContext.type);
        if( scriptContext.type == 'view' ) {
            var objForm = scriptContext.form;
            var invId = scriptContext.newRecord.id;
            objForm.addButton({
                id : 'custpage_pod',
                label : 'Upload Signature File',
                functionName : 'uploadPOD('+invId+')'
            });
            
            objForm.addField({
                id: 'custpage_stickyheaders_script',
                label: 'Hidden',
                type: ui.FieldType.INLINEHTML
            }).defaultValue = '<script>' +
                '(function($){' +
                    "var targetNode = document.getElementById('dadRecordDropZoneBackgroundStatus');"+
                    "var observer = new MutationObserver(function(mutationsList, observer) {" + 
                        "for(var mutation of mutationsList) {" +
                            "if (mutation.type === 'childList' && targetNode.textContent.indexOf('completed') > -1) {" +
                                "jQuery.get('https://6827316.app.netsuite.com/app/site/hosting/scriptlet.nl?script=5001&deploy=1&type=direct&invoice="+invId+"', function( data ) {" +
                                    "var retData = JSON.parse(data);" +
                                    "if( retData.success ){" +
                                        "console.log('***Uploaded File***');" +
                                        "location.reload();" +
                                    "}" +
                                "});" +
                            '}}});' +
                    'var config = { childList: true, subtree: true };' +
                    'observer.observe(targetNode, config);' +
                '})(jQuery);' +
            '</script>';
            objForm.clientScriptModulePath = './WillCallPOD_CS.js';
        }
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
        
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {
        
    }

    return {
        beforeLoad: beforeLoad,
        //beforeSubmit: beforeSubmit,
        //afterSubmit: afterSubmit
    };
    
});
