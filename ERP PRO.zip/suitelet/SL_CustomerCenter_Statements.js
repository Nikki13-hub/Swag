/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope public
 */

 define([
 	'N/ui/serverWidget',
 	'N/record',
 	'N/render',
 	'N/runtime'
 ], (ui, record, render, runtime) => {
  
  function onRequest(context) {
    const { request, response } = context;
    const reqParameters = request.parameters;
    const user = runtime.getCurrentUser();
    const userId = user.id;
    const userSubsi = user.subsidiary;
    const todaysDate = new Date();
    const lastMosDate = new Date(todaysDate.getFullYear(), todaysDate.getMonth() - 1, todaysDate.getDate());
    
    if (request.method == 'GET'){
      
    	let form = ui.createForm({
	        title: 'Print Transit Statements',
	        hideNavBar: false
      	});
      	let customerFld = form.addField({
	        id : 'custpage_customer',
	        type : ui.FieldType.SELECT,
	        label : 'Customer',
	        source: 'customer'
      	});
      	customerFld.isMandatory = true;
      	customerFld.defaultValue = userId;

      	// Subsidiary
      	let subsidiaryFld = form.addField({
	        id : 'custpage_subsdiary',
	        type : ui.FieldType.SELECT,
	        label : 'Subsidiary',
	        source: 'subsidiary'
      	});
      	subsidiaryFld.isMandatory = true;
      	subsidiaryFld.defaultValue = userSubsi;

      	// Statement Date
      	let dateFld = form.addField({
	        id : 'custpage_statementdate',
	        type : ui.FieldType.DATE,
	        label : 'Statement Date'
	    });
	    dateFld.defaultValue = todaysDate;

      	// Start Date
      	let startDateFld = form.addField({
	        id : 'custpage_startdate',
	        type : ui.FieldType.DATE,
	        label : 'Start Date'
	    });
	    startDateFld.defaultValue = lastMosDate;

      	// Show Only Open Transactions (true)
      	let openTransaction = form.addField({
	        id : 'custpage_opentransaction',
	        type : ui.FieldType.CHECKBOX,
	        label : 'Show Only Open Transactions'
	    });
	    openTransaction.defaultValue = 'T';

      	// Consolidated Statement (true)
      	let consolidatedStatement = form.addField({
	        id : 'custpage_consolidated',
	        type : ui.FieldType.CHECKBOX,
	        label : 'Consolidated Statement'
	    });
	    consolidatedStatement.defaultValue = 'T';

      	// Display Only Transit Statement
      	let transitOnlyFld = form.addField({
	        id : 'custpage_onlytransit',
	        type : ui.FieldType.CHECKBOX,
	        label : 'Display Only Transit Statement'
	    });
	    transitOnlyFld.defaultValue = 'T';

      

      form.addSubmitButton({
        label: 'Print',
      });
      response.writePage(form);

    } else {

    	log.debug('PARAMS', reqParameters);
    	const {
	        custpage_customer: customer,
	        custpage_subsdiary: subsidiary,
	        custpage_statementdate: statementDate,
	        custpage_startdate: startDate,
	        custpage_opentransaction: openTrans,
	        custpage_consolidated: consolidated,
	        custpage_onlytransit: onlyTransit
	    } = reqParameters;


    	const statementFile = 
    	render.statement({
			entityId: Number(customer),
			subsidiaryId: Number(subsidiary),
			printMode: render.PrintMode.PDF,
			formId: onlyTransit == 'T' ? 284 : undefined, //Transit Orders Only for GM customers
			inCustLocale: true,
			startDate: startDate,
			statementDate: statementDate,
			openTransactionsOnly: openTrans == 'T' ? true : false,
			consolidateStatements: consolidated == 'T' ? true : false,
		});
		

		response.writeFile({ file: statementFile, isInline: false });
      
    }

  }

  return {
    onRequest
  };
});