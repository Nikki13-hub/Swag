/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/record', 'N/currentRecord'],

function(search, record, currentRecord) {

    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        
    }

    function uploadPOD(invId) {
        var curRec = currentRecord.get();
        try{
            window.open('https://6827316.app.netsuite.com/app/site/hosting/scriptlet.nl?script=5001&deploy=1&type=page&invoice='+invId+'', 'Signature File', 'width=300,height=300');
        } catch(e){

        }
    }

    Date.prototype.addDays = function (days) {
        const date = new Date(this.valueOf());
        date.setDate(date.getDate() + days);
        return date;
    };

    function runSearch(search, recType, searchId, filters, columns) {
        var srchObj = null;
        if(searchId == null || searchId == ''){
            srchObj = search.create({type : recType, filters: filters, columns: columns});
            //log.debug('runSearch', 'srchObj ='+JSON.stringify(srchObj));
        }else
        {
            srchObj = search.load({id : searchId});
            var existFilters = srchObj.filters;
            var existColumns = srchObj.columns;
            
            existFilters = (existFilters == null || existFilters == '') ? new Array() : existFilters;
            existColumns = (existColumns == null || existColumns == '') ? new Array() : existColumns;
            if(filters != null && filters != '')
            {
                for(var idx=0; idx < filters.length; idx++)
                    existFilters.push(filters[idx]);
            }
            if(columns != null && columns != '')
            {
                for(var idx=0; idx < columns.length; idx++)
                    existColumns.push(columns[idx]);
            }
            
            srchObj.filters = existFilters;
            srchObj.columns = existColumns;
        }
        
        var resultSet = srchObj.run();

        return resultSet;
    }

    return {
        pageInit: pageInit,
        uploadPOD: uploadPOD
    };
});