/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/ui/dialog', 'N/search', 'N/runtime'],

    function (__dialog, __search, __runtime) {
        var isSubmitted = false;
        /**
         * Function to be executed after page is initialized.
         *
         * @param {Object} scriptContext
         * @param {Record} scriptContext.currentRecord - Current form record
         * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
         *
         * @since 2015.2
         */
        function pageInit(_scriptContext) {
            var rec = _scriptContext.currentRecord;
            try {
                jQuery("#dealer_num").on("change", function () {
                    var dealer_num = jQuery(this).val();
                    if( isEmpty(dealer_num) )   return;
                    jQuery.get("https://6827316.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=5009&deploy=1&compid=6827316&ns-at=AAEJ7tMQyj8gcxvJ7HatqpUYhY_Tz-jNEj1xrWH5gy01qaScmpY&action=dealer&dealer_num="+dealer_num, function( data ) {
                        var retData = JSON.parse(data);
                        if( retData.success ){
                            console.log(JSON.stringify(retData.data));
                            jQuery('#customer_id').val(retData.data.id);
                            jQuery('#customer_sub').val(retData.data.subsidiary);
                            jQuery('#dealer_name').val(retData.data.name);
                            jQuery('#dealer_addr').val(retData.data.addr);
                            jQuery('#dealer_phone').val(retData.data.phone);
                        } else
                            alert(retData.message);

                    });
                    
                });

                jQuery("#item_file").change(function(e) {
                    var ext = jQuery(this).val().split(".").pop().toLowerCase();
                    if(jQuery.inArray(ext, ["csv"]) == -1) {
                        alert('Please upload CSV file!');
                        return false;
                    }
                    if (e.target.files != undefined) {
                        var reader = new FileReader();
                        reader.onload = function(e) {
                            var lines = e.target.result.split('\r\n');
                            var columns = lines[0].split(',');
                            if( columns.length != 2 ) {
                                alert('Please upload correct CSV file!');
                                return false;
                            }
                            var customerSub = jQuery('#customer_sub').val();
                            for (i = 1; i < lines.length; ++i){
                                var partInfo = lines[i].split(',');
                                if( !isEmpty(partInfo[0]) ) {
                                    console.log(partInfo[0]+', '+partInfo[1]);                                
                                    jQuery.get("https://6827316.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=5009&deploy=1&compid=6827316&ns-at=AAEJ7tMQyj8gcxvJ7HatqpUYhY_Tz-jNEj1xrWH5gy01qaScmpY&action=part&part_num="+partInfo[0]+"&subsidiary="+customerSub+"&part_qty="+partInfo[1], function( data ) {
                                        console.log(data);
                                        var retData = JSON.parse(data);
                                        if( retData.success ){
                                            var trRow = jQuery('#item_table tr:last');
                                            trRow.attr('value', retData.data.id);
                                            trRow.find('td').eq(0).children(0).val(retData.data.name);
                                            trRow.find('td').eq(1).children(0).val(retData.data.qty);
                                            trRow.find('td').eq(2).children(0).val(retData.data.desc);
                                            trRow.find('button').eq(0).trigger("click");
                                        } else{
                                            alert(retData.message);
                                            jQuery('#item_file').val('');
                                        }
                                    });
                                }
                            }
                        };
                        reader.readAsText(e.target.files.item(0));
                    }
                    return false;
                });

                jQuery(".ibtnAdd").on("click", function () {
                    if( jQuery('#item_table').find('tr').length > 52 ) {
                        alert('Parts can be up to 50+ lines!');
                        return;
                    }
                    // Add Row
                    var oldRow = jQuery(this).closest("tr");
                    if( isEmpty(oldRow.attr('value')) || isEmpty(oldRow.find('input').eq(1).val()) ){
                        alert('Please enter a part number and quantity!');
                        return;
                    }
                    var newRow = oldRow.clone();
                    newRow.find('button').parent().html('<button type="button" class="ibtnDel btn btn-danger btn-md"><span class="bi-trash" style="font-size: 2rem;"></span></button>');
                    newRow.insertBefore(oldRow);

                    //Reset Row
                    oldRow.attr('value', '');
                    jQuery.each(oldRow.find('input'), function () {
                        jQuery(this).val('');
                    });
                });

                jQuery(document).on('click', 'button.ibtnDel', function () {
                    // var trVal = jQuery(this).closest("tr").attr('value');
                    // var tblId = jQuery(this).closest('table').prop('id');
                    jQuery(this).closest("tr").remove();
                });

                jQuery(".partNumInt").on("change", function () {
                    var trRow = jQuery(this).closest("tr");
                    var part_num = jQuery(this).val();
                    var customerSub = jQuery('#customer_sub').val();
                    if( isEmpty(part_num) )   return;
                    jQuery.get("https://6827316.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=5009&deploy=1&compid=6827316&ns-at=AAEJ7tMQyj8gcxvJ7HatqpUYhY_Tz-jNEj1xrWH5gy01qaScmpY&action=part&part_num="+part_num+"&subsidiary="+customerSub, function( data ) {
                        var retData = JSON.parse(data);
                        if( retData.success ){
                            trRow.attr('value', retData.data.id);
                            trRow.find('td').eq(2).children(0).val(retData.data.desc);
                        } else
                            alert(retData.message);

                    });
                });

                // Processing UI components
                jQuery("#main_form").attr("action", "https://6827316.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=5009&deploy=1&compid=6827316&ns-at=AAEJ7tMQyj8gcxvJ7HatqpUYhY_Tz-jNEj1xrWH5gy01qaScmpY");
                
            } catch (err) {
                console.log(err);
            }
        }

        function saveRecord(_scriptContext){
            if( isSubmitted ) {
                alert("You've already submitted this order, please be patient while it's processing");
                return false;
            }
          
            var rec = _scriptContext.currentRecord;
            var itemData = '';
            if( isEmpty(jQuery('#customer_id').val()) ){
                alert('Please enter dealer info!');
                return false;
            }

            if( jQuery('#item_table tbody').find('tr').length < 2 && isEmpty(jQuery('#item_file').val())){
                alert('Please enter one part at least one or select template file!');
                return false;
            }

            jQuery.each(jQuery('#item_table tbody').find('tr'), function () {
                itemData += jQuery(this).attr('value')+'@'+jQuery(this).find('input').eq(1).val()+'@';
                // jQuery.each(jQuery(this).find('input'), function () {
                //     itemData += jQuery(this).val()+'@';
                // });
            });
            itemData = itemData.replace('@@', '');
            jQuery('#item_data').val(itemData);
            isSubmitted = true;
            console.log(itemData);
            return true;
        }

        function fieldChanged(_scriptContext) {
            try {
                var rec = _scriptContext.currentRecord;
                
            } catch (e){
                
            }
        }

        function getParameterFromURL(param) {
            var query = window.location.search.substring(1);
            var vars = query.split("&");
            for (var i = 0; i < vars.length; i++) {
                var pair = vars[i].split("=");
                if (pair[0] == param) {
                    return decodeURIComponent(pair[1]) || '';
                }
            }
            return (false);
        }

        function isEmpty(stValue) {
            return ((stValue === '' || stValue == null || stValue == undefined)
                || (stValue.constructor === Array && stValue.length == 0)
                || (stValue.constructor === Object && (function (v) { for (var k in v) return false; return true; })(stValue)));
        }

        return {
            pageInit: pageInit,
            saveRecord: saveRecord,
            fieldChanged: fieldChanged
        };
    });