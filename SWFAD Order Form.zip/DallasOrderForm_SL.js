/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */
define(['N/record', 'N/error', 'N/log', 'N/https', 'N/search', 'N/task', 'N/runtime', 'N/format', 'N/email', 'N/render'],
function(record, error, log, https, search, task, runtime, format, email, render) {
    function onRequest(context) {
        if (context.request.method === 'GET') {
            var parameters = context.request.parameters;
            try {
                stAction = parameters.action||'dealer';
                stDealerNum = parameters.dealer_num||'';
                stPartNum = parameters.part_num||'';
                stPartQty = parameters.part_qty||'';
                stCustomerSub = parameters.subsidiary||'';
                log.debug('Parameter', 'Action = '+stAction+', Dealer = '+stDealerNum+', Part = '+stPartNum);
                if( stAction == 'dealer' && isEmpty(stDealerNum) )  throw 'No dealer number!';
                if( stAction == 'part' && isEmpty(stPartNum) )  throw 'No part number!';

                var retData = {};
                var arrFilter = [], arrColumns = [];
                if( stAction == 'dealer' ) {
                    arrFilter.push(search.createFilter({name: 'isinactive', operator: search.Operator.IS, values: ['F']}));
                    arrFilter.push(search.createFilter({name: 'entityid', operator: search.Operator.IS, values: [stDealerNum]}));
                    arrColumns.push(search.createColumn({name: "altname"}));
                    arrColumns.push(search.createColumn({name: 'shipaddress'}));
                    arrColumns.push(search.createColumn({name: 'billaddress'}));
                    arrColumns.push(search.createColumn({name: 'phone'}));
                    arrColumns.push(search.createColumn({name: 'subsidiary'}));
                    var arrResult = runSearch(search, 'customer', null, arrFilter, arrColumns);
                    if( arrResult.length ){
                        retData.id = arrResult[0].id;
                        retData.name = arrResult[0].getValue('altname');
                        retData.addr = arrResult[0].getValue('billaddress')?arrResult[0].getValue('billaddress'):arrResult[0].getValue('shipaddress');
                        retData.phone = arrResult[0].getValue('phone');
                        retData.subsidiary = arrResult[0].getValue('subsidiary');
                    } else
                        throw 'There is no dealer with #'+stDealerNum+'!';
                } else{
                    arrFilter.push(search.createFilter({name: 'isinactive', operator: search.Operator.IS, values: ['F']}));
                    arrFilter.push(search.createFilter({name: "itemid", operator: 'is', values: [stPartNum]}));
                    arrColumns.push(search.createColumn({name: "itemid"}));
                    arrColumns.push(search.createColumn({name: "salesdescription"}));
                    arrColumns.push(search.createColumn({name: "subsidiary"}));
                    var arrResult = runSearch(search, 'item', null, arrFilter, arrColumns);
                    log.debug('Search Items', 'Items = '+arrResult.length);
                    var isExistSub = false;
                    if( arrResult.length ){
                        /*retData.id = arrResult[0].id;
                        retData.name = stPartNum;
                        retData.qty = stPartQty;
                        retData.desc = arrResult[0].getValue('salesdescription');
                        retData.subsidiary = arrResult[0].getValue('subsidiary');*/
                        for(var i=0;i<arrResult.length;i++) {
                            log.debug('Item Info', 'Item = '+arrResult[i].id);
                            if(stCustomerSub == arrResult[i].getValue('subsidiary')){
                                isExistSub = true;
                                retData.id = arrResult[i].id;
                                retData.name = stPartNum;
                                retData.qty = stPartQty;
                                retData.desc = arrResult[i].getValue('salesdescription');
                                retData.subsidiary = arrResult[i].getValue('subsidiary');
                                break;
                            }
                            //if(stCustomerSub == arrResult[i].getValue('subsidiary'))    isExistSub = true;
                            //log.debug('Item subsidiary', 'subsidiary = '+arrResult[i].getValue('subsidiary'));
                        }
                    } else
                        throw 'There is no part with #'+stPartNum+'!';


                    if(!isExistSub)     throw 'Part #'+stPartNum+' is invalid for the dealer!';
                }

                context.response.write(JSON.stringify({
                    "success": true,
                    "data": retData
                }));
            } catch (e) {
                log.debug('Error', e);
                context.response.write(JSON.stringify({
                    "success": false,
                    "message": JSON.stringify(e)
                }));
            }
        } else {
            var html = '';
            try {
                var reqPara = context.request.parameters;
                var reqFile = context.request.files;
                var stCustomerId = reqPara.customer_id || '';
                var stVinNum = reqPara.vin_num || '';
                var stCEmail = reqPara.client_email || '';
                var stCName = reqPara.client_name || '';
                var stWillCall = reqPara.will_call||'';
                log.debug('Parameter', 'Customer = '+stCustomerId+', vin_num='+stVinNum+', willcall='+stWillCall+', Item='+reqPara.item_data);
                //log.debug('Parameter', reqFile);
                
                if( stCustomerId ){
                    var stItemName = "", arrItemInfo = [];
                    var entityRec = record.load({type: 'customer', id: stCustomerId});
                    var salesLocation = entityRec.getValue('custentity_nsps_customer_default_loc');
                    var fulfilLocation = entityRec.getValue('custentity_8q_fulfillment_f');
                    var routeNum = entityRec.getValue('custentity_swag_routes');
                    var repId = entityRec.getValue('salesrep');
                    
                    var itemData = reqPara.item_data.split('@');
                    if( !itemData.length )      throw 'No Parts'
                    var soRec = record.create({type: 'salesorder'});
                    soRec.setValue('entity', stCustomerId);
                    soRec.setValue('otherrefnum', reqPara.po_num);
                    soRec.setValue('memo', reqPara.comments);
                    soRec.setValue('orderstatus', 'B');
                    if( !isEmpty(salesLocation) )   soRec.setValue('location', salesLocation);
                    if( !isEmpty(fulfilLocation) )   soRec.setValue('custbody_8q_fulfillment_f', fulfilLocation);
                    if( !isEmpty(stVinNum) )   soRec.setValue('custbody_nsts_vin_number', stVinNum);
                    if( !isEmpty(stWillCall) )   soRec.setValue('custbody_nsps_online_ord_type', 3);
                    if( !isEmpty(routeNum) )   soRec.setValue('custbody_nsps_lpo_route', routeNum);
     
                    var nRow = 0;
                    for(var i=0;i<(itemData.length-1)/2;i++){
                        if( isEmpty(itemData[2*i]) )    continue;
                        soRec.setSublistValue({sublistId:'item', fieldId: 'item', value: itemData[2*i], line: nRow});
                        soRec.setSublistValue({sublistId:'item', fieldId: 'quantity', value: itemData[2*i+1], line: nRow});
                        if( !isEmpty(fulfilLocation) )      soRec.setSublistValue({sublistId:'item', fieldId: 'inventorylocation', value: fulfilLocation, line: nRow});
                        //soRec.setSublistValue({sublistId:'item', fieldId: 'memo', value: arrItemInfo[i].desc, line: nRow});
                        nRow ++;
                    }
                    var soId = soRec.save();
                    log.debug('Created SO', 'Id = '+soId);
                    if( !isEmpty(soId) && !isEmpty(repId)) {
                        var soFlds = search.lookupFields({
                            type: 'salesorder',
                            id: soId,
                            columns: ['tranid']
                        });
 
                        var mergeResultObj = render.mergeEmail({ templateId: 55});
                        var subject = 'SWFAD Order Confirmation';
                        var body = 'Dear '+stCName+',<br>' + 'Your order('+soFlds.tranid+') was created successfully.<br>';
                        email.send({
                          author: repId,
                          recipients: [stCEmail],
                          subject: mergeResultObj.subject,
                          body: mergeResultObj.body.replace('{{id}}', soFlds.tranid),
                        });
                    }

                    html = ''
                        +'<br>'
                        +'<br>'
                        +'<br>'
                        +'<center><img src="https://swfad.com/inc/templates/current/vehicle_responsive/images/SouthwestFAD_Color_1x.png" alt="Southwest FAD"></center>'
                        +'<br>'
                        +'<center><b>Thank you for submitting your order.</b></center>'
                        +'<br>'
                        +'<center><b>If there is any issues processing your order, we will contact you.</b></center>'
                        +'';
                } else
                    throw "No Dealer!";
                // return {
                //     "success": true
                // }
            } catch (e){
                log.debug('Error', e);
                html = ''
                    +'<br>'
                    +'<br>'
                    +'<br>'
                    +'<center><img src="https://swfad.com/inc/templates/current/vehicle_responsive/images/SouthwestFAD_Color_1x.png" alt="Southwest FAD"></center>'
                    +'<br>'
                    +'<center><b>Your order has been submitted successfully.</b></center>'
                    +'<br>'
                    +'<center><b>If you have any questions please contact us at 817-770-0996.</b><br>Thank you.</center>'
                    +'<br>'
                    +'';

                // return {
                //     "success": false,
                //     "Error Message": e.message
                // }
            }
            context.response.write(html);
        }
    }
    
    function runSearch(search, recType, searchId, filters, columns) {
        var retList = new Array();
        var srchObj = null;
        if (searchId == null || searchId == '')
            srchObj = search.create({type : recType, filters: filters, columns: columns});
        else
        {
            srchObj = search.load({id : searchId});
            var existFilters = srchObj.filters;
            var existColumns = srchObj.columns;

            existFilters = (existFilters == null || existFilters == '') ? new Array() : existFilters;
            existColumns = (existColumns == null || existColumns == '') ? new Array() : existColumns;
            if (filters != null && filters != '')
            {
                for (var idx = 0; idx < filters.length; idx++)
                    existFilters.push(filters[idx]);
            }
            if (columns != null && columns != '')
            {
                for(var idx = 0; idx < columns.length; idx++)
                    existColumns.push(columns[idx]);
            }

            srchObj.filters = existFilters;
            srchObj.columns = existColumns;
        }

        var resultSet = srchObj.run();
        var startPos = 0, endPos = 1000;
        while (startPos <= 10000)
        {
            var options = new Object();
            options.start = startPos;
            options.end = endPos;
            var currList = resultSet.getRange(options);
            if (currList == null || currList.length <= 0)
                break;
            if (retList == null)
                retList = currList;
            else
                retList = retList.concat(currList);

            if (currList.length < 1000)
                break;

            startPos += 1000;
            endPos += 1000;
        }

        return retList;
    }

    function updateReqDetail(fldId, fldVal, fldType, requestId, resendCnt){
        try {
            /*var arrFilter = [], arrColumns = [];
            arrFilter.push(search.createFilter({name: 'custrecord_vord_request', operator: search.Operator.IS, values: [requestId]}));
            arrFilter.push(search.createFilter({name: 'custrecord_vord_field', operator: search.Operator.IS, values: [fldId]}));
            arrColumns.push(search.createColumn({name: "custrecord_vord_field"}));
            arrColumns.push(search.createColumn({name: 'custrecord_vord_value'}));
            var arrResult = runSearch(search, 'customrecord_vendoronboardingrequestdeta', null, arrFilter, arrColumns);
            if( arrResult.length ){
                var detailId = arrResult[0].id;
                record.submitFields({
                    type: 'customrecord_vendoronboardingrequestdeta',
                    id: detailId,
                    values: {
                        custrecord_vord_value: fldVal
                    },
                    options: {
                        enableSourcing: false,
                        ignoreMandatoryFields : true
                    }
                });
                log.debug('updateReqDetail: Updated RequestDetail', 'Text: Detail Id = '+detailId);
            } else{*/
                var reqRec = record.create({ type: 'customrecord_vendoronboardingrequestdeta' });
                reqRec.setValue({
                    fieldId: 'custrecord_vord_field',
                    value: fldId
                });
                reqRec.setValue({
                    fieldId: 'custrecord_vord_value',
                    value: fldVal
                });
                reqRec.setValue({
                    fieldId: 'custrecord_vord_type',
                    value: fldType
                });
                reqRec.setValue({
                    fieldId: 'custrecord_vord_request',
                    value: requestId
                });
                reqRec.setValue({
                    fieldId: 'custrecord_vord_resend',
                    value: resendCnt
                });
                var detailId = reqRec.save();
                log.debug('updateReqDetail: Created RequestDetail', 'Text: Detail Id = '+detailId);   
            //}
        } catch (e){
            log.debug('Error', e);
        }
    }
    
    function isEmpty(value) {
        var bResult = false;
        if (
            value === null ||
            value === 'null' ||
            value === undefined ||
            value === '' ||
            value.length <= 0
        ) {
            bResult = true;
        }
        return bResult;
    }

    function inArray(val, arr) {   
        var bIsValueFound = false;  
        
        for(var i = 0; i < arr.length; i++)
        {
            if(val == arr[i])
            {
                bIsValueFound = true;        
                break;    
            }
        }
        
        return bIsValueFound;
    }
    
    return {
        onRequest: onRequest
    };
});
